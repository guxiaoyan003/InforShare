from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Talent
from ..resp import ok
from ..serializers import talent_dict

router = APIRouter(prefix="/talents", tags=["talents"])


@router.get("")
def list_talents(
    q: Optional[str] = None,
    seg: int = 0,
    db: Session = Depends(get_db),
):
    query = db.query(Talent)
    if q:
        like = "%" + q + "%"
        query = query.filter(or_(Talent.name.like(like), Talent.dir.like(like), Talent.city.like(like)))
    rows = query.all()
    if seg == 1:
        rows = [t for t in rows if any(k in (t.dir or "") for k in ["智能体", "视觉", "大模型", "数据"])]
    elif seg == 2:
        rows = [t for t in rows if "产品" in (t.dir or "")]
    elif seg == 3:
        rows = [t for t in rows if "培训" in (t.dir or "")]
    rows.sort(key=lambda t: t.match_score or 0, reverse=True)
    return ok([talent_dict(t) for t in rows])


@router.get("/{talent_id}")
def talent_detail(talent_id: str, db: Session = Depends(get_db)):
    t = db.get(Talent, talent_id)
    if not t:
        raise HTTPException(status_code=404, detail="牛人不存在")
    return ok(talent_dict(t))
