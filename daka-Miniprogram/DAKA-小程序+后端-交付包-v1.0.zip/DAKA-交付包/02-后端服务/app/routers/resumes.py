import shutil
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import get_current_user
from ..models import Resume, User
from ..resp import ok, uid
from ..serializers import resume_dict

router = APIRouter(tags=["resumes"])

ALLOWED = {".pdf", ".doc", ".docx"}


def _files(db: Session, user: User):
    return (
        db.query(Resume)
        .filter(Resume.user_id == user.id, Resume.is_online.is_(False))
        .order_by(Resume.created_at.desc())
        .all()
    )


@router.get("/resumes")
def list_resumes(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return ok([resume_dict(r) for r in _files(db, user)])


@router.post("/resumes")
def upload_resume(
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(status_code=400, detail="仅支持 PDF / DOC / DOCX")
    content = file.file.read()
    if len(content) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件超过 %d MB" % settings.MAX_UPLOAD_MB)
    settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    name_on_disk = uid("r") + ext
    target = settings.UPLOAD_DIR / name_on_disk
    with target.open("wb") as f:
        f.write(content)
    size_text = (
        "%.1f MB" % (len(content) / 1024 / 1024)
        if len(content) >= 1024 * 1024
        else "%d KB" % max(1, round(len(content) / 1024))
    )
    r = Resume(
        id=uid("R-"),
        user_id=user.id,
        is_online=False,
        name=file.filename[:150],
        time_text=__import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M"),
        size_text=size_text,
        file_url=settings.UPLOAD_BASE_URL.rstrip("/") + "/" + name_on_disk,
    )
    db.add(r)
    db.commit()
    return ok([resume_dict(x) for x in _files(db, user)])


@router.get("/resume")
def get_online_resume(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.query(Resume).filter(Resume.user_id == user.id, Resume.is_online.is_(True)).first()
    if not r:
        return ok({})
    return ok(dict(r.content or {}))


@router.put("/resume")
def save_online_resume(payload: dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.query(Resume).filter(Resume.user_id == user.id, Resume.is_online.is_(True)).first()
    if not r:
        r = Resume(id=uid("R-"), user_id=user.id, is_online=True, name=payload.get("name", ""), content={})
        db.add(r)
    r.content = payload
    r.name = payload.get("name", r.name)
    db.commit()
    return ok(payload)


@router.delete("/resumes/{resume_id}")
def delete_resume(resume_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.get(Resume, resume_id)
    if not r or r.user_id != user.id or r.is_online:
        raise HTTPException(status_code=404, detail="简历不存在")
    if r.file_url:
        p = settings.UPLOAD_DIR / Path(r.file_url).name
        if p.exists():
            try:
                p.unlink()
            except OSError:
                pass
    db.delete(r)
    db.commit()
    return ok([resume_dict(x) for x in _files(db, user)])
