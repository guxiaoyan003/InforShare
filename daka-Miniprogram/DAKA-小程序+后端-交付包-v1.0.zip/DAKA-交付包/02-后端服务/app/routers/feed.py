from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..constants import CATS, E_CATS
from ..db import get_db
from ..deps import get_current_user
from ..models import Company, Coop, Job, Post, User
from ..resp import ok, uid
from ..serializers import coop_dict, job_dict, post_dict

router = APIRouter(tags=["feed"])


@router.get("/categories")
def categories():
    return ok({"cats": CATS, "ecats": E_CATS})


@router.get("/jobs")
def list_jobs(
    cat: Optional[str] = None,
    city: Optional[str] = None,
    exp: Optional[str] = None,
    q: Optional[str] = None,
    limit: int = Query(default=200, le=500),
    db: Session = Depends(get_db),
):
    query = db.query(Job)
    if cat:
        query = query.filter(Job.cat == cat)
    if city:
        query = query.filter(Job.city == city)
    if exp:
        query = query.filter(Job.exp.like(exp + "%"))
    if q:
        like = "%" + q + "%"
        query = query.filter(or_(Job.title.like(like), Job.company.like(like), Job.city.like(like)))
    return ok([job_dict(j) for j in query.limit(limit).all()])


@router.get("/jobs/{job_id}")
def job_detail(job_id: str, db: Session = Depends(get_db)):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="职位不存在")
    return ok(job_dict(job))


@router.get("/coops")
def list_coops(
    cat: Optional[str] = None,
    city: Optional[str] = None,
    coop: Optional[str] = None,
    q: Optional[str] = None,
    limit: int = Query(default=100, le=500),
    db: Session = Depends(get_db),
):
    query = db.query(Coop)
    if cat:
        query = query.filter(Coop.cat == cat)
    if city:
        query = query.filter(Coop.city == city)
    if coop:
        query = query.filter(Coop.coop == coop)
    if q:
        like = "%" + q + "%"
        query = query.filter(or_(Coop.title.like(like), Coop.company_name.like(like), Coop.city.like(like)))
    return ok([coop_dict(c) for c in query.limit(limit).all()])


@router.get("/coops/{coop_id}")
def coop_detail(coop_id: str, db: Session = Depends(get_db)):
    coop = db.get(Coop, coop_id)
    if not coop:
        raise HTTPException(status_code=404, detail="合作需求不存在")
    return ok(coop_dict(coop))


class PostIn(BaseModel):
    kind: str
    data: dict
    ent: bool = False


@router.get("/posts")
def list_posts(kind: Optional[str] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = db.query(Company).filter(Company.owner_user_id == user.id).first()
    query = db.query(Post).filter(Post.owner_type == "personal", Post.owner_id == user.id)
    if kind:
        query = query.filter(Post.kind == kind)
    personal = [post_dict(p) for p in query.order_by(Post.created_at.desc()).all()]
    company_posts = []
    if company:
        cq = db.query(Post).filter(Post.owner_type == "company", Post.owner_id == company.id)
        if kind:
            cq = cq.filter(Post.kind == kind)
        company_posts = [post_dict(p) for p in cq.order_by(Post.created_at.desc()).all()]
    return ok({"personal": personal, "company": company_posts})


@router.get("/posts/{post_id}")
def post_detail(post_id: str, db: Session = Depends(get_db)):
    post = db.get(Post, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="发布内容不存在")
    return ok(post_dict(post))


@router.post("/posts")
def create_post(payload: PostIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = db.query(Company).filter(Company.owner_user_id == user.id).first()
    if payload.ent and not company:
        raise HTTPException(status_code=403, detail="请先完成企业认证")
    data = dict(payload.data or {})
    title = str(data.pop("title", "") or "").strip()
    if not title:
        raise HTTPException(status_code=400, detail="请填写标题")
    post = Post(
        id=uid("P-"),
        owner_type="company" if payload.ent else "personal",
        owner_id=company.id if payload.ent and company else user.id,
        kind=payload.kind,
        title=title,
        status="待审核",
        applies=0,
        time_text=data.pop("time", ""),
        payload=data,
    )
    db.add(post)
    db.commit()
    db.refresh(post)
    return ok(post_dict(post))
