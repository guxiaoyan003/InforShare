from typing import Optional

import requests
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..models import Company, User
from ..resp import ok, uid
from ..security import create_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginIn(BaseModel):
    phone: str
    password: Optional[str] = ""
    code: Optional[str] = ""
    mode: str = "pwd"
    role: str = "personal"


class WechatIn(BaseModel):
    code: str
    role: str = "personal"


@router.post("/login")
def login(payload: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.phone == payload.phone.strip()).first()
    if not user:
        raise HTTPException(status_code=404, detail="账号不存在，请先注册")
    if payload.mode == "pwd":
        if not verify_password(payload.password or "", user.password_hash or ""):
            raise HTTPException(status_code=400, detail="手机号或密码错误")
    else:
        if (payload.code or "").strip() != settings.DEMO_SMS_CODE:
            raise HTTPException(status_code=400, detail="验证码错误")
    token = create_token(user.id, payload.role)
    return ok({
        "token": token,
        "user": {"id": user.id, "name": user.name, "role": payload.role},
    })


@router.post("/wechat")
def wechat_login(payload: WechatIn, db: Session = Depends(get_db)):
    openid = ""
    if settings.WX_APPID and settings.WX_SECRET:
        try:
            resp = requests.get(
                "https://api.weixin.qq.com/sns/jscode2session",
                params={
                    "appid": settings.WX_APPID,
                    "secret": settings.WX_SECRET,
                    "js_code": payload.code,
                    "grant_type": "authorization_code",
                },
                timeout=8,
            )
            body = resp.json()
        except Exception:
            raise HTTPException(status_code=502, detail="微信登录服务不可用")
        openid = body.get("openid", "")
        if not openid:
            raise HTTPException(status_code=400, detail=body.get("errmsg", "微信登录失败"))
    elif settings.WX_MOCK_OPENID:
        openid = settings.WX_MOCK_OPENID
    else:
        raise HTTPException(status_code=400, detail="服务端未配置微信 AppID / Secret")

    user = db.query(User).filter(User.openid == openid).first()
    if not user:
        user = User(
            id=uid("u"),
            openid=openid,
            phone="wx_" + openid[:16],
            name="微信用户",
            role="personal",
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    token = create_token(user.id, payload.role)
    return ok({
        "token": token,
        "user": {"id": user.id, "name": user.name, "role": payload.role},
    })


class RegisterIn(BaseModel):
    phone: str
    password: str
    name: str = ""
    role: str = "personal"


@router.post("/register")
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.phone == payload.phone).first():
        raise HTTPException(status_code=400, detail="该手机号已注册")
    user = User(
        id=uid("u"),
        phone=payload.phone,
        password_hash=hash_password(payload.password),
        name=payload.name or "新用户",
        role=payload.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    token = create_token(user.id, payload.role)
    return ok({"token": token, "user": {"id": user.id, "name": user.name, "role": payload.role}})
