from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import get_current_user
from ..models import Company, CompanyApplication, CompanyCert, Post, User
from ..resp import ok
from ..serializers import cert_dict, company_application_dict, ent_dict, post_dict

router = APIRouter(prefix="/company", tags=["company"])


def _company(db: Session, user: User):
    company = db.query(Company).filter(Company.owner_user_id == user.id).first()
    if not company:
        raise HTTPException(status_code=403, detail="当前账号未关联企业")
    return company


def _cert(db: Session, company: Company):
    cert = db.query(CompanyCert).filter(CompanyCert.company_id == company.id).first()
    if not cert:
        cert = CompanyCert(id="cert-" + company.id, company_id=company.id, state=0, step=1, payload={}, logs=[])
        db.add(cert)
        db.commit()
        db.refresh(cert)
    return cert


@router.get("/profile")
def profile(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return ok(ent_dict(_company(db, user)))


@router.get("/cert")
def get_cert(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = _company(db, user)
    return ok(cert_dict(_cert(db, company)))


@router.post("/cert")
def submit_cert(payload: dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = _company(db, user)
    cert = _cert(db, company)
    cert.payload = payload
    cert.state = 1
    cert.step = 1
    cert.submit_at = datetime.now().strftime("%Y-%m-%d %H:%M")
    cert.logs = [
        {"t": "提交认证申请", "d": cert.submit_at + " · 提交主体信息、证照 2 份、对公开票信息", "s": "ok"},
        {"t": "平台审核中", "d": "当前节点：证照核验（预计 1 个工作日内完成）", "s": "on"},
    ]
    if payload.get("name"):
        company.name = str(payload["name"])[:128]
    if payload.get("code"):
        company.code = str(payload["code"])[:32]
        code = company.code
        company.code_mask = code[:12] + "****" + code[-4:] if len(code) > 16 else code
    if payload.get("type"):
        pass
    if payload.get("size"):
        company.size = str(payload["size"])[:32]
    if payload.get("contact"):
        company.admin = str(payload["contact"])[:32]
    if payload.get("contactTitle"):
        company.admin_title = str(payload["contactTitle"])[:64]
    if payload.get("mobile"):
        company.phone = str(payload["mobile"])[:32]
    if payload.get("email"):
        company.email = str(payload["email"])[:128]
    db.commit()
    return ok(cert_dict(cert))


@router.post("/cert/approve")
def approve_cert(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = _company(db, user)
    cert = _cert(db, company)
    cert.state = 2
    cert.pass_at = datetime.now().strftime("%Y-%m-%d %H:%M")
    logs = list(cert.logs or [])
    logs.append({"t": "平台审核通过", "d": cert.pass_at + " · 证照与工商信息一致", "s": "ok"})
    logs.append({"t": "认证生效", "d": "有效期 12 个月，到期前 30 天提醒续期", "s": "ok"})
    cert.logs = logs
    db.commit()
    return ok(cert_dict(cert))


@router.get("/posts")
def company_posts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = _company(db, user)
    rows = db.query(Post).filter(Post.owner_type == "company", Post.owner_id == company.id).order_by(Post.created_at.desc()).all()
    data = {}
    for p in rows:
        data.setdefault(p.kind, []).append(post_dict(p))
    return ok(data)


@router.get("/applications")
def company_applications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = _company(db, user)
    rows = (
        db.query(CompanyApplication)
        .filter(CompanyApplication.company_id == company.id)
        .order_by(CompanyApplication.created_at.desc())
        .all()
    )
    return ok([company_application_dict(a) for a in rows])
