from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import get_current_user
from ..models import Company, Message, User
from ..resp import ok
from ..serializers import message_dict

router = APIRouter(tags=["messages"])


def _scope_ids(db: Session, user: User):
    company = db.query(Company).filter(Company.owner_user_id == user.id).first()
    return user.id, (company.id if company else "")


@router.get("/messages")
def list_messages(scope: str = Query("personal"), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    uid_, cid = _scope_ids(db, user)
    q = db.query(Message).filter(Message.scope == scope)
    q = q.filter(Message.company_id == cid) if scope == "ent" else q.filter(Message.user_id == uid_)
    return ok([message_dict(m) for m in q.order_by(Message.created_at.desc()).all()])


@router.get("/messages/{message_id}")
def get_message(message_id: str, scope: str = Query("personal"), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    uid_, cid = _scope_ids(db, user)
    m = db.get(Message, message_id)
    if not m or m.scope != scope:
        raise HTTPException(status_code=404, detail="消息不存在")
    if scope == "ent" and m.company_id != cid:
        raise HTTPException(status_code=404, detail="消息不存在")
    if scope != "ent" and m.user_id != uid_:
        raise HTTPException(status_code=404, detail="消息不存在")
    return ok(message_dict(m))


@router.delete("/messages/{message_id}")
def delete_message(
    message_id: str,
    scope: str = Query("personal"),
    payload: Optional[dict] = Body(default=None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if payload and payload.get("scope"):
        scope = payload["scope"]
    uid_, cid = _scope_ids(db, user)
    m = db.get(Message, message_id)
    if not m or m.scope != scope:
        raise HTTPException(status_code=404, detail="消息不存在")
    if scope == "ent" and m.company_id != cid:
        raise HTTPException(status_code=404, detail="消息不存在")
    if scope != "ent" and m.user_id != uid_:
        raise HTTPException(status_code=404, detail="消息不存在")
    db.delete(m)
    db.commit()
    return ok({"id": message_id})
