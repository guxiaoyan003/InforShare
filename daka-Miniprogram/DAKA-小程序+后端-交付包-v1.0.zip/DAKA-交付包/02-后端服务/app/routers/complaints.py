from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import get_current_user
from ..models import Complaint, User
from ..resp import ok, uid
from ..serializers import complaint_dict

router = APIRouter(tags=["complaints"])


class ComplaintIn(BaseModel):
    obj: str
    type: str = "其他"
    desc: str = ""


def _list(db: Session, user: User):
    rows = (
        db.query(Complaint)
        .filter(Complaint.user_id == user.id)
        .order_by(Complaint.created_at.desc())
        .all()
    )
    return [complaint_dict(c) for c in rows]


@router.get("/complaints")
def list_complaints(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return ok(_list(db, user))


@router.post("/complaints")
def create_complaint(payload: ComplaintIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    c = Complaint(
        id=uid("CP-"),
        user_id=user.id,
        obj=payload.obj[:160],
        type=payload.type,
        desc_text=payload.desc or "（未填写）",
        status_text="处理中",
        status_cls="orange",
        time_text=datetime.now().strftime("%m-%d %H:%M"),
    )
    db.add(c)
    db.commit()
    return ok(_list(db, user))
