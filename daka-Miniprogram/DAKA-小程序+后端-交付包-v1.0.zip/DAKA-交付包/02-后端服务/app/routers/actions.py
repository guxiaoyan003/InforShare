from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import get_current_user
from ..models import (
    Application,
    Company,
    CompanyApplication,
    Coop,
    CoopApplication,
    Job,
    PostApplicant,
    User,
)
from ..resp import ok, uid
from ..serializers import application_dict, coop_application_dict

router = APIRouter(tags=["actions"])


class ApplyIn(BaseModel):
    channel: str = "online"
    cover: Optional[str] = ""


class CoopApplyIn(BaseModel):
    price: str = ""
    cycle: str = ""
    plan: str = ""


class DecisionIn(BaseModel):
    ok: bool = True


def now_text():
    from datetime import datetime

    return datetime.now().strftime("%m-%d %H:%M")


@router.post("/jobs/{job_id}/apply")
def apply_job(job_id: str, payload: ApplyIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="职位不存在")
    exists = db.query(Application).filter(Application.user_id == user.id, Application.job_id == job_id).first()
    if exists:
        return ok(application_dict(exists))
    app = Application(
        id=uid("A-"),
        user_id=user.id,
        job_id=job_id,
        obj_title=job.title,
        company_name=job.company,
        type="岗位投递",
        salary=job.salary,
        time_text=now_text(),
        status_text="已投递",
        status_cls="gray",
        feedback=payload.cover or "简历已送达，等待企业查看。",
        channel=payload.channel,
        cover=payload.cover or "",
    )
    db.add(app)
    db.commit()
    db.refresh(app)
    return ok(application_dict(app))


@router.post("/coops/{coop_id}/apply")
def apply_coop(coop_id: str, payload: CoopApplyIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    coop = db.get(Coop, coop_id)
    if not coop:
        raise HTTPException(status_code=404, detail="合作需求不存在")
    company = db.query(Company).filter(Company.owner_user_id == user.id).first()
    if not company:
        raise HTTPException(status_code=403, detail="请先完成企业认证")
    app = CoopApplication(
        id=uid("CA-"),
        company_id=company.id,
        coop_id=coop_id,
        obj_title=coop.title,
        company_name=coop.company_name,
        type="项目承接",
        salary="¥" + (payload.price or ""),
        time_text=now_text(),
        status_text="已投递",
        status_cls="gray",
        feedback=payload.plan or "方案已提交，等待企业查看。",
        price=payload.price,
        cycle=payload.cycle,
        plan=payload.plan,
    )
    coop.applies = (coop.applies or 0) + 1
    db.add(app)
    db.commit()
    db.refresh(app)
    return ok(coop_application_dict(app))


@router.post("/applicants/{applicant_id}/decision")
def decide_applicant(applicant_id: str, payload: DecisionIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.get(PostApplicant, applicant_id)
    if not a or a.owner_user_id != user.id:
        raise HTTPException(status_code=404, detail="申请不存在")
    a.status = 1 if payload.ok else 2
    db.commit()
    return ok({"id": a.id, "st": a.status})


@router.post("/company/applicants/{applicant_id}/decision")
def decide_company_applicant(applicant_id: str, payload: DecisionIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = db.query(Company).filter(Company.owner_user_id == user.id).first()
    a = db.get(CompanyApplication, applicant_id)
    if not a or not company or a.company_id != company.id:
        raise HTTPException(status_code=404, detail="申请不存在")
    a.status = 2 if payload.ok else 3
    db.commit()
    return ok({"id": a.id, "st": a.status})
