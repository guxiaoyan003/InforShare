from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..constants import CATS, E_CATS
from ..db import get_db
from ..deps import get_current_user
from ..models import (
    Application,
    CareerPlan,
    Company,
    CompanyApplication,
    CompanyCert,
    Complaint,
    Coop,
    CoopApplication,
    Job,
    Message,
    Post,
    PostApplicant,
    Resume,
    Talent,
    User,
)
from ..resp import ok
from ..serializers import (
    applicant_dict,
    application_dict,
    cert_dict,
    company_application_dict,
    complaint_dict,
    coop_application_dict,
    coop_dict,
    ent_dict,
    job_dict,
    me_dict,
    message_dict,
    plan_dict,
    post_dict,
    resume_dict,
    talent_dict,
)

router = APIRouter(tags=["bootstrap"])

POST_KINDS = ["consult", "project", "coach"]
E_POST_KINDS = ["job", "project", "consult", "train", "coach"]


def get_company(db: Session, user: User):
    return db.query(Company).filter(Company.owner_user_id == user.id).first()


@router.get("/bootstrap")
def bootstrap(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = get_company(db, user)

    jobs = db.query(Job).all()
    coops = db.query(Coop).all()
    talents = db.query(Talent).all()

    applied_coops = set()
    if company:
        applied_coops = {
            a.coop_id
            for a in db.query(CoopApplication).filter(CoopApplication.company_id == company.id).all()
        }
    coop_items = []
    for c in coops:
        item = coop_dict(c)
        item["applied"] = c.id in applied_coops
        coop_items.append(item)

    posts = {k: [] for k in POST_KINDS}
    for p in db.query(Post).filter(Post.owner_type == "personal", Post.owner_id == user.id).all():
        posts.setdefault(p.kind, []).append(post_dict(p))

    company_posts = {k: [] for k in E_POST_KINDS}
    if company:
        for p in db.query(Post).filter(Post.owner_type == "company", Post.owner_id == company.id).all():
            company_posts.setdefault(p.kind, []).append(post_dict(p))

    messages = [
        message_dict(m)
        for m in db.query(Message).filter(Message.scope == "personal", Message.user_id == user.id)
        .order_by(Message.created_at.desc()).all()
    ]
    company_messages = []
    if company:
        company_messages = [
            message_dict(m)
            for m in db.query(Message).filter(Message.scope == "ent", Message.company_id == company.id)
            .order_by(Message.created_at.desc()).all()
        ]

    applicants = [
        applicant_dict(a)
        for a in db.query(PostApplicant).filter(PostApplicant.owner_user_id == user.id)
        .order_by(PostApplicant.created_at.desc()).all()
    ]

    company_applicants = []
    if company:
        company_applicants = [
            company_application_dict(a)
            for a in db.query(CompanyApplication).filter(CompanyApplication.company_id == company.id)
            .order_by(CompanyApplication.created_at.desc()).all()
        ]

    my_applications = [
        application_dict(a)
        for a in db.query(Application).filter(Application.user_id == user.id)
        .order_by(Application.created_at.desc()).all()
    ]

    company_my_applications = []
    if company:
        company_my_applications = [
            coop_application_dict(a)
            for a in db.query(CoopApplication).filter(CoopApplication.company_id == company.id)
            .order_by(CoopApplication.created_at.desc()).all()
        ]

    online = db.query(Resume).filter(Resume.user_id == user.id, Resume.is_online.is_(True)).first()
    resume = {}
    if online:
        resume = dict(online.content or {})
        resume.update({"id": online.id, "name": online.name})
    files = [
        resume_dict(r)
        for r in db.query(Resume).filter(Resume.user_id == user.id, Resume.is_online.is_(False))
        .order_by(Resume.created_at.desc()).all()
    ]

    complaints = [
        complaint_dict(c)
        for c in db.query(Complaint).filter(Complaint.user_id == user.id)
        .order_by(Complaint.created_at.desc()).all()
    ]
    plans = [
        plan_dict(p)
        for p in db.query(CareerPlan).filter(CareerPlan.user_id == user.id)
        .order_by(CareerPlan.created_at.desc()).all()
    ]

    cert = db.query(CompanyCert).filter(CompanyCert.company_id == (company.id if company else "")).first()
    if not cert and company:
        cert = CompanyCert(id="cert-" + company.id, company_id=company.id, state=0, step=1, payload={}, logs=[])
        db.add(cert)
        db.commit()
        db.refresh(cert)

    applied = [a.job_id for a in db.query(Application).filter(Application.user_id == user.id).all() if a.job_id]

    return ok({
        "me": me_dict(user),
        "ent": ent_dict(company) if company else {},
        "cats": CATS,
        "ecats": E_CATS,
        "jobs": [job_dict(j) for j in jobs],
        "coops": coop_items,
        "posts": posts,
        "companyPosts": company_posts,
        "messages": messages,
        "companyMessages": company_messages,
        "applicants": applicants,
        "companyApplicants": company_applicants,
        "myApplications": my_applications,
        "companyMyApplications": company_my_applications,
        "resume": resume,
        "resumes": files,
        "complaints": complaints,
        "plans": plans,
        "talents": [talent_dict(t) for t in talents],
        "cert": cert_dict(cert) if cert else {"state": 0, "step": 1, "logs": []},
        "appliedJobs": applied,
    })


@router.get("/me")
def get_me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    company = get_company(db, user)
    return ok({"me": me_dict(user), "ent": ent_dict(company) if company else {}})


@router.put("/me")
def update_me(payload: dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if payload.get("name"):
        user.name = str(payload["name"])[:64]
    if payload.get("phone"):
        user.phone = str(payload["phone"])[:20]
    if "email" in payload:
        user.email = str(payload.get("email") or "")[:128]
    if payload.get("city"):
        user.city = str(payload["city"])[:32]
    if payload.get("state"):
        user.work_state = str(payload["state"])[:64]
    avatar = payload.get("avatar") or {}
    if avatar:
        user.avatar_kind = avatar.get("kind", user.avatar_kind)
        user.avatar_seed = avatar.get("seed", user.avatar_seed)
        user.avatar_src = avatar.get("src", user.avatar_src)
    db.commit()
    db.refresh(user)
    return ok(me_dict(user))
