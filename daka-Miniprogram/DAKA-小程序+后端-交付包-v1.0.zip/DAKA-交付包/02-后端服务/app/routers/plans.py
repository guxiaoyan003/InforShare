from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import get_current_user
from ..models import CareerPlan, User
from ..resp import ok, uid
from ..serializers import plan_dict

router = APIRouter(tags=["plans"])


def _list(db: Session, user: User):
    rows = (
        db.query(CareerPlan)
        .filter(CareerPlan.user_id == user.id)
        .order_by(CareerPlan.created_at.desc())
        .all()
    )
    return [plan_dict(p) for p in rows]


@router.get("/plans")
def list_plans(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return ok(_list(db, user))


@router.get("/plans/{plan_id}")
def plan_detail(plan_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = db.get(CareerPlan, plan_id)
    if not p or p.user_id != user.id:
        raise HTTPException(status_code=404, detail="记录不存在")
    return ok(plan_dict(p))


@router.post("/plans")
def create_plan(payload: dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    count = db.query(CareerPlan).filter(CareerPlan.user_id == user.id).count()
    p = CareerPlan(
        id="GE-%04d" % (count + 1),
        user_id=user.id,
        plan_no=count + 1,
        dir=payload.get("dir", "AI 产品经理"),
        weeks=int(payload.get("weeks", 12)),
        gaps=int(payload.get("gaps", 0)),
        actions=int(payload.get("actions", 0)),
        concl=payload.get("concl", ""),
        phases=payload.get("phases", []),
        next_steps=payload.get("next", []),
        at_text=datetime.now().strftime("%Y-%m-%d %H:%M"),
        rounds=int(payload.get("rounds", 3)),
    )
    db.add(p)
    db.commit()
    return ok(_list(db, user))
