from typing import Any


def ok(data: Any = None, message: str = "ok"):
    return {"code": 0, "message": message, "data": data}


def uid(prefix: str) -> str:
    import random
    import time

    return "%s%d%03d" % (prefix, int(time.time() * 1000), random.randint(0, 999))
