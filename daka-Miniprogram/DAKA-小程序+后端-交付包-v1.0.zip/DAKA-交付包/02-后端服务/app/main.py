import os

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import settings
from .db import Base, engine
from .routers import actions, auth, bootstrap, company, complaints, feed, messages, plans, resumes, talents

app = FastAPI(title=settings.APP_NAME, version="1.0.0", docs_url="/docs", redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/uploads", StaticFiles(directory=str(settings.UPLOAD_DIR)), name="uploads")


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"code": 1, "message": exc.detail, "data": None},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={"code": 1, "message": "参数校验失败", "data": exc.errors()},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"code": 1, "message": "服务器内部错误", "data": None},
    )


@app.get("/api/health")
def health():
    return {"code": 0, "message": "ok", "data": {"status": "up", "version": "1.0.0"}}


for router in (
    auth.router,
    bootstrap.router,
    feed.router,
    actions.router,
    messages.router,
    resumes.router,
    complaints.router,
    plans.router,
    company.router,
    talents.router,
):
    app.include_router(router, prefix="/api")


@app.on_event("startup")
def maybe_create_tables():
    if os.getenv("AUTO_INIT", "false").lower() == "true":
        Base.metadata.create_all(bind=engine)
