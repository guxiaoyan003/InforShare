"""
建表脚本：python -m app.initdb [--reset]
默认只创建缺失的表；--reset 会先删表再重建（仅用于开发环境）。
"""
import sys

from .db import Base, engine
from . import models  # noqa: F401  确保模型注册


def main():
    reset = "--reset" in sys.argv
    if reset:
        Base.metadata.drop_all(bind=engine)
        print("已删除旧表")
    Base.metadata.create_all(bind=engine)
    print("建表完成，共 %d 张表" % len(Base.metadata.tables))


if __name__ == "__main__":
    main()
