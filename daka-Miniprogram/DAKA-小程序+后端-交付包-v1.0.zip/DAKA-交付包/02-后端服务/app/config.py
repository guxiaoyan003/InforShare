"""
全局配置：全部通过环境变量 / .env 注入，代码里不写死任何地址与密钥。
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_env():
    env_file = BASE_DIR / ".env"
    if not env_file.exists():
        return
    for raw in env_file.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        os.environ.setdefault(k, v)


_load_env()


class Settings:
    APP_NAME = os.getenv("APP_NAME", "DAKA API")
    DEBUG = os.getenv("DEBUG", "false").lower() == "true"

    # mysql+pymysql://用户名:密码@主机:3306/库名?charset=utf8mb4
    DATABASE_URL = os.getenv(
        "DATABASE_URL",
        "mysql+pymysql://daka:daka@127.0.0.1:3306/daka?charset=utf8mb4",
    )
    DB_ECHO = os.getenv("DB_ECHO", "false").lower() == "true"

    JWT_SECRET = os.getenv("JWT_SECRET", "please-change-this-secret-in-production")
    JWT_ALG = "HS256"
    JWT_EXPIRE_DAYS = int(os.getenv("JWT_EXPIRE_DAYS", "30"))

    # 微信小程序（由部署同学在环境变量里配置）
    WX_APPID = os.getenv("WX_APPID", "")
    WX_SECRET = os.getenv("WX_SECRET", "")
    WX_MOCK_OPENID = os.getenv("WX_MOCK_OPENID", "")

    # 文件上传
    UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", str(BASE_DIR / "uploads")))
    UPLOAD_BASE_URL = os.getenv("UPLOAD_BASE_URL", "/uploads")
    MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "10"))

    CORS_ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",") if x.strip()]

    # 演示短信验证码（接入短信服务后由服务端校验）
    DEMO_SMS_CODE = os.getenv("DEMO_SMS_CODE", "123456")


settings = Settings()
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
