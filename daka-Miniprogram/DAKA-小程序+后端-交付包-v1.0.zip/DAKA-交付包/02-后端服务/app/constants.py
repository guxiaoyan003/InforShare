"""与小程序一致的静态字典"""

CATS = [
    {"key": "job", "name": "岗位招聘", "logo": "chart"},
    {"key": "project", "name": "项目外包", "logo": "layers"},
    {"key": "outstaff", "name": "岗位外包", "logo": "users"},
    {"key": "consult", "name": "数智化咨询", "logo": "compass"},
    {"key": "train", "name": "AI培训", "logo": "book"},
    {"key": "coach", "name": "AI私教", "logo": "spark"},
    {"key": "intern", "name": "AI实习", "logo": "rocket"},
]

E_CATS = [
    {"key": "project", "name": "项目外包", "logo": "layers"},
    {"key": "outstaff", "name": "岗位外包", "logo": "users"},
    {"key": "consult", "name": "数智化培训", "logo": "compass"},
    {"key": "train", "name": "AI培训", "logo": "book"},
]

CITIES = ["深圳", "广州", "杭州", "北京", "上海"]

EXP_OPTS = ["不限", "在校/应届", "1 年以下", "1–3 年", "3–5 年", "5–10 年", "10 年以上"]

EDU_OPTS = ["不限", "大专", "本科", "硕士", "博士"]

E_PUB_LABELS = {
    "job": "岗位",
    "project": "项目外包",
    "consult": "数智化咨询",
    "train": "AI培训",
    "coach": "AI私教",
}
