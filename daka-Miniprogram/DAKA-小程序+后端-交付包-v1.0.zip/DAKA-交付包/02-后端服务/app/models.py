from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    Index,
)
from sqlalchemy.orm import relationship

from .db import Base


def now():
    return datetime.now()


class User(Base):
    __tablename__ = "users"

    id = Column(String(32), primary_key=True)
    openid = Column(String(64), unique=True, index=True, nullable=True)
    phone = Column(String(20), unique=True, index=True, nullable=False)
    password_hash = Column(String(200), nullable=True)
    name = Column(String(64), default="")
    avatar_kind = Column(String(16), default="preset")
    avatar_seed = Column(String(64), default="")
    avatar_src = Column(String(512), default="")
    email = Column(String(128), default="")
    city = Column(String(32), default="")
    work_state = Column(String(64), default="")
    role = Column(String(16), default="personal")
    created_at = Column(DateTime, default=now)

    company = relationship("Company", back_populates="owner", uselist=False)


class Company(Base):
    __tablename__ = "companies"

    id = Column(String(32), primary_key=True)
    owner_user_id = Column(String(32), ForeignKey("users.id"), index=True)
    name = Column(String(128), default="")
    short_name = Column(String(64), default="")
    code = Column(String(32), default="")
    code_mask = Column(String(32), default="")
    city = Column(String(32), default="")
    industry = Column(String(64), default="")
    size = Column(String(32), default="")
    admin = Column(String(32), default="")
    admin_title = Column(String(64), default="")
    phone = Column(String(32), default="")
    email = Column(String(128), default="")
    created_at = Column(DateTime, default=now)

    owner = relationship("User", back_populates="company")


class Job(Base):
    __tablename__ = "jobs"

    id = Column(String(32), primary_key=True)
    cat = Column(String(24), index=True, nullable=False)
    logo = Column(String(24), default="chart")
    title = Column(String(128), nullable=False)
    company = Column(String(128), default="")
    salary = Column(String(32), default="")
    bonus = Column(String(32), default="")
    city = Column(String(32), index=True, default="")
    exp = Column(String(32), default="")
    date_text = Column(String(32), default="")
    type = Column(String(24), default="")
    tags = Column(JSON, default=list)
    edu = Column(String(24), default="")
    recruiter = Column(String(32), default="")
    recruiter_title = Column(String(64), default="")
    reply = Column(String(16), default="")
    openings = Column(String(16), default="")
    intro = Column(Text, default="")
    duties = Column(JSON, default=list)
    skills = Column(JSON, default=list)
    reqs = Column(JSON, default=list)
    plus = Column(JSON, default=list)
    created_at = Column(DateTime, default=now)


class Coop(Base):
    __tablename__ = "coops"

    id = Column(String(32), primary_key=True)
    cat = Column(String(24), index=True, nullable=False)
    title = Column(String(160), nullable=False)
    company_name = Column(String(128), default="")
    budget = Column(String(32), default="")
    cycle = Column(String(32), default="")
    city = Column(String(32), index=True, default="")
    coop = Column(String(24), default="")
    deadline = Column(String(32), default="")
    publish = Column(String(32), default="")
    tags = Column(JSON, default=list)
    publisher = Column(String(32), default="")
    publisher_title = Column(String(64), default="")
    applies = Column(Integer, default=0)
    status = Column(String(24), default="招募中")
    desc_text = Column(Text, default="")
    req_text = Column(Text, default="")
    accept = Column(Text, default="")
    created_at = Column(DateTime, default=now)


class Post(Base):
    """个人 / 企业发布的需求（岗位、项目、咨询、培训、私教）"""

    __tablename__ = "posts"

    id = Column(String(32), primary_key=True)
    owner_type = Column(String(16), index=True, default="personal")  # personal / company
    owner_id = Column(String(32), index=True, default="")
    kind = Column(String(24), index=True, default="consult")
    title = Column(String(160), default="")
    status = Column(String(24), default="待审核")
    applies = Column(Integer, default=0)
    time_text = Column(String(32), default="")
    payload = Column(JSON, default=dict)
    created_at = Column(DateTime, default=now)


class Application(Base):
    """个人投递岗位"""

    __tablename__ = "applications"

    id = Column(String(32), primary_key=True)
    user_id = Column(String(32), index=True)
    job_id = Column(String(32), index=True, default="")
    obj_title = Column(String(160), default="")
    company_name = Column(String(128), default="")
    type = Column(String(24), default="岗位投递")
    salary = Column(String(32), default="")
    time_text = Column(String(32), default="")
    status_text = Column(String(24), default="已投递")
    status_cls = Column(String(16), default="gray")
    feedback = Column(Text, default="")
    channel = Column(String(24), default="online")
    cover = Column(Text, default="")
    created_at = Column(DateTime, default=now)


class PostApplicant(Base):
    """个人发布收到的申请"""

    __tablename__ = "post_applicants"

    id = Column(String(32), primary_key=True)
    owner_user_id = Column(String(32), index=True)
    post_id = Column(String(32), index=True, default="")
    who = Column(String(64), default="")
    dir = Column(String(64), default="")
    msg = Column(Text, default="")
    type = Column(String(32), default="")
    status = Column(Integer, default=0)  # 0待处理 1已同意 2已拒绝
    time_text = Column(String(32), default="")
    created_at = Column(DateTime, default=now)


class CoopApplication(Base):
    """企业申请承接（我的申请）"""

    __tablename__ = "coop_applications"

    id = Column(String(32), primary_key=True)
    company_id = Column(String(32), index=True)
    coop_id = Column(String(32), index=True, default="")
    obj_title = Column(String(160), default="")
    company_name = Column(String(128), default="")
    type = Column(String(32), default="项目承接")
    salary = Column(String(32), default="")
    time_text = Column(String(32), default="")
    status_text = Column(String(24), default="已投递")
    status_cls = Column(String(16), default="gray")
    feedback = Column(Text, default="")
    price = Column(String(32), default="")
    cycle = Column(String(32), default="")
    plan = Column(Text, default="")
    created_at = Column(DateTime, default=now)


class CompanyApplication(Base):
    """企业收到的申请"""

    __tablename__ = "company_applications"

    id = Column(String(32), primary_key=True)
    company_id = Column(String(32), index=True)
    post_id = Column(String(32), index=True, default="")
    who = Column(String(64), default="")
    dir = Column(String(64), default="")
    obj = Column(String(160), default="")
    type = Column(String(32), default="")
    msg = Column(Text, default="")
    status = Column(Integer, default=1)  # 1待处理 2已同意 3已拒绝
    time_text = Column(String(32), default="")
    created_at = Column(DateTime, default=now)


class Message(Base):
    __tablename__ = "messages"

    id = Column(String(32), primary_key=True)
    scope = Column(String(16), index=True, default="personal")  # personal / ent
    user_id = Column(String(32), index=True, nullable=True)
    company_id = Column(String(32), index=True, nullable=True)
    name = Column(String(64), default="")
    role = Column(String(64), default="")
    time_text = Column(String(32), default="")
    kind = Column(String(24), default="reply")
    preview = Column(Text, default="")
    body = Column(Text, default="")
    rel_id = Column(String(32), default="")
    rel_type = Column(String(24), default="")
    ap_id = Column(String(32), default="")
    av = Column(String(24), default="")
    created_at = Column(DateTime, default=now)


class Resume(Base):
    __tablename__ = "resumes"

    id = Column(String(32), primary_key=True)
    user_id = Column(String(32), index=True)
    is_online = Column(Boolean, default=False)
    name = Column(String(160), default="")
    time_text = Column(String(32), default="")
    size_text = Column(String(32), default="")
    file_url = Column(String(512), default="")
    content = Column(JSON, default=dict)
    created_at = Column(DateTime, default=now)


class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(String(32), primary_key=True)
    user_id = Column(String(32), index=True)
    obj = Column(String(160), default="")
    type = Column(String(32), default="")
    desc_text = Column(Text, default="")
    status_text = Column(String(24), default="处理中")
    status_cls = Column(String(16), default="orange")
    time_text = Column(String(32), default="")
    created_at = Column(DateTime, default=now)


class CareerPlan(Base):
    __tablename__ = "career_plans"

    id = Column(String(32), primary_key=True)
    user_id = Column(String(32), index=True)
    plan_no = Column(Integer, default=1)
    dir = Column(String(64), default="")
    weeks = Column(Integer, default=12)
    gaps = Column(Integer, default=0)
    actions = Column(Integer, default=0)
    concl = Column(Text, default="")
    phases = Column(JSON, default=list)
    next_steps = Column(JSON, default=list)
    at_text = Column(String(32), default="")
    rounds = Column(Integer, default=3)
    created_at = Column(DateTime, default=now)


class Talent(Base):
    __tablename__ = "talents"

    id = Column(String(32), primary_key=True)
    name = Column(String(64), default="")
    dir = Column(String(64), default="")
    years = Column(String(24), default="")
    city = Column(String(32), default="")
    edu = Column(String(24), default="")
    work_state = Column(String(64), default="")
    salary = Column(String(32), default="")
    match_score = Column(Integer, default=0)
    skills = Column(JSON, default=list)
    intro = Column(Text, default="")
    works = Column(JSON, default=list)
    projects = Column(JSON, default=list)
    created_at = Column(DateTime, default=now)


class CompanyCert(Base):
    __tablename__ = "company_certs"

    id = Column(String(32), primary_key=True)
    company_id = Column(String(32), index=True, unique=True)
    state = Column(Integer, default=0)  # 0未认证 1审核中 2已认证
    step = Column(Integer, default=1)
    payload = Column(JSON, default=dict)
    logs = Column(JSON, default=list)
    submit_at = Column(String(32), default="")
    pass_at = Column(String(32), default="")
    reject_reason = Column(Text, default="")
    updated_at = Column(DateTime, default=now, onupdate=now)


Index("ix_jobs_cat_city", Job.cat, Job.city)
Index("ix_coops_cat_city", Coop.cat, Coop.city)
