"""ORM -> 前端 JSON 结构（字段名与小程序完全对齐）"""


def me_dict(user):
    return {
        "name": user.name,
        "phone": user.phone,
        "email": user.email,
        "city": user.city,
        "state": user.work_state,
        "avatar": {
            "kind": user.avatar_kind or "preset",
            "seed": user.avatar_seed or user.name,
            "src": user.avatar_src or "",
        },
    }


def ent_dict(company):
    return {
        "name": company.name,
        "short": company.short_name,
        "code": company.code,
        "codeMask": company.code_mask,
        "city": company.city,
        "industry": company.industry,
        "size": company.size,
        "admin": company.admin,
        "adminTitle": company.admin_title,
        "phone": company.phone,
        "email": company.email,
    }


def job_dict(job):
    return {
        "id": job.id,
        "cat": job.cat,
        "logo": job.logo,
        "title": job.title,
        "company": job.company,
        "salary": job.salary,
        "bonus": job.bonus,
        "city": job.city,
        "exp": job.exp,
        "date": job.date_text,
        "type": job.type,
        "tags": job.tags or [],
        "edu": job.edu,
        "recruiter": job.recruiter,
        "recruiterTitle": job.recruiter_title,
        "reply": job.reply,
        "openings": job.openings,
        "intro": job.intro,
        "duties": job.duties or [],
        "skills": job.skills or [],
        "reqs": job.reqs or [],
        "plus": job.plus or [],
    }


def coop_dict(coop):
    return {
        "id": coop.id,
        "cat": coop.cat,
        "title": coop.title,
        "company": coop.company_name,
        "budget": coop.budget,
        "cycle": coop.cycle,
        "city": coop.city,
        "coop": coop.coop,
        "deadline": coop.deadline,
        "publish": coop.publish,
        "tags": coop.tags or [],
        "publisher": coop.publisher,
        "publisherTitle": coop.publisher_title,
        "applies": coop.applies,
        "status": coop.status,
        "desc": coop.desc_text,
        "req": coop.req_text,
        "accept": coop.accept,
    }


def post_dict(post):
    data = dict(post.payload or {})
    data.update({
        "id": post.id,
        "cat": post.kind,
        "title": post.title,
        "status": post.status,
        "applies": post.applies,
        "time": post.time_text,
    })
    return data


def message_dict(msg):
    return {
        "id": msg.id,
        "name": msg.name,
        "role": msg.role,
        "time": msg.time_text,
        "kind": msg.kind,
        "preview": msg.preview,
        "body": msg.body,
        "relId": msg.rel_id,
        "relType": msg.rel_type,
        "apId": msg.ap_id,
        "av": msg.av,
    }


def applicant_dict(a):
    return {
        "id": a.id,
        "objId": a.post_id,
        "who": a.who,
        "dir": a.dir,
        "msg": a.msg,
        "type": a.type,
        "time": a.time_text,
        "st": a.status,
    }


def application_dict(a):
    return {
        "id": a.id,
        "obj": a.obj_title,
        "co": a.company_name,
        "type": a.type,
        "salary": a.salary,
        "time": a.time_text,
        "st": a.status_text,
        "stc": a.status_cls,
        "fb": a.feedback,
    }


def coop_application_dict(a):
    return {
        "id": a.id,
        "obj": a.obj_title,
        "co": a.company_name,
        "type": a.type,
        "salary": a.salary,
        "time": a.time_text,
        "st": a.status_text,
        "stc": a.status_cls,
        "fb": a.feedback,
    }


def company_application_dict(a):
    return {
        "id": a.id,
        "who": a.who,
        "dir": a.dir,
        "obj": a.obj,
        "type": a.type,
        "time": a.time_text,
        "msg": a.msg,
        "st": a.status,
    }


def resume_dict(r):
    return {
        "id": r.id,
        "name": r.name,
        "time": r.time_text,
        "size": r.size_text,
        "fileUrl": r.file_url,
        "content": r.content or {},
    }


def complaint_dict(c):
    return {
        "obj": c.obj,
        "type": c.type,
        "desc": c.desc_text,
        "time": c.time_text,
        "st": c.status_text,
        "stc": c.status_cls,
    }


def plan_dict(p):
    return {
        "id": p.id,
        "at": p.at_text,
        "rounds": p.rounds,
        "dir": p.dir,
        "weeks": p.weeks,
        "gaps": p.gaps,
        "actions": p.actions,
        "concl": p.concl,
        "phases": p.phases or [],
        "next": p.next_steps or [],
    }


def talent_dict(t):
    return {
        "id": t.id,
        "name": t.name,
        "dir": t.dir,
        "years": t.years,
        "city": t.city,
        "edu": t.edu,
        "state": t.work_state,
        "salary": t.salary,
        "match": t.match_score,
        "skills": t.skills or [],
        "intro": t.intro,
        "works": t.works or [],
        "projects": t.projects or [],
    }


def cert_dict(cert):
    p = cert.payload or {}
    return {
        "state": cert.state,
        "step": cert.step,
        "name": p.get("name", ""),
        "code": p.get("code", ""),
        "type": p.get("type", ""),
        "year": p.get("year", ""),
        "size": p.get("size", ""),
        "addr": p.get("addr", ""),
        "site": p.get("site", ""),
        "scope": p.get("scope", ""),
        "lic": p.get("lic", ""),
        "legal": p.get("legal", ""),
        "legalId": p.get("legalId", ""),
        "authFile": p.get("authFile", ""),
        "contact": p.get("contact", ""),
        "contactTitle": p.get("contactTitle", ""),
        "mobile": p.get("mobile", ""),
        "email": p.get("email", ""),
        "invoice": p.get("invoice", {}),
        "logs": cert.logs or [],
        "submitAt": cert.submit_at,
        "passAt": cert.pass_at,
    }
