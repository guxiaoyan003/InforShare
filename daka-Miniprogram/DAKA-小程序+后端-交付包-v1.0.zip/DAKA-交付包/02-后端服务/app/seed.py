"""
演示数据导入：python -m app.seed [--reset]

数据来源 seed_data.json（由产品 Demo 导出，字段与小程序完全一致），
部署到生产前请按需替换为企业真实数据。
"""
import json
import sys
from pathlib import Path

from .db import Base, SessionLocal, engine
from .models import (
    Application,
    CareerPlan,
    Company,
    CompanyApplication,
    CompanyCert,
    Complaint,
    Coop,
    CoopApplication,
    Job,
    Message,
    Post,
    PostApplicant,
    Resume,
    Talent,
    User,
)
from .security import hash_password

BASE_DIR = Path(__file__).resolve().parent.parent
SEED_FILE = BASE_DIR / "seed_data.json"

USER_ID = "u-1"
COMPANY_ID = "c-1"


def load():
    with SEED_FILE.open("r", encoding="utf-8") as f:
        return json.load(f)


def seed(reset=False):
    data = load()
    if reset:
        Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        if db.query(User).count() > 0:
            print("数据库已有数据，跳过导入。需要重建请使用 --reset")
            return

        me = data["ME"]
        ent = data["ENT"]
        user = User(
            id=USER_ID,
            phone=me["phone"].replace(" ", ""),
            password_hash=hash_password("123456"),
            name=me["name"],
            email=me.get("email", ""),
            city=me.get("city", ""),
            work_state=me.get("state", ""),
            avatar_kind=(me.get("avatar") or {}).get("kind", "preset"),
            avatar_seed=(me.get("avatar") or {}).get("seed", me["name"]),
            avatar_src=(me.get("avatar") or {}).get("src", ""),
            role="personal",
        )
        db.add(user)

        company = Company(
            id=COMPANY_ID,
            owner_user_id=USER_ID,
            name=ent["name"],
            short_name=ent.get("short", ""),
            code=ent.get("code", ""),
            code_mask=ent.get("codeMask", ""),
            city=ent.get("city", ""),
            industry=ent.get("industry", ""),
            size=ent.get("size", ""),
            admin=ent.get("admin", ""),
            admin_title=ent.get("adminTitle", ""),
            phone=ent.get("phone", ""),
            email=ent.get("email", ""),
        )
        db.add(company)

        # 职位
        for j in data["JOBS"]:
            db.add(Job(
                id=j["id"], cat=j["cat"], logo=j.get("logo", "chart"), title=j["title"],
                company=j.get("company", ""), salary=j.get("salary", ""), bonus=j.get("bonus", ""),
                city=j.get("city", ""), exp=j.get("exp", ""), date_text=j.get("date", ""),
                type=j.get("type", ""), tags=j.get("tags", []), edu=j.get("edu", ""),
                recruiter=j.get("recruiter", ""), recruiter_title=j.get("recruiterTitle", ""),
                reply=j.get("reply", ""), openings=j.get("openings", ""), intro=j.get("intro", ""),
                duties=j.get("duties", []), skills=j.get("skills", []), reqs=j.get("reqs", []),
                plus=j.get("plus", []),
            ))

        # 合作需求
        for c in data["E_COOPS"]:
            db.add(Coop(
                id=c["id"], cat=c["cat"], title=c["title"], company_name=c.get("company", ""),
                budget=c.get("budget", ""), cycle=c.get("cycle", ""), city=c.get("city", ""),
                coop=c.get("coop", ""), deadline=c.get("deadline", ""), publish=c.get("publish", ""),
                tags=c.get("tags", []), publisher=c.get("publisher", ""),
                publisher_title=c.get("publisherTitle", ""), applies=c.get("applies", 0),
                status=c.get("status", "招募中"), desc_text=c.get("desc", ""),
                req_text=c.get("req", ""), accept=c.get("accept", ""),
            ))

        # 牛人库
        for t in data["E_TALENTS"]:
            db.add(Talent(
                id=t["id"], name=t["name"], dir=t.get("dir", ""), years=t.get("years", ""),
                city=t.get("city", ""), edu=t.get("edu", ""), work_state=t.get("state", ""),
                salary=t.get("salary", ""), match_score=t.get("match", 0),
                skills=t.get("skills", []), intro=t.get("intro", ""),
                works=t.get("works", []), projects=t.get("projects", []),
            ))

        # 个人发布
        for kind, items in data["MY_PUB"].items():
            for it in items:
                payload = {k: v for k, v in it.items() if k not in ("id", "title", "status", "applies", "time")}
                db.add(Post(
                    id=it["id"], owner_type="personal", owner_id=USER_ID, kind=kind,
                    title=it["title"], status=it.get("status", "待审核"),
                    applies=it.get("applies", 0), time_text=it.get("time", ""), payload=payload,
                ))

        # 企业发布
        for kind, items in data["E_PUB"].items():
            for it in items:
                payload = {k: v for k, v in it.items() if k not in ("id", "title", "status", "applies", "time")}
                db.add(Post(
                    id=it["id"], owner_type="company", owner_id=COMPANY_ID, kind=kind,
                    title=it["title"], status=it.get("status", "待审核"),
                    applies=it.get("applies", 0), time_text=it.get("time", ""), payload=payload,
                ))

        # 消息
        for m in data["MSGS"]:
            db.add(Message(
                id=m["id"], scope="personal", user_id=USER_ID, name=m["name"], role=m.get("role", ""),
                time_text=m.get("time", ""), kind=m.get("kind", "reply"), preview=m.get("preview", ""),
                body=m.get("body", ""), rel_id=m.get("relId", "") or "",
                ap_id=m.get("apId", "") or "", av=m.get("av", "") or "",
            ))
        for m in data["E_MSGS"]:
            db.add(Message(
                id=m["id"], scope="ent", company_id=COMPANY_ID, name=m["name"], role=m.get("role", ""),
                time_text=m.get("time", ""), kind=m.get("kind", "reply"), preview=m.get("preview", ""),
                body=m.get("body", ""), rel_id=m.get("relId", "") or "", rel_type=m.get("relType", "") or "",
                ap_id=m.get("apId", "") or "", av=m.get("av", "") or "",
            ))

        # 收到的申请（个人发布）
        for a in data["APPLICANTS"]:
            db.add(PostApplicant(
                id=a["id"], owner_user_id=USER_ID, post_id=a.get("objId", ""), who=a.get("who", ""),
                dir=a.get("dir", ""), msg=a.get("msg", ""), type=a.get("type", ""),
                status=a.get("st", 0), time_text=a.get("time", ""),
            ))

        # 我投递的岗位
        for a in data["MY_APPLIES"]:
            db.add(Application(
                id="A-" + a["obj"][:6], user_id=USER_ID, job_id="", obj_title=a["obj"],
                company_name=a.get("co", ""), type=a.get("type", "岗位投递"),
                salary=a.get("salary", ""), time_text=a.get("time", ""),
                status_text=a.get("st", "已投递"), status_cls=a.get("stc", "gray"),
                feedback=a.get("fb", ""),
            ))

        # 企业收到的申请
        for a in data["E_APPLIES"]:
            db.add(CompanyApplication(
                id=a["id"], company_id=COMPANY_ID, post_id="", who=a.get("who", ""),
                dir=a.get("dir", ""), obj=a.get("obj", ""), type=a.get("type", ""),
                msg=a.get("msg", ""), status=a.get("st", 1), time_text=a.get("time", ""),
            ))

        # 企业承接申请
        for a in data["E_MY_APPLIES"]:
            db.add(CoopApplication(
                id="CA-" + a["obj"][:6], company_id=COMPANY_ID, coop_id="",
                obj_title=a["obj"], company_name=a.get("co", ""), type=a.get("type", "项目承接"),
                salary=a.get("salary", ""), time_text=a.get("time", ""),
                status_text=a.get("st", "已投递"), status_cls=a.get("stc", "gray"),
                feedback=a.get("fb", ""),
            ))

        # 在线简历 + 附件
        online = dict(data["ONLINE_RESUME"])
        db.add(Resume(
            id="R-online", user_id=USER_ID, is_online=True, name=online.get("name", ""),
            time_text="2026-10-08 14:20", size_text="1.2 MB", content=online,
        ))
        for r in data["RESUMES"]:
            db.add(Resume(
                id=r["id"], user_id=USER_ID, is_online=False, name=r["name"],
                time_text=r.get("time", ""), size_text=r.get("size", ""),
            ))

        # 投诉
        for c in data["COMPLAINTS"]:
            db.add(Complaint(
                id="CP-" + c["obj"][:6], user_id=USER_ID, obj=c["obj"], type=c.get("type", ""),
                desc_text=c.get("desc", ""), status_text=c.get("st", "处理中"),
                status_cls=c.get("stc", "orange"), time_text=c.get("time", ""),
            ))

        # 职业规划历史
        for p in data["GW_HISTORY"]:
            db.add(CareerPlan(
                id=p["id"], user_id=USER_ID, plan_no=int(p["id"].split("-")[-1]),
                dir=p.get("dir", ""), weeks=p.get("weeks", 12), gaps=p.get("gaps", 0),
                actions=p.get("actions", 0), concl=p.get("concl", ""),
                phases=p.get("phases", []), next_steps=p.get("next", []),
                at_text=p.get("at", ""), rounds=p.get("rounds", 3),
            ))

        # 企业认证
        cert = data["ENT_CERT"]
        payload = {
            "name": cert.get("name"), "code": cert.get("code"), "type": cert.get("type"),
            "year": cert.get("year"), "size": cert.get("size"), "addr": cert.get("addr"),
            "site": cert.get("site"), "scope": cert.get("scope"), "lic": cert.get("lic"),
            "legal": cert.get("legal"), "legalId": cert.get("legalId"),
            "authFile": cert.get("authFile"), "contact": cert.get("contact"),
            "contactTitle": cert.get("contactTitle"), "mobile": cert.get("mobile"),
            "email": cert.get("email"), "invoice": cert.get("invoice", {}),
        }
        db.add(CompanyCert(
            id="cert-" + COMPANY_ID, company_id=COMPANY_ID, state=cert.get("state", 0),
            step=cert.get("step", 1), payload=payload, logs=cert.get("logs", []),
            submit_at=cert.get("submitAt", ""), pass_at=cert.get("passAt", ""),
        ))

        db.commit()
        print("演示数据导入完成：用户 %s / 企业 %s" % (user.phone, company.name))
        print("登录账号：%s  密码：123456" % user.phone)
    finally:
        db.close()


if __name__ == "__main__":
    seed(reset="--reset" in sys.argv)
