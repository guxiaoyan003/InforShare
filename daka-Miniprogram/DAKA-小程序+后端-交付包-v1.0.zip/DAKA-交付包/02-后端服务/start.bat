@echo off
cd /d %~dp0
if "%PORT%"=="" set PORT=8000
uvicorn app.main:app --host 0.0.0.0 --port %PORT%
