# DAKA 后端服务（FastAPI + MySQL）

大咖 DAKA 小程序双端（个人端 / 企业端）的后端实现。接口返回统一信封：

```json
{ "code": 0, "message": "ok", "data": {} }
```

`code != 0` 时 `message` 为可直接展示的中文提示。

---

## 1. 环境要求

| 项 | 版本 |
| --- | --- |
| Python | 3.10+（3.9 亦可） |
| MySQL | 5.7+ / 8.0，字符集 `utf8mb4` |
| 依赖 | 见 `requirements.txt` |

---

## 2. 目录结构

```
02-后端服务/
├── app/
│   ├── main.py            # FastAPI 入口、CORS、统一异常
│   ├── config.py          # 全部配置来自 .env / 环境变量
│   ├── db.py              # SQLAlchemy 引擎与会话
│   ├── models.py          # 15 张表的 ORM 定义
│   ├── serializers.py     # ORM -> 小程序 JSON 字段映射
│   ├── security.py        # PBKDF2 密码、JWT
│   ├── deps.py            # 登录态依赖
│   ├── initdb.py          # 建表
│   ├── seed.py            # 演示数据导入
│   └── routers/           # auth / bootstrap / feed / actions / ...
├── sql/schema.sql         # 建表 SQL（与模型一致，可直接执行）
├── seed_data.json         # 演示数据（105 岗位 / 32 合作需求 / 7 牛人）
├── requirements.txt
├── .env.example
└── start.sh / start.bat
```

---

## 3. 部署步骤

### 3.1 建库

```sql
CREATE DATABASE daka DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

### 3.2 安装依赖

```bash
cd 02-后端服务
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3.3 配置 .env

```bash
cp .env.example .env
```

必填项（由负责环境的同学填写）：

```
DATABASE_URL=mysql+pymysql://用户名:密码@数据库内网地址:3306/daka?charset=utf8mb4
JWT_SECRET=32位以上随机字符串
WX_APPID=小程序AppID
WX_SECRET=小程序AppSecret
```

> `WX_SECRET` 只能放在服务端，不要写进小程序代码。

### 3.4 建表 + 导入演示数据

方式一（推荐，可重复执行建表）：

```bash
python -m app.initdb
python -m app.seed
```

方式二（DBA 直接执行 SQL）：

```bash
mysql -u用户名 -p daka < sql/schema.sql
python -m app.seed        # 仍需要执行一次，导入演示数据
```

重建（会清空数据，仅开发环境）：

```bash
python -m app.initdb --reset
python -m app.seed
```

导入完成后会打印演示账号：`13800136688 / 123456`。

### 3.5 启动

```bash
# 开发
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

# 生产（多进程，端口按运维规范调整）
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

健康检查：`GET /api/health`；接口文档：`/docs`（生产可关）。

### 3.6 Nginx 反向代理（示例）

```nginx
server {
    listen 443 ssl;
    server_name api.example.com;

    ssl_certificate     /etc/nginx/cert/api.example.com.pem;
    ssl_certificate_key /etc/nginx/cert/api.example.com.key;

    client_max_body_size 12m;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /uploads/ {
        alias /srv/daka/uploads/;
    }
}
```

### 3.7 微信侧配置

1. `微信公众平台 → 开发管理 → 开发设置 → 服务器域名`，把 `https://api.example.com` 加入 **request 合法域名** 与 **uploadFile 合法域名**（必须是 HTTPS、已备案域名）。
2. 小程序端 `utils/config.js` 改：

```js
USE_MOCK: false,
API_BASE: 'https://api.example.com/api'
```

---

## 4. 接口清单

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/auth/login` | 手机号 + 密码 / 验证码登录 |
| POST | `/api/auth/wechat` | 微信 `code2session` 登录 |
| POST | `/api/auth/register` | 注册（可选） |
| GET | `/api/bootstrap` | 首屏聚合数据（一次拿全） |
| GET | `/api/me` / `PUT /api/me` | 个人资料 |
| GET | `/api/jobs` / `/api/jobs/{id}` | 职位列表 / 详情 |
| POST | `/api/jobs/{id}/apply` | 投递职位 |
| GET | `/api/coops` / `/api/coops/{id}` | 企业合作需求 |
| POST | `/api/coops/{id}/apply` | 申请承接 |
| GET/POST | `/api/posts` | 我的发布 / 发布需求（个人或企业） |
| POST | `/api/applicants/{id}/decision` | 同意 / 拒绝申请人（个人） |
| POST | `/api/company/applicants/{id}/decision` | 同意 / 拒绝申请人（企业） |
| GET | `/api/messages?scope=` | 消息列表 |
| DELETE | `/api/messages/{id}` | 删除消息（body 带 `scope`） |
| GET/POST | `/api/resumes` | 简历附件列表 / 上传（multipart，字段名 `file`） |
| GET | `/api/resume` | 在线简历 |
| GET/POST | `/api/complaints` | 投诉记录 / 提交投诉 |
| GET/POST | `/api/plans` | 职业规划历史 / 保存 |
| GET/POST | `/api/company/cert` | 企业认证信息 / 提交认证 |
| POST | `/api/company/cert/approve` | 模拟审核通过（演示用，接真实审核后删除） |
| GET | `/api/company/posts` | 企业发布列表 |
| GET | `/api/company/applications` | 企业收到的申请 |
| GET | `/api/talents` / `/api/talents/{id}` | 牛人库 |

除登录、健康检查外，都需要请求头：

```
Authorization: Bearer <token>
```

---

## 5. 数据表

| 表 | 说明 |
| --- | --- |
| users | 账号（手机号 / openid / 密码 / 资料 / 头像） |
| companies | 企业主体（与 users 一对一） |
| jobs | 岗位（7 个分类共 105 条演示数据） |
| coops | 企业合作需求（项目 / 岗位外包 / 咨询 / 培训） |
| posts | 个人与企业发布的需求（5 类） |
| applications | 个人投递岗位记录 |
| post_applicants | 个人发布收到的申请 |
| coop_applications | 企业承接申请 |
| company_applications | 企业收到的申请 |
| messages | 消息（personal / ent 两个作用域） |
| resumes | 在线简历 + 附件简历 |
| complaints | 投诉 |
| career_plans | 职业规划历史 |
| talents | 牛人库 |
| company_certs | 企业认证状态与材料 |

建表语句见 `sql/schema.sql`。

---

## 6. 安全与上线注意事项

- `JWT_SECRET` 必须替换，且不要提交到代码仓库。
- 演示账号密码 `123456` 仅用于验收，上线前删除或强制改密。
- `/api/company/cert/approve` 是演示用“模拟审核”，接入真实审核流程后应下线。
- 文件上传已限制扩展名与大小；生产建议接对象存储（OSS/COS），把 `UPLOAD_BASE_URL` 换成 CDN 域名。
- 短信验证码当前固定为 `DEMO_SMS_CODE`（默认 123456），接入短信服务后改为服务端校验。
- AI 职业规划当前为 Demo 脚本流程，未接大模型；接入位置见 `README` 顶部说明。
