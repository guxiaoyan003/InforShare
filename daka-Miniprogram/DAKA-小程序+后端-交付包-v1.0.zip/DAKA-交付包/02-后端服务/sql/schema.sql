-- DAKA 大咖 · MySQL 建表脚本（由 SQLAlchemy 模型生成）
-- 字符集必须 utf8mb4；MySQL 5.7+ / 8.0
-- 执行：mysql -u用户 -p 库名 < sql/schema.sql
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE users (
	id VARCHAR(32) NOT NULL, 
	openid VARCHAR(64), 
	phone VARCHAR(20) NOT NULL, 
	password_hash VARCHAR(200), 
	name VARCHAR(64), 
	avatar_kind VARCHAR(16), 
	avatar_seed VARCHAR(64), 
	avatar_src VARCHAR(512), 
	email VARCHAR(128), 
	city VARCHAR(32), 
	work_state VARCHAR(64), 
	`role` VARCHAR(16), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_users_openid ON users (openid);
CREATE UNIQUE INDEX ix_users_phone ON users (phone);

CREATE TABLE companies (
	id VARCHAR(32) NOT NULL, 
	owner_user_id VARCHAR(32), 
	name VARCHAR(128), 
	short_name VARCHAR(64), 
	code VARCHAR(32), 
	code_mask VARCHAR(32), 
	city VARCHAR(32), 
	industry VARCHAR(64), 
	size VARCHAR(32), 
	`admin` VARCHAR(32), 
	admin_title VARCHAR(64), 
	phone VARCHAR(32), 
	email VARCHAR(128), 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(owner_user_id) REFERENCES users (id)
);
CREATE INDEX ix_companies_owner_user_id ON companies (owner_user_id);

CREATE TABLE jobs (
	id VARCHAR(32) NOT NULL, 
	cat VARCHAR(24) NOT NULL, 
	logo VARCHAR(24), 
	title VARCHAR(128) NOT NULL, 
	company VARCHAR(128), 
	salary VARCHAR(32), 
	bonus VARCHAR(32), 
	city VARCHAR(32), 
	exp VARCHAR(32), 
	date_text VARCHAR(32), 
	type VARCHAR(24), 
	tags JSON, 
	edu VARCHAR(24), 
	recruiter VARCHAR(32), 
	recruiter_title VARCHAR(64), 
	reply VARCHAR(16), 
	openings VARCHAR(16), 
	intro TEXT, 
	duties JSON, 
	skills JSON, 
	reqs JSON, 
	plus JSON, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_jobs_cat ON jobs (cat);
CREATE INDEX ix_jobs_city ON jobs (city);
CREATE INDEX ix_jobs_cat_city ON jobs (cat, city);

CREATE TABLE coops (
	id VARCHAR(32) NOT NULL, 
	cat VARCHAR(24) NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	company_name VARCHAR(128), 
	budget VARCHAR(32), 
	cycle VARCHAR(32), 
	city VARCHAR(32), 
	coop VARCHAR(24), 
	deadline VARCHAR(32), 
	publish VARCHAR(32), 
	tags JSON, 
	publisher VARCHAR(32), 
	publisher_title VARCHAR(64), 
	applies INTEGER, 
	status VARCHAR(24), 
	desc_text TEXT, 
	req_text TEXT, 
	accept TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_coops_cat ON coops (cat);
CREATE INDEX ix_coops_cat_city ON coops (cat, city);
CREATE INDEX ix_coops_city ON coops (city);

CREATE TABLE posts (
	id VARCHAR(32) NOT NULL, 
	owner_type VARCHAR(16), 
	owner_id VARCHAR(32), 
	kind VARCHAR(24), 
	title VARCHAR(160), 
	status VARCHAR(24), 
	applies INTEGER, 
	time_text VARCHAR(32), 
	payload JSON, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_posts_owner_type ON posts (owner_type);
CREATE INDEX ix_posts_kind ON posts (kind);
CREATE INDEX ix_posts_owner_id ON posts (owner_id);

CREATE TABLE applications (
	id VARCHAR(32) NOT NULL, 
	user_id VARCHAR(32), 
	job_id VARCHAR(32), 
	obj_title VARCHAR(160), 
	company_name VARCHAR(128), 
	type VARCHAR(24), 
	salary VARCHAR(32), 
	time_text VARCHAR(32), 
	status_text VARCHAR(24), 
	status_cls VARCHAR(16), 
	feedback TEXT, 
	channel VARCHAR(24), 
	cover TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_applications_job_id ON applications (job_id);
CREATE INDEX ix_applications_user_id ON applications (user_id);

CREATE TABLE post_applicants (
	id VARCHAR(32) NOT NULL, 
	owner_user_id VARCHAR(32), 
	post_id VARCHAR(32), 
	who VARCHAR(64), 
	dir VARCHAR(64), 
	msg TEXT, 
	type VARCHAR(32), 
	status INTEGER, 
	time_text VARCHAR(32), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_post_applicants_post_id ON post_applicants (post_id);
CREATE INDEX ix_post_applicants_owner_user_id ON post_applicants (owner_user_id);

CREATE TABLE coop_applications (
	id VARCHAR(32) NOT NULL, 
	company_id VARCHAR(32), 
	coop_id VARCHAR(32), 
	obj_title VARCHAR(160), 
	company_name VARCHAR(128), 
	type VARCHAR(32), 
	salary VARCHAR(32), 
	time_text VARCHAR(32), 
	status_text VARCHAR(24), 
	status_cls VARCHAR(16), 
	feedback TEXT, 
	price VARCHAR(32), 
	cycle VARCHAR(32), 
	plan TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_coop_applications_company_id ON coop_applications (company_id);
CREATE INDEX ix_coop_applications_coop_id ON coop_applications (coop_id);

CREATE TABLE company_applications (
	id VARCHAR(32) NOT NULL, 
	company_id VARCHAR(32), 
	post_id VARCHAR(32), 
	who VARCHAR(64), 
	dir VARCHAR(64), 
	obj VARCHAR(160), 
	type VARCHAR(32), 
	msg TEXT, 
	status INTEGER, 
	time_text VARCHAR(32), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_company_applications_post_id ON company_applications (post_id);
CREATE INDEX ix_company_applications_company_id ON company_applications (company_id);

CREATE TABLE messages (
	id VARCHAR(32) NOT NULL, 
	scope VARCHAR(16), 
	user_id VARCHAR(32), 
	company_id VARCHAR(32), 
	name VARCHAR(64), 
	`role` VARCHAR(64), 
	time_text VARCHAR(32), 
	kind VARCHAR(24), 
	preview TEXT, 
	body TEXT, 
	rel_id VARCHAR(32), 
	rel_type VARCHAR(24), 
	ap_id VARCHAR(32), 
	av VARCHAR(24), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_messages_user_id ON messages (user_id);
CREATE INDEX ix_messages_scope ON messages (scope);
CREATE INDEX ix_messages_company_id ON messages (company_id);

CREATE TABLE resumes (
	id VARCHAR(32) NOT NULL, 
	user_id VARCHAR(32), 
	is_online BOOL, 
	name VARCHAR(160), 
	time_text VARCHAR(32), 
	size_text VARCHAR(32), 
	file_url VARCHAR(512), 
	content JSON, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_resumes_user_id ON resumes (user_id);

CREATE TABLE complaints (
	id VARCHAR(32) NOT NULL, 
	user_id VARCHAR(32), 
	obj VARCHAR(160), 
	type VARCHAR(32), 
	desc_text TEXT, 
	status_text VARCHAR(24), 
	status_cls VARCHAR(16), 
	time_text VARCHAR(32), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_complaints_user_id ON complaints (user_id);

CREATE TABLE career_plans (
	id VARCHAR(32) NOT NULL, 
	user_id VARCHAR(32), 
	plan_no INTEGER, 
	dir VARCHAR(64), 
	weeks INTEGER, 
	gaps INTEGER, 
	actions INTEGER, 
	concl TEXT, 
	phases JSON, 
	next_steps JSON, 
	at_text VARCHAR(32), 
	rounds INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_career_plans_user_id ON career_plans (user_id);

CREATE TABLE talents (
	id VARCHAR(32) NOT NULL, 
	name VARCHAR(64), 
	dir VARCHAR(64), 
	years VARCHAR(24), 
	city VARCHAR(32), 
	edu VARCHAR(24), 
	work_state VARCHAR(64), 
	salary VARCHAR(32), 
	match_score INTEGER, 
	skills JSON, 
	intro TEXT, 
	works JSON, 
	projects JSON, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);

CREATE TABLE company_certs (
	id VARCHAR(32) NOT NULL, 
	company_id VARCHAR(32), 
	state INTEGER, 
	step INTEGER, 
	payload JSON, 
	logs JSON, 
	submit_at VARCHAR(32), 
	pass_at VARCHAR(32), 
	reject_reason TEXT, 
	updated_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_company_certs_company_id ON company_certs (company_id);

SET FOREIGN_KEY_CHECKS = 1;