/**
 * 本地演示数据仓（USE_MOCK = true 时启用）
 * 结构与后端 MySQL 表一一对应，便于切换真实接口。
 */
const seed = require('./seed');
const { nowShort, nowText } = require('./util');

const KEY = 'daka_mock_db_v1';

function clone(o) { return JSON.parse(JSON.stringify(o)); }

function fresh() {
  const db = clone(seed);
  db.applied = [];
  db.meApplied = [];
  db.certLogs = [];
  db.certState = 0;
  db.certEditing = false;
  db.certStep = 1;
  db.certDraft = {};
  db.planHistory = clone(seed.GW_HISTORY);
  delete db.GW_HISTORY;
  return db;
}

let db = null;

function load() {
  if (db) return db;
  try {
    const cached = wx.getStorageSync(KEY);
    if (cached && cached.__v === 1) db = cached.db;
  } catch (e) { /* ignore */ }
  if (!db) { db = fresh(); db.__v = 1; save(); }
  return db;
}

function save() {
  try { wx.setStorageSync(KEY, { __v: 1, db }); } catch (e) { /* ignore */ }
}

function reset() {
  db = fresh(); db.__v = 1; save();
  return db;
}

/* ---------- 查询 ---------- */
function jobs(cat) {
  const d = load();
  if (!cat) return d.JOBS;
  return d.JOBS.filter(j => j.cat === cat);
}

function job(id) { return load().JOBS.find(j => j.id === id) || null; }

function coops(cat) {
  const d = load();
  if (!cat) return d.E_COOPS;
  return d.E_COOPS.filter(x => x.cat === cat);
}

function coop(id) { return load().E_COOPS.find(x => x.id === id) || null; }

function postById(id) {
  const d = load();
  for (const kind of Object.keys(d.MY_PUB)) {
    const it = d.MY_PUB[kind].find(x => x.id === id);
    if (it) return { kind, item: it };
  }
  return null;
}

function ePostById(kind, id) {
  const d = load();
  return (d.E_PUB[kind] || []).find(x => x.id === id) || null;
}

function messages(scope) { return scope === 'ent' ? load().E_MSGS : load().MSGS; }

/* ---------- 写入 ---------- */
function applyJob(jobId, channel, cover) {
  const d = load();
  if (d.applied.indexOf(jobId) < 0) d.applied.push(jobId);
  const j = job(jobId);
  d.MY_APPLIES.unshift({
    obj: j ? j.title : '岗位',
    co: j ? j.company : '',
    type: '岗位投递',
    salary: j ? j.salary : '',
    time: nowShort(),
    st: '已投递', stc: 'gray',
    fb: cover || '简历已送达，等待企业查看。'
  });
  save();
  return true;
}

function applyCoop(id, price, cycle, plan) {
  const d = load();
  const it = coop(id);
  if (it) { it.applied = true; it.applies = (it.applies || 0) + 1; }
  d.E_MY_APPLIES.unshift({
    obj: it ? it.title : '合作需求',
    co: it ? it.company : '',
    type: '项目承接', salary: '¥' + (price || '—'),
    time: nowShort(), st: '已投递', stc: 'gray',
    fb: plan || '方案已提交，等待企业查看。'
  });
  save();
  return true;
}

function createPost(kind, data, ent) {
  const d = load();
  const store = ent ? d.E_PUB : d.MY_PUB;
  if (!store[kind]) store[kind] = [];
  const item = Object.assign({
    id: 'NEW-' + Date.now().toString().slice(-6),
    cat: kind,
    time: nowShort(),
    status: '待审核',
    applies: 0,
    desc: data.desc || '',
    req: data.req || '',
    tags: ent ? ['企业发布'] : []
  }, data);
  store[kind].unshift(item);
  save();
  return item;
}

function decideApplicant(id, ok) {
  const d = load();
  const a = d.APPLICANTS.find(x => x.id === id);
  if (a) { a.st = ok ? 1 : 2; save(); }
  return a;
}

function decideCompanyApplicant(id, ok) {
  const d = load();
  const a = d.E_APPLIES.find(x => x.id === id);
  if (a) { a.st = ok ? 2 : 3; save(); }
  return a;
}

function deleteMessage(scope, id) {
  const d = load();
  const list = scope === 'ent' ? d.E_MSGS : d.MSGS;
  const i = list.findIndex(x => x.id === id);
  if (i >= 0) { list.splice(i, 1); save(); }
  return true;
}

function addResume(name, size) {
  const d = load();
  d.RESUMES.unshift({ id: 'r' + Date.now(), name, time: nowText().slice(0, 16), size });
  save();
  return d.RESUMES;
}

function addComplaint(obj, type, desc) {
  const d = load();
  d.COMPLAINTS.unshift({ obj, type, desc: desc || '（未填写）', time: nowShort(), st: '处理中', stc: 'orange' });
  save();
  return d.COMPLAINTS;
}

function addPlan(plan) {
  const d = load();
  const round = d.planHistory.length + 1;
  d.planHistory.unshift(Object.assign({
    id: 'GE-' + String(round).padStart(4, '0'),
    at: nowText(),
    rounds: 3
  }, plan));
  save();
  return d.planHistory;
}

function saveProfile(p) {
  const d = load();
  Object.assign(d.ME, p);
  save();
  return d.ME;
}

function submitCert(payload) {
  const d = load();
  Object.assign(d.ENT_CERT, payload);
  d.certState = 1;
  d.ENT_CERT.state = 1;
  d.ENT_CERT.submitAt = nowText();
  d.certLogs = [
    { t: '提交认证申请', d: d.ENT_CERT.submitAt + ' · 提交主体信息、证照 2 份、对公开票信息', s: 'ok' },
    { t: '平台审核中', d: '当前节点：证照核验（预计 1 个工作日内完成）', s: 'on' }
  ];
  save();
  return d.ENT_CERT;
}

function approveCert() {
  const d = load();
  d.certState = 2;
  d.ENT_CERT.state = 2;
  d.ENT_CERT.passAt = nowText();
  d.certLogs.push({ t: '平台审核通过', d: d.ENT_CERT.passAt + ' · 证照与工商信息一致', s: 'ok' });
  d.certLogs.push({ t: '认证生效', d: '有效期 12 个月，到期前 30 天提醒续期', s: 'ok' });
  save();
  return d.ENT_CERT;
}

function talents(q, seg) {
  const d = load();
  let arr = d.E_TALENTS.slice();
  if (seg === 1) arr = arr.filter(t => /智能体|视觉|大模型|数据/.test(t.dir));
  if (seg === 2) arr = arr.filter(t => /产品/.test(t.dir));
  if (seg === 3) arr = arr.filter(t => /培训/.test(t.dir));
  if (q) {
    const k = q.toLowerCase();
    arr = arr.filter(t => (t.name + t.dir + (t.skills || []).join('') + t.city).toLowerCase().indexOf(k) >= 0);
  }
  return arr.sort((a, b) => b.match - a.match);
}

module.exports = {
  load, save, reset, jobs, job, coops, coop, postById, ePostById, messages,
  applyJob, applyCoop, createPost, decideApplicant, decideCompanyApplicant,
  deleteMessage, addResume, addComplaint, addPlan, saveProfile, submitCert, approveCert, talents,
  nowShort, nowText
};
