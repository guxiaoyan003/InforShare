/**
 * 视图模型构建：把数据转换成 WXML 直接可渲染的结构
 * 与 demo 的 DOM 层级/文案逐项对齐
 */
const { avatarOf, badgeOf } = require('./avatar');
const { meta3, metaJob, salaryText, maskPhone } = require('./util');

function metas(list) {
  return list.map(x => ({ icon: x.icon, text: x.text }));
}

function jobCard(j) {
  return {
    id: j.id,
    kind: 'job',
    logo: 'i-job-sm',
    title: j.title,
    sub: j.company,
    salary: salaryText(j.salary),
    bonus: j.bonus,
    metas: metaJob(j),
    tags: [{ text: j.type, cls: 'type' }].concat((j.tags || []).map(t => ({ text: t, cls: '' }))),
    foot: { avatar: avatarOf(j.recruiter), name: j.recruiter, pill: { text: '招聘中', cls: '' } }
  };
}

function coopCard(it, catName) {
  return {
    id: it.id,
    kind: 'coop',
    logo: 'i-logo-' + (it.cat || 'layers'),
    title: it.title,
    sub: it.company + ' · 企业发布',
    salary: it.budget,
    bonus: it.cycle,
    metas: meta3(it.city, it.coop, '截止 ' + it.deadline),
    tags: [{ text: catName, cls: 'type' }].concat((it.tags || []).map(t => ({ text: t, cls: '' }))),
    foot: {
      avatar: avatarOf(it.publisher),
      name: it.publisher + ' · ' + it.publisherTitle,
      pill: { text: it.applied ? '已申请' : '招募中', cls: it.applied ? 'gray' : '' }
    }
  };
}

function postCard(kind, it) {
  let sub = '', salary = '', bonus = '', meta = [], tag = '';
  if (kind === 'consult') {
    sub = '数智化咨询 · ' + it.scene; salary = it.budget; bonus = it.cycle;
    meta = meta3(it.city, it.size, it.time); tag = it.type;
  } else if (kind === 'project') {
    sub = it.catg; salary = it.budget; bonus = '';
    meta = meta3(it.city, it.coop, it.deadline); tag = it.ptype + '发布';
  } else {
    sub = 'AI私教 · ' + it.type; salary = it.fee; bonus = '';
    meta = meta3(it.city, it.exp, it.time); tag = '招募 ' + it.count;
  }
  const green = ['服务中', '招募中', '接单中', '招聘中'].indexOf(it.status) >= 0;
  return {
    id: it.id,
    kind: 'post',
    logo: 'i-job-sm',
    title: it.title,
    sub,
    salary,
    bonus,
    metas: meta,
    tags: [{ text: tag, cls: 'type' }],
    foot: {
      avatar: '',
      name: it.applies + ' 人申请',
      pill: { text: it.status, cls: green ? '' : (it.status === '待审核' ? 'orange' : 'gray') }
    }
  };
}

function ePubCard(kind, it) {
  let sub = '', salary = '', bonus = '', meta = [], tag = '';
  if (kind === 'job') {
    sub = '岗位招聘 · ' + (it.type || '全职'); salary = it.salary; bonus = it.bonus;
    meta = meta3(it.city, it.exp, it.time); tag = it.type || '全职';
  } else if (kind === 'project') {
    sub = '项目外包 · ' + (it.catg || '项目外包'); salary = it.budget; bonus = it.cycle;
    meta = meta3(it.city, it.coop, it.deadline); tag = '项目外包';
  } else if (kind === 'consult') {
    sub = '数智化咨询 · ' + (it.scene || '企业内部系统'); salary = it.budget; bonus = it.cycle;
    meta = meta3(it.city, it.size, it.time); tag = it.type || '项目制咨询';
  } else if (kind === 'train') {
    sub = 'AI培训 · ' + (it.type || '企业内训'); salary = it.budget; bonus = it.cycle;
    meta = meta3(it.city, it.count, it.time); tag = it.type || '企业内训';
  } else {
    sub = 'AI私教 · ' + (it.type || '一对一私教'); salary = it.fee; bonus = '';
    meta = meta3(it.city, it.exp, it.time); tag = '招募 ' + (it.count || '1 人');
  }
  const green = ['招聘中', '招募中', '服务中', '接单中'].indexOf(it.status) >= 0;
  return {
    id: it.id,
    kind: 'epost',
    cat: kind,
    logo: 'i-job-sm',
    title: it.title,
    sub,
    salary: salary || '面议',
    bonus,
    metas: meta,
    tags: [{ text: tag, cls: 'type' }].concat((it.tags || []).slice(0, 2).map(t => ({ text: t, cls: '' }))),
    foot: {
      avatar: '',
      name: (it.applies || 0) + ' 人申请',
      pill: { text: it.status || '待审核', cls: green ? '' : (it.status === '待审核' ? 'orange' : 'gray') }
    }
  };
}

function msgCard(m) {
  const parts = m.kind === 'apply' ? m.preview.split('|').map(s => s.trim()) : [m.preview];
  return {
    id: m.id,
    name: m.name,
    avatar: m.av ? badgeOf(m.av) : avatarOf(m.name),
    sys: !!m.av,
    parts
  };
}

const AP_ST = [['待处理', 'orange'], ['已同意', 'blue'], ['已拒绝', 'gray']];
const E_AP_ST = [['待处理', 'orange'], ['已同意', 'blue'], ['已拒绝', 'gray']];

function applicantCard(a, objTitle) {
  const st = AP_ST[a.st] || AP_ST[0];
  return {
    id: a.id,
    objId: a.objId,
    who: a.who,
    avatar: avatarOf(a.who),
    dir: a.dir,
    objTitle,
    msg: a.msg,
    time: a.time,
    type: a.type,
    stText: st[0],
    stCls: st[1],
    pending: a.st === 0
  };
}

function companyApplicantCard(a) {
  const st = E_AP_ST[(a.st || 1) - 1] || E_AP_ST[0];
  return {
    id: a.id,
    who: a.who,
    avatar: avatarOf(a.who),
    dir: a.dir,
    objTitle: a.obj,
    msg: a.msg,
    time: a.time,
    type: a.type,
    stText: st[0],
    stCls: st[1],
    pending: a.st === 1
  };
}

function myApplyCard(a) {
  return {
    id: a.id || a.obj,
    obj: a.obj, co: a.co, type: a.type, salary: a.salary, time: a.time,
    fb: a.fb, st: a.st, stc: a.stc || ''
  };
}

function planCard(h, idx, total) {
  return {
    id: h.id,
    order: total - idx,
    at: h.at,
    rounds: h.rounds,
    concl: h.concl,
    dir: h.dir,
    weeks: h.weeks
  };
}

function complaintCard(c) {
  return { obj: c.obj, desc: c.desc, type: c.type, time: c.time, st: c.st, stc: c.stc || '' };
}

function fileCard(r) {
  return { id: r.id, name: r.name, time: r.time, size: r.size };
}

function talentCard(t) {
  return {
    id: t.id,
    name: t.name,
    avatar: avatarOf(t.name),
    dir: t.dir,
    years: t.years,
    city: t.city,
    match: t.match,
    edu: t.edu,
    salary: t.salary,
    state: t.state,
    skills: t.skills,
    intro: t.intro
  };
}

/* ---------- 详情页通用块 ---------- */
function liBlocks(arr, start) {
  return (arr || []).map((d, k) => ({ t: 'li', n: (start || 0) + k + 1, text: d }));
}

function detailHero(o) {
  return {
    title: o.title,
    company: o.company,
    metas: o.metas,
    stats: o.stats
  };
}

function jobDetail(j, applied) {
  const panes = [];
  panes.push([
    { t: 'h4', text: '岗位简介' },
    { t: 'p', text: j.intro },
    { t: 'h4', text: '岗位职责' }
  ].concat(liBlocks(j.duties)).concat([{ t: 'h4', text: '需求能力' }]).concat(liBlocks(j.skills)));

  panes.push([
    { t: 'h4', text: '任职要求' }
  ].concat(liBlocks(j.reqs)).concat([{ t: 'h4', text: '加分项' }]).concat(liBlocks(j.plus)).concat([
    { t: 'h4', text: '工作信息' },
    { t: 'row', k: '工作地点', v: j.city },
    { t: 'row', k: '经验要求', v: j.exp },
    { t: 'row', k: '学历要求', v: j.edu },
    { t: 'row', k: '用工形式', v: j.type }
  ]));

  panes.push([
    { t: 'head', name: j.recruiter, sub: j.recruiterTitle + ' · ' + j.company, avatar: avatarOf(j.recruiter) },
    { t: 'row', k: '所属公司', v: j.company },
    { t: 'row', k: '回复率', v: j.reply },
    { t: 'row', k: '在招职位', v: j.openings },
    { t: 'row', k: '发布时间', v: j.date }
  ]);

  return {
    hero: detailHero({
      title: j.title,
      company: j.company,
      metas: metaJob(j),
      stats: [
        { k: '薪资范围', v: salaryText(j.salary) },
        { k: '薪资发放', v: j.bonus },
        { k: '学历要求', v: j.edu }
      ]
    }),
    tabs: ['岗位职责', '任职要求', '发布者信息'],
    panes,
    applied: !!applied,
    applyText: applied ? '已投递' : '投递职位'
  };
}

function objDetail(found, me) {
  const kind = found.kind, it = found.item;
  let sub = '', stats = [], meta = [];
  if (kind === 'consult') {
    sub = '数智化咨询 · ' + it.scene;
    stats = [{ k: '预算', v: it.budget }, { k: '周期', v: it.cycle }, { k: '状态', v: it.status }];
    meta = meta3(it.city, it.size, it.time);
  } else if (kind === 'project') {
    sub = it.catg;
    stats = [{ k: '预算', v: it.budget }, { k: '合作', v: it.coop }, { k: '截止', v: it.deadline }];
    meta = meta3(it.city, it.coop, it.deadline);
  } else {
    sub = 'AI私教 · ' + it.type;
    stats = [{ k: '课时费', v: it.fee }, { k: '招募', v: it.count }, { k: '状态', v: it.status }];
    meta = meta3(it.city, it.exp, it.time);
  }
  return {
    hero: detailHero({ title: it.title, company: sub, metas: meta, stats }),
    tabs: ['需求说明', '承接要求', '发布者信息'],
    panes: [
      [
        { t: 'h4', text: '需求描述' },
        { t: 'p', text: it.desc },
        { t: 'h4', text: '补充信息' },
        { t: 'row', k: '发布时间', v: it.time },
        { t: 'row', k: '收到申请', v: it.applies + ' 人' }
      ],
      [
        { t: 'h4', text: kind === 'project' ? '验收标准' : '承接要求' },
        { t: 'p', text: it.req }
      ],
      [
        { t: 'head', name: me.name, sub: '个人发布 · ' + me.city, avatar: avatarOf(me.name) },
        { t: 'row', k: '联系人', v: me.name },
        { t: 'row', k: '手机号', v: maskPhone(me.phone) },
        { t: 'row', k: '邮箱', v: me.email },
        { t: 'row', k: '发布时间', v: it.time }
      ]
    ]
  };
}

function coopDetail(it, catName) {
  return {
    hero: detailHero({
      title: it.title,
      company: it.company + ' · ' + catName,
      metas: meta3(it.city, it.coop, '截止 ' + it.deadline),
      stats: [
        { k: '项目预算', v: it.budget },
        { k: '交付周期', v: it.cycle },
        { k: '申请方', v: String(it.applies) }
      ]
    }),
    tabs: ['需求说明', '承接要求', '发布方信息'],
    panes: [
      [
        { t: 'h4', text: '需求描述' },
        { t: 'p', text: it.desc },
        { t: 'h4', text: '补充信息' },
        { t: 'row', k: '发布时间', v: it.publish },
        { t: 'row', k: '截止时间', v: it.deadline },
        { t: 'row', k: '合作方式', v: it.coop }
      ],
      [
        { t: 'h4', text: '承接要求' },
        { t: 'p', text: it.req },
        { t: 'h4', text: '验收标准' },
        { t: 'p', text: it.accept }
      ],
      [
        { t: 'head', name: it.publisher, sub: it.publisherTitle + ' · ' + it.company, avatar: avatarOf(it.publisher) },
        { t: 'row', k: '企业名称', v: it.company },
        { t: 'row', k: '所在城市', v: it.city },
        { t: 'row', k: '已申请', v: it.applies + ' 家' },
        { t: 'row', k: '发布时间', v: it.publish }
      ]
    ],
    applied: !!it.applied,
    applyText: it.applied ? '已申请承接' : '申请承接'
  };
}

function ePostDetail(kind, it, companyName) {
  const label = { job: '岗位', project: '项目外包', consult: '数智化咨询', train: 'AI培训', coach: 'AI私教' }[kind] || '发布';
  let meta = [], stats = [];
  if (kind === 'job') {
    meta = meta3(it.city, it.exp, it.time);
    stats = [{ k: '薪资范围', v: it.salary }, { k: '薪资发放', v: it.bonus || '—' }, { k: '招聘人数', v: it.count || '1 人' }];
  } else if (kind === 'coach') {
    meta = meta3(it.city, it.exp, it.time);
    stats = [{ k: '课时费', v: it.fee }, { k: '招募人数', v: it.count || '1 人' }, { k: '收到申请', v: it.applies + ' 人' }];
  } else {
    meta = meta3(it.city, it.cycle, '截止 ' + (it.deadline || it.time));
    stats = [{ k: '预算', v: it.budget }, { k: '周期', v: it.cycle }, { k: '收到申请', v: it.applies + ' 人' }];
  }
  return {
    hero: detailHero({ title: it.title, company: label + ' · ' + companyName, metas: meta, stats }),
    blocks: [
      { t: 'blk', title: '需求说明', p: it.desc || '—' },
      { t: 'blk', title: '要求与验收', p: it.req || '—' },
      {
        t: 'blk', title: '发布信息', rows: [
          { t: 'row', k: '发布编号', v: it.id },
          { t: 'row', k: '发布时间', v: it.time },
          { t: 'row', k: '当前状态', v: it.status },
          { t: 'row', k: '收到申请', v: (it.applies || 0) + ' 人' }
        ]
      },
      { t: 'tip', text: '如需修改或下架，请在「我的发布」中操作；审核中的内容暂不可编辑。' }
    ]
  };
}

module.exports = {
  jobCard, coopCard, postCard, ePubCard, msgCard, applicantCard, companyApplicantCard,
  myApplyCard, planCard, complaintCard, fileCard, talentCard,
  jobDetail, objDetail, coopDetail, ePostDetail, metas
};
