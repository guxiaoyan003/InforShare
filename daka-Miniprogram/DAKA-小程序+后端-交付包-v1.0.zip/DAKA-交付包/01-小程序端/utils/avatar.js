/**
 * 头像映射：沿用 demo 的真人商务头像池（15 张）
 * 指定姓名固定头像，其余按姓名哈希稳定分配
 */
const PHOTO_FORCE = {
  '王旭': 0, '林沐': 0, '纪野': 3, '周昱': 4, '陈昊': 6, '裴然': 9, '于衡': 12,
  '孙倩': 8, '苏晴': 13, '李明': 14, '陈曦': 5, '何佳': 10, '赵晨': 12, '顾言': 6,
  '林书瑶': 11, '周牧': 14
};

const PHOTO_COUNT = 15;

function hashStr(s) {
  let h = 2166136261;
  const str = String(s == null ? '' : s);
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function avatarOf(name) {
  const key = String(name == null ? '' : name);
  let idx = PHOTO_FORCE[key];
  if (idx == null) idx = hashStr(key) % PHOTO_COUNT;
  return '/assets/avatars/p' + idx + '.jpg';
}

const BADGE = {
  platform: '/assets/icons/badge-platform.svg',
  company: '/assets/icons/badge-company.svg',
  service: '/assets/icons/badge-service.svg'
};

function badgeOf(kind) {
  return BADGE[kind] || BADGE.platform;
}

module.exports = { avatarOf, badgeOf, hashStr };
