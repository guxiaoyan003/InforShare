/* 通用工具：与 demo 的显示口径保持一致 */

const META_ICON = { city: 'pin', exp: 'bag', date: 'clock' };

function maskPhone(p) {
  return String(p == null ? '' : p).replace(/\s/g, '').replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2');
}

function pad(n) { return String(n).padStart(2, '0'); }

function nowText() {
  const d = new Date();
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
}

function nowShort() { return nowText().slice(5, 16); }

function meta3(a, b, c) {
  return [
    { icon: 'pin', text: a },
    { icon: 'bag', text: b },
    { icon: 'clock', text: c }
  ];
}

function metaJob(j) {
  return meta3(j.city, j.exp, j.date || j.time);
}

function salaryText(s) { return String(s == null ? '' : s).replace('k', 'K'); }

function catName(cats, key) {
  const c = (cats || []).find(x => x.key === key);
  return c ? c.name : '';
}

/* 描述文本按换行拆段，供 WXML 渲染 */
function lines(text) {
  return String(text == null ? '' : text).split('\n').filter(Boolean);
}

function scrollToBottom(page, key) {
  page.setData({ [key]: 'msg-bottom-' + Date.now() });
}

module.exports = {
  maskPhone, nowText, nowShort, meta3, metaJob, salaryText, catName, lines, scrollToBottom, pad
};
