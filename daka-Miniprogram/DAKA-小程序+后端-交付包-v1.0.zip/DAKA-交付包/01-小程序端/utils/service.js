/**
 * 统一数据服务层
 * USE_MOCK = true  -> 本地演示仓（可离线预览全部流程）
 * USE_MOCK = false -> Python 后端（FastAPI + MySQL）
 */
const config = require('./config');
const api = require('./api');
const mock = require('./mock');

const USE_MOCK = config.USE_MOCK;

function bootstrap() {
  if (!USE_MOCK) return api.get('/bootstrap');
  const d = mock.load();
  return Promise.resolve({
    me: d.ME,
    ent: d.ENT,
    cats: d.CATS,
    ecats: d.E_CATS,
    jobs: d.JOBS,
    coops: d.E_COOPS,
    posts: d.MY_PUB,
    companyPosts: d.E_PUB,
    messages: d.MSGS,
    companyMessages: d.E_MSGS,
    applicants: d.APPLICANTS,
    companyApplicants: d.E_APPLIES,
    myApplications: d.MY_APPLIES,
    companyMyApplications: d.E_MY_APPLIES,
    resume: d.ONLINE_RESUME,
    resumes: d.RESUMES,
    complaints: d.COMPLAINTS,
    plans: d.planHistory,
    talents: d.E_TALENTS,
    cert: Object.assign({}, d.ENT_CERT, { state: d.ENT_CERT.state, logs: d.certLogs || [] }),
    appliedJobs: d.applied || []
  });
}

function login(payload) {
  if (!USE_MOCK) {
    if (payload.mode === 'wechat') return api.post('/auth/wechat', { code: payload.code, role: payload.role });
    return api.post('/auth/login', payload);
  }
  const d = mock.load();
  const user = payload.role === 'ent'
    ? { id: 'ent-1', role: 'ent', name: d.ENT.name, short: d.ENT.short, avatar: '/assets/icons/ent-logo.svg' }
    : { id: 'u-1', role: 'personal', name: d.ME.name, avatar: '/assets/avatars/p0.jpg' };
  return Promise.resolve({ token: 'mock-token', user });
}

function applyJob(jobId, channel, cover) {
  if (!USE_MOCK) return api.post('/jobs/' + jobId + '/apply', { channel, cover });
  return Promise.resolve(mock.applyJob(jobId, channel, cover));
}

function applyCoop(id, payload) {
  if (!USE_MOCK) return api.post('/coops/' + id + '/apply', payload);
  return Promise.resolve(mock.applyCoop(id, payload.price, payload.cycle, payload.plan));
}

function createPost(kind, data, ent) {
  if (!USE_MOCK) return api.post('/posts', { kind, data, ent: !!ent });
  return Promise.resolve(mock.createPost(kind, data, ent));
}

function decideApplicant(id, ok) {
  if (!USE_MOCK) return api.post('/applicants/' + id + '/decision', { ok });
  return Promise.resolve(mock.decideApplicant(id, ok));
}

function decideCompanyApplicant(id, ok) {
  if (!USE_MOCK) return api.post('/company/applicants/' + id + '/decision', { ok });
  return Promise.resolve(mock.decideCompanyApplicant(id, ok));
}

function deleteMessage(scope, id) {
  if (!USE_MOCK) return api.del('/messages/' + id, { scope });
  return Promise.resolve(mock.deleteMessage(scope, id));
}

function addResume(file) {
  if (!USE_MOCK) return api.upload('/resumes', file.path, { name: file.name, size: file.size });
  return Promise.resolve(mock.addResume(file.name, file.size));
}

function addComplaint(obj, type, desc) {
  if (!USE_MOCK) return api.post('/complaints', { obj, type, desc });
  return Promise.resolve(mock.addComplaint(obj, type, desc));
}

function addPlan(plan) {
  if (!USE_MOCK) return api.post('/plans', plan);
  return Promise.resolve(mock.addPlan(plan));
}

function saveProfile(profile) {
  if (!USE_MOCK) return api.put('/me', profile);
  return Promise.resolve(mock.saveProfile(profile));
}

function submitCert(payload) {
  if (!USE_MOCK) return api.post('/company/cert', payload);
  return Promise.resolve(mock.submitCert(payload));
}

function approveCert() {
  if (!USE_MOCK) return api.post('/company/cert/approve');
  return Promise.resolve(mock.approveCert());
}

function resetMock() { mock.reset(); }

module.exports = {
  USE_MOCK, bootstrap, login, applyJob, applyCoop, createPost,
  decideApplicant, decideCompanyApplicant, deleteMessage, addResume,
  addComplaint, addPlan, saveProfile, submitCert, approveCert, resetMock
};
