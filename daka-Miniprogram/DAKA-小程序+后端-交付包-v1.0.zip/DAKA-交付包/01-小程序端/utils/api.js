const config = require('./config');

function url(path) {
  if (/^https?:\/\//.test(path)) return path;
  return config.API_BASE.replace(/\/$/, '') + path;
}

function request(method, path, data, opt) {
  opt = opt || {};
  return new Promise((resolve, reject) => {
    const app = getApp();
    const token = (app && app.globalData.token) || wx.getStorageSync(config.TOKEN_KEY) || '';
    wx.request({
      url: url(path),
      method: method,
      data: data || {},
      timeout: config.TIMEOUT,
      header: Object.assign({
        'content-type': 'application/json',
        'Authorization': token ? 'Bearer ' + token : ''
      }, opt.header || {}),
      success(res) {
        const body = res.data || {};
        if (res.statusCode >= 200 && res.statusCode < 300 && body.code === 0) {
          resolve(body.data);
          return;
        }
        if (res.statusCode === 401) {
          wx.removeStorageSync(config.TOKEN_KEY);
          const a = getApp();
          if (a) a.globalData.token = '';
        }
        const msg = body.message || ('请求失败（' + res.statusCode + '）');
        if (!opt.silent) wx.showToast({ title: msg, icon: 'none' });
        reject(new Error(msg));
      },
      fail(err) {
        if (!opt.silent) wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' });
        reject(err);
      }
    });
  });
}

function upload(path, filePath, formData) {
  return new Promise((resolve, reject) => {
    const app = getApp();
    const token = (app && app.globalData.token) || wx.getStorageSync(config.TOKEN_KEY) || '';
    wx.uploadFile({
      url: url(path),
      filePath: filePath,
      name: 'file',
      formData: formData || {},
      header: { 'Authorization': token ? 'Bearer ' + token : '' },
      success(res) {
        let body = {};
        try { body = JSON.parse(res.data || '{}'); } catch (e) { body = {}; }
        if (res.statusCode >= 200 && res.statusCode < 300 && body.code === 0) resolve(body.data);
        else {
          wx.showToast({ title: body.message || '上传失败', icon: 'none' });
          reject(new Error(body.message || 'upload failed'));
        }
      },
      fail(err) {
        wx.showToast({ title: '上传失败，请重试', icon: 'none' });
        reject(err);
      }
    });
  });
}

module.exports = {
  get: (p, d, o) => request('GET', p, d, o),
  post: (p, d, o) => request('POST', p, d, o),
  put: (p, d, o) => request('PUT', p, d, o),
  del: (p, d, o) => request('DELETE', p, d, o),
  upload
};
