/**
 * 全局配置
 * 部署时只需要改这个文件：
 *   - USE_MOCK = false       走 Python 后端
 *   - API_BASE = 'https://你的域名/api'
 *   - WX_APPID 由后端配置，前端不保存 AppSecret
 * 注意：小程序后台需把 API_BASE 域名加入 request 合法域名。
 */
module.exports = {
  // true：使用内置演示数据（无需后端即可完整走通 UI 与交互）
  // false：所有读写走 Python + MySQL 后端
  USE_MOCK: true,

  API_BASE: 'https://api.example.com/api',

  TIMEOUT: 15000,

  TOKEN_KEY: 'daka_token',
  USER_KEY: 'daka_user',

  // 演示环境固定验证码，接入短信服务后由后端校验
  DEMO_SMS_CODE: '123456',

  VERSION: '1.0.0'
};
