const config = require('./utils/config');

App({
  globalData: {
    token: '',
    user: null,
    role: 'personal',
    systemInfo: null
  },

  onLaunch() {
    try {
      const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
      this.globalData.systemInfo = info;
    } catch (e) {
      this.globalData.systemInfo = { windowWidth: 375, statusBarHeight: 20 };
    }
    const token = wx.getStorageSync(config.TOKEN_KEY) || '';
    if (token) this.globalData.token = token;
  }
});
