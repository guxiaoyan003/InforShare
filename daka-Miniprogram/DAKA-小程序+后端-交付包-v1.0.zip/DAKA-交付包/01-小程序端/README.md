# 小程序端说明

## 目录

```
01-小程序端/
├── app.js / app.json / app.wxss
├── pages/index/
│   ├── index.js          # 页面状态机：登录、tab、二级页栈、弹层、事件
│   ├── index.wxml        # 只做 include 壳
│   ├── index.wxss        # 全站样式（按 440 设计稿 ×1.7045 转 rpx）
│   └── tpl/
│       ├── l1.wxml       # 个人端 4 个一级页 + 企业端 4 个一级页
│       ├── l2.wxml       # 二级页容器（右滑进入 / 返回）
│       ├── cards.wxml    # 通用卡片、消息、申请、简历文件、牛人、富文本块
│       ├── pages.wxml    # 详情 / 搜索 / 消息 / 简历 / 申请 / 牛人
│       ├── forms.wxml    # 发布 / 企业认证 / 编辑资料
│       ├── login.wxml    # 登录
│       ├── tabbar.wxml   # 舵式 tabbar + FAB
│       └── overlay.wxml  # 投递弹层 / 选择器 / 对话框 / Toast
├── utils/
│   ├── config.js         # 唯一需要改的配置（USE_MOCK / API_BASE）
│   ├── api.js            # wx.request / wx.uploadFile 封装
│   ├── service.js        # 数据服务层（mock / http 双通道）
│   ├── mock.js           # 本地演示仓（Storage 持久化）
│   ├── seed.js           # 演示数据（岗位 / 消息 / 申请 / 规划…）
│   ├── vm.js             # 数据 -> WXML 视图模型
│   ├── avatar.js         # 姓名 -> 头像映射
│   └── util.js           # 脱敏 / 时间 / meta
├── styles/icons.wxss     # 从 demo 提取的 SVG（base64 背景图）
└── assets/               # 头像、规划页背景、企业 logo
```

## 为什么是单页 + 模板

demo 的交互核心是「一级页 + 可层叠的二级页 + 全局弹层」，二级页用 `translateX` + `cubic-bezier(.32,.72,0,1)` 滑入。微信原生 `navigateTo` 的转场曲线不可定制，无法 1:1 还原，因此采用：

- 一个 `pages/index/index` 承载页面栈（`data.stack`），每层是一个 `scroll-view`，保留各自的滚动位置；
- 二级页通过 `transform` 滑入 / 滑出，曲线与 demo 完全一致；
- 所有一级页 / 二级页用 `tpl/*.wxml` 拆分，通过 `include` / `import` 组装，便于维护。

## 改配置

```js
// utils/config.js
USE_MOCK: true,                       // 演示模式；联调改 false
API_BASE: 'https://api.example.com/api'
```

`USE_MOCK = false` 时，`utils/service.js` 会把所有读写切到 `utils/api.js`，接口约定见后端 README。

## 新增一个二级页

1. 在 `pages/index/pages.js` 的 `buildPage()` 里加分支，返回 `{ title, vm, footer }`；
2. 在 `tpl/pages.wxml` 加 `<template name="xxx">`；
3. 在 `tpl/l2.wxml` 加一行 `<block wx:elif="{{item.name === 'xxx'}}">`；
4. 需要底部按钮时，`footer.type` 用 `action` / `double` / `chat` / `cert` / `publish`。

## AI 接入点

`pages/index/pages.js`：

- `chatStart()` 开始会话
- `chatAsk()` 出题
- `chatAnswer()` 用户回答后请求下一题
- `chatFinish()` 生成方案卡

把 `ACK` 固定文案换成接口返回即可；数据结构保持 `{text, opts, plan}`，UI 不用改。
