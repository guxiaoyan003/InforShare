/* 二级页：构建 + 交互（详情 / 搜索 / 消息 / 简历 / 申请 / 牛人 / 规划） */
const service = require('../../utils/service');
const vm = require('../../utils/vm');
const util = require('../../utils/util');
const seed = require('../../utils/seed');
const { avatarOf } = require('../../utils/avatar');

const GW_Q = seed.GW_Q;
const GW_PLAN = seed.GW_PLAN;
const ACK = [
  t => '收到～ <b>' + t + '</b>，这个年龄段在 AI 岗位上的成长节奏确实不太一样，我会在后面的建议里考虑进去。',
  t => '明白了，<b>' + t + '</b> 这段经历很关键，我会把协作与带人能力单独纳入评估。',
  t => '好的，按 <b>' + t + '</b> 来安排节奏，我会把任务拆成你能坚持的最小颗粒度。'
];

function rich(html) {
  return String(html || '')
    .replace(/<span class="sub">/g, '<span style="display:block;font-size:20rpx;color:#8A97A8;margin-top:7rpx">')
    .replace(/<b>/g, '<span style="font-weight:700">')
    .replace(/<\/b>/g, '</span>');
}

module.exports = {
  /* ================= 页面构建 ================= */
  buildPage(name, p, key) {
    const me = this.data.me || {};
    const ent = this.data.ent || {};

    if (name === 'detail') {
      const j = (this.allJobs || []).find(x => x.id === p.id) || (this.allJobs || [])[0];
      if (!j) return { title: '职位详情', vm: {} };
      const d = vm.jobDetail(j, (this.data.appliedJobs || []).indexOf(j.id) >= 0);
      return {
        title: '职位详情',
        vm: Object.assign(d, { activeTab: 0, activeBlocks: d.panes[0], jobId: j.id }),
        footer: { type: 'action', kind: 'job', text: d.applyText, done: d.applied }
      };
    }

    if (name === 'objDetail') {
      const found = this.findPost(p.id);
      if (!found) return { title: '需求详情', vm: { empty: '需求不存在' } };
      const d = vm.objDetail(found, me);
      return { title: '需求详情', vm: Object.assign(d, { activeTab: 0, activeBlocks: d.panes[0], objId: found.item.id }) };
    }

    if (name === 'search') {
      return {
        title: '搜索',
        vm: {
          q: '',
          placeholder: '请查找您想要的岗位',
          filters: [
            { k: 'city', label: '城市', value: '不限', on: false },
            { k: 'cat', label: '岗位类型', value: '不限', on: false },
            { k: 'exp', label: '经验', value: '不限', on: false }
          ],
          count: '共 ' + (this.allJobs || []).length + ' 个岗位',
          cards: (this.allJobs || []).map(vm.jobCard),
          emptyTitle: '没有找到匹配的岗位',
          emptyHint: '试试更换关键词或筛选条件',
          empty: false
        }
      };
    }

    if (name === 'hist') {
      const list = this.data.plans || [];
      return {
        title: '历史记录',
        vm: {
          count: list.length,
          items: list.map((h, i) => vm.planCard(h, i, list.length))
        }
      };
    }

    if (name === 'histDetail') {
      const h = (this.data.plans || []).find(x => x.id === p.id);
      if (!h) return { title: '规划详情', vm: { empty: '该记录已不存在' } };
      return {
        title: '规划详情',
        vm: {
          at: h.at,
          rounds: h.rounds,
          dir: h.dir,
          concl: h.concl,
          weeks: h.weeks,
          gaps: h.gaps,
          actions: h.actions,
          phases: h.phases || [],
          next: h.next || []
        }
      };
    }

    if (name === 'chat') {
      return {
        title: '职业规划',
        scrollClass: 'chat-body',
        vm: {
          hero: true,
          msgs: [],
          chips: this.chatChips(),
          chipOn: -1,
          input: '',
          busy: false,
          done: false,
          plan: null,
          scrollInto: '',
          step: -1,
          started: false,
          chipOn: -1
        },
        footer: { type: 'chat' }
      };
    }

    if (name === 'msgDetail') {
      const m = (this.data.msgsRaw || []).find(x => x.id === p.id);
      if (!m) return { title: '消息详情', vm: { empty: '该消息已删除' } };
      const rel = m.relId ? this.findPost(m.relId) : null;
      let relVM = null;
      if (rel) {
        const it = rel.item;
        const sub = rel.kind === 'consult' ? '数智化咨询 · ' + it.scene
          : rel.kind === 'project' ? it.catg : 'AI私教 · ' + it.type;
        const sal = rel.kind === 'coach' ? it.fee : it.budget;
        relVM = { id: it.id, title: it.title, sub, salary: sal };
      }
      return {
        title: '消息详情',
        vm: {
          name: m.name,
          role: m.role,
          time: m.time,
          avatar: m.av ? this.badge(m.av) : avatarOf(m.name),
          sys: !!m.av,
          body: m.body,
          rel: relVM,
          isApply: m.kind === 'apply',
          relId: m.relId || '',
          apId: m.apId || '',
          hasAp: !!(m.kind === 'apply' && m.apId)
        }
      };
    }

    if (name === 'resume') {
      const r = this.data.resume || {};
      return {
        title: '在线简历',
        vm: {
          name: r.name,
          intent: r.intent,
          salary: r.salary,
          state: r.state,
          complete: r.complete,
          phone: r.phone,
          email: r.email,
          city: r.city,
          years: r.years,
          edu: r.edu,
          eduMode: r.eduMode,
          school: r.school,
          level: r.level,
          major: r.major,
          grad: r.grad,
          expectCity: r.expectCity,
          works: r.works || [],
          projects: r.projects || [],
          skills: r.skills || [],
          aiIntro: r.aiIntro,
          file: r.file || {},
          avatar: avatarOf(r.name)
        }
      };
    }

    if (name === 'minePub') {
      const st = { tab: (p && p.tab) || 0 };
      const keys = ['consult', 'project', 'coach'];
      const labels = ['数智化咨询', '项目外包', 'AI私教'];
      const kind = keys[st.tab];
      const arr = (this.data.myPub || {})[kind] || [];
      return {
        title: '我的发布',
        vm: {
          tab: st.tab,
          segs: labels,
          bar: { left: 0, width: 0 },
          cards: arr.map(it => vm.postCard(kind, it)),
          empty: arr.length === 0
        }
      };
    }

    if (name === 'mineApply') {
      const arr = this.data.myApplies || [];
      return {
        title: '我的申请',
        vm: { count: arr.length, kind: '投递', items: arr.map(vm.myApplyCard) }
      };
    }

    if (name === 'received') {
      const arr = this.data.applicants || [];
      return {
        title: '收到申请',
        vm: {
          count: arr.length,
          scope: 'personal',
          items: arr.map(a => vm.applicantCard(a, this.objTitle(a.objId)))
        }
      };
    }

    if (name === 'apDetail') {
      const found = this.findPost(p.objId);
      const list = (this.data.applicants || []).filter(a => a.objId === p.objId);
      return {
        title: '申请详情',
        vm: {
          objId: p.objId,
          card: found ? vm.postCard(found.kind, found.item) : null,
          count: list.length,
          items: list.map(a => vm.applicantCard(a, this.objTitle(a.objId)))
        }
      };
    }

    if (name === 'uploadResume') {
      return {
        title: '上传简历',
        vm: { items: (this.data.resumes || []).map(vm.fileCard) }
      };
    }

    if (name === 'complaint') {
      return {
        title: '发起投诉',
        vm: {
          obj: '',
          type: '虚假职位',
          desc: '',
          items: (this.data.complaints || []).map(vm.complaintCard)
        }
      };
    }

    if (name === 'eDetail') {
      const it = (this.allCoops || []).find(x => x.id === p.id) || (this.allCoops || [])[0];
      if (!it) return { title: '需求详情', vm: {} };
      const cat = (this.data.ecats || []).find(c => c.key === it.cat);
      const d = vm.coopDetail(it, cat ? cat.name : '');
      return {
        title: '需求详情',
        vm: Object.assign(d, { activeTab: 0, activeBlocks: d.panes[0], coopId: it.id }),
        footer: { type: 'action', kind: 'coop', text: d.applyText, done: d.applied }
      };
    }

    if (name === 'eSearch') {
      return {
        title: '搜索',
        vm: {
          q: '',
          placeholder: '搜索项目、岗位外包或培训需求',
          filters: [
            { k: 'city', label: '城市', value: '不限', on: false },
            { k: 'cat', label: '类型', value: '不限', on: false },
            { k: 'coop', label: '方式', value: '不限', on: false }
          ],
          count: '共 ' + (this.allCoops || []).length + ' 个合作需求',
          cards: (this.allCoops || []).map(it => {
            const c = (this.data.ecats || []).find(x => x.key === it.cat);
            return vm.coopCard(it, c ? c.name : '');
          }),
          emptyTitle: '没有找到匹配的合作需求',
          emptyHint: '试试更换关键词或筛选条件',
          empty: false
        }
      };
    }

    if (name === 'eMinePub') {
      const order = ['job', 'project', 'consult', 'train', 'coach'];
      const labels = ['岗位', '项目外包', '数智化咨询', 'AI培训', 'AI私教'];
      const tab = Math.max(0, (p && p.tab) || 0);
      const kind = order[tab];
      const arr = (this.data.ePub || {})[kind] || [];
      return {
        title: '我的发布',
        vm: {
          tab,
          segs: labels,
          bar: { left: 0, width: 0 },
          cards: arr.map(it => vm.ePubCard(kind, it)),
          empty: arr.length === 0
        }
      };
    }

    if (name === 'eMineApply') {
      const arr = this.data.eMyApplies || [];
      return {
        title: '我的申请',
        vm: { count: arr.length, kind: '承接申请', items: arr.map(vm.myApplyCard) }
      };
    }

    if (name === 'eReceived') {
      const arr = this.data.eApplies || [];
      return {
        title: '收到申请',
        vm: { count: arr.length, scope: 'ent', items: arr.map(vm.companyApplicantCard) }
      };
    }

    if (name === 'viewTalent') {
      return {
        title: '查看牛人',
        vm: {
          q: '', seg: 0,
          segs: ['全部', '技术', '产品', '培训'],
          count: '共 ' + (this.data.talents || []).length + ' 位牛人 · 按匹配度排序',
          cards: (this.data.talents || []).slice().sort((a, b) => b.match - a.match).map(vm.talentCard),
          empty: false
        }
      };
    }

    if (name === 'talentDetail') {
      const t = (this.data.talents || []).find(x => x.id === p.id) || (this.data.talents || [])[0];
      if (!t) return { title: '牛人主页', vm: {} };
      return {
        title: '牛人主页',
        vm: {
          name: t.name,
          dir: t.dir,
          years: t.years,
          city: t.city,
          state: t.state,
          salary: t.salary,
          edu: t.edu,
          match: t.match,
          intro: t.intro,
          skills: t.skills,
          works: (t.works || []).map(w => ({ org: w[0], title: w[1], time: w[2], desc: w[3] })),
          projects: (t.projects || []).map(w => ({ name: w[0], role: w[1], desc: w[2] })),
          avatar: avatarOf(t.name)
        },
        footer: { type: 'double' }
      };
    }

    if (name === 'eMsgDetail') {
      const m = (this.data.emsgsRaw || []).find(x => x.id === p.id);
      if (!m) return { title: '消息详情', vm: { empty: '该消息已删除' } };
      let relVM = null;
      if (m.relType) {
        const rel = ((this.data.ePub || {})[m.relType] || []).find(x => x.id === m.relId);
        if (rel) {
          const label = { job: '岗位', project: '项目外包', consult: '数智化咨询', train: 'AI培训', coach: 'AI私教' }[m.relType] || '发布';
          relVM = {
            title: rel.title,
            sub: label + ' · ' + (rel.status || ''),
            salary: rel.budget || rel.salary || rel.fee || '面议'
          };
        }
      }
      return {
        title: '消息详情',
        vm: {
          name: m.name, role: m.role, time: m.time,
          avatar: m.av ? this.badge(m.av) : avatarOf(m.name),
          sys: !!m.av,
          scope: 'ent',
          body: m.body, rel: relVM, relId: m.relId || '', hasAp: !!m.apId
        }
      };
    }

    if (name === 'eObjDetail') {
      const kind = p.kind || 'job';
      const it = ((this.data.ePub || {})[kind] || []).find(x => x.id === p.id);
      if (!it) return { title: '发布详情', vm: { empty: '内容不存在' } };
      const d = vm.ePostDetail(kind, it, (this.data.ent || {}).name || '');
      return { title: '发布详情', vm: d };
    }

    return this.buildForm ? this.buildForm(name, p, key) : { title: '', vm: {} };
  },

  /* ================= 辅助 ================= */
  findPost(id) {
    const my = this.data.myPub || {};
    for (const kind of Object.keys(my)) {
      const it = (my[kind] || []).find(x => x.id === id);
      if (it) return { kind, item: it };
    }
    return null;
  },

  objTitle(id) {
    const f = this.findPost(id);
    return f ? f.item.title : id;
  },

  badge(kind) { return require('../../utils/avatar').badgeOf(kind); },

  chatChips() {
    const list = [{ label: '在线简历', pdf: false }];
    (this.data.resumes || []).forEach(r => list.push({ label: r.name, pdf: true }));
    return list;
  },

  /* ================= 详情交互 ================= */
  onPaneTab(e) {
    const i = Number(e.currentTarget.dataset.i);
    const t = Number(e.currentTarget.dataset.t);
    const v = this.data.stack[i].vm;
    this.setData({
      ['stack[' + i + '].vm.activeTab']: t,
      ['stack[' + i + '].vm.activeBlocks']: (v.panes || [])[t]
    });
  },

  onSearch() { this.go('search'); },
  onESearch() { this.go('eSearch'); },
  onHist() { this.go('hist'); },
  onPlan() { this.go('chat'); },
  onCertClick() { this.setData({ certEditing: false }); this.go('cert'); },

  onCardTap(e) {
    const d = e.currentTarget.dataset;
    if (d.kind === 'coop') this.go('eDetail', { id: d.id });
    else if (d.kind === 'epost') this.go('eObjDetail', { kind: d.cat, id: d.id });
    else if (d.kind === 'post') this.go('objDetail', { id: d.id });
    else this.go('detail', { id: d.id });
  },

  onApplyTap(e) {
    const kind = e.currentTarget.dataset.kind;
    if (kind === 'coop') this.onCoopApplyOpen(e);
    else this.onApplyOpen(e);
  },

  onApplyOpen(e) {
    const i = Number(e.currentTarget.dataset.i);
    const layer = this.data.stack[i];
    const job = (this.allJobs || []).find(x => x.id === layer.vm.jobId);
    if (!job) return;
    if (layer.vm.applied) return;
    this._apply = { jobId: job.id, channel: 'online', cover: '', layerIndex: i };
    const pdfs = (this.data.resumes || []).length ? this.data.resumes : [{ name: '王旭-产品经理-2026.pdf' }];
    this.setData({
      'sheet.show': true,
      'sheet.okText': '投递职位',
      'sheet.cancelText': '我再想想',
      'sheet.type': 'job',
      'sheet.job': {
        title: job.title,
        salary: util.salaryText(job.salary),
        bonus: job.bonus
      },
      'sheet.chips': [{ key: 'online', label: '在线简历', pdf: false }].concat(pdfs.map((f, k) => ({
        key: 'pdf' + k,
        label: f.name.length > 20 ? f.name.slice(0, 20) + '…' : f.name,
        pdf: true
      }))),
      'sheet.chip': 'online',
      'sheet.cover': ''
    });
  },

  onCoopApplyOpen(e) {
    const i = Number(e.currentTarget.dataset.i);
    const layer = this.data.stack[i];
    const it = (this.allCoops || []).find(x => x.id === layer.vm.coopId);
    if (!it || it.applied) return;
    this._apply = { coopId: it.id, layerIndex: i, price: '', plan: '', cycle: '8 周' };
    this.setData({
      'sheet.show': true,
      'sheet.okText': '提交申请',
      'sheet.cancelText': '取消',
      'sheet.type': 'coop',
      'sheet.job': { title: it.title, salary: it.budget, bonus: '' },
      'sheet.chips': ['4 周', '8 周', '12 周', '3 个月以上'].map(c => ({ key: c, label: c, pdf: false })),
      'sheet.chip': '8 周',
      'sheet.price': '',
      'sheet.plan': ''
    });
  },

  onSheetChip(e) {
    const k = e.currentTarget.dataset.k;
    if (this.data.sheet.type === 'coop') this._apply.cycle = k;
    else this._apply.channel = k;
    this.setData({ 'sheet.chip': k });
  },

  onSheetCover(e) { this._apply.cover = e.detail.value; },
  onSheetPrice(e) { this._apply.price = e.detail.value; },
  onSheetPlan(e) { this._apply.plan = e.detail.value; },

  async onSheetOk() {
    const a = this._apply || {};
    if (this.data.sheet.type === 'coop') {
      if (!String(a.price || '').trim()) { this.toast('请填写报价'); return; }
      if (String(a.plan || '').trim().length < 10) { this.toast('承接方案至少 10 个字'); return; }
      await service.applyCoop(a.coopId, { price: a.price, cycle: a.cycle, plan: a.plan });
      const i = a.layerIndex;
      this.setData({
        ['stack[' + i + '].vm.applied']: true,
        ['stack[' + i + '].vm.applyText']: '已申请承接',
        ['stack[' + i + '].footer.text']: '已申请承接',
        ['stack[' + i + '].footer.done']: true,
        'sheet.show': false
      });
      this.toast('申请已提交，等待发布方确认');
      return;
    }
    await service.applyJob(a.jobId, a.channel, a.cover);
    const applied = (this.data.appliedJobs || []).slice();
    if (applied.indexOf(a.jobId) < 0) applied.push(a.jobId);
    const i = a.layerIndex;
    this.setData({
      appliedJobs: applied,
      ['stack[' + i + '].vm.applied']: true,
      ['stack[' + i + '].vm.applyText']: '已投递',
      ['stack[' + i + '].footer.text']: '已投递',
      ['stack[' + i + '].footer.done']: true,
      'sheet.show': false
    });
    this.toast('投递成功，请留意消息通知');
  },

  onSheetCancel() { this.setData({ 'sheet.show': false }); this._apply = null; },

  /* ================= 搜索 ================= */
  onSearchInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    const q = e.detail.value;
    this.patchSearch(i, { q });
  },

  onSearchClear(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.patchSearch(i, { q: '' });
  },

  onFilterTap(e) {
    const i = Number(e.currentTarget.dataset.i);
    const k = e.currentTarget.dataset.k;
    const layer = this.data.stack[i];
    const isEnt = layer.name === 'eSearch';
    let opts;
    if (k === 'city') opts = ['不限', '深圳', '广州', '杭州', '北京', '上海'];
    else if (k === 'cat') opts = isEnt ? ['不限'].concat((this.data.ecats || []).map(c => c.name)) : ['不限'].concat((this.data.cats || []).map(c => c.name));
    else if (k === 'coop') opts = ['不限', '线上', '线下', '线上 + 线下'];
    else opts = ['不限', '在校/应届', '1 年以下', '1–3 年', '3–5 年', '5–10 年', '10 年以上'];
    const cur = (layer.vm.filters.find(f => f.k === k) || {}).value || '不限';
    this._filterCtx = { i, k };
    this.openPicker({ city: '选择城市', cat: '选择岗位类型', coop: '选择合作方式', exp: '选择经验' }[k] || '请选择', opts, cur, v => {
      const ctx = this._filterCtx;
      if (!ctx) return;
      this.patchSearch(ctx.i, { filter: { k: ctx.k, v } });
    });
  },

  patchSearch(i, patch) {
    const layer = this.data.stack[i];
    if (!layer) return;
    const isEnt = layer.name === 'eSearch';
    const v = layer.vm;
    let q = patch.q != null ? patch.q : v.q;
    let filters = v.filters.map(f => ({ k: f.k, label: f.label, value: f.value, on: f.on }));
    if (patch.filter) {
      const f = filters.find(x => x.k === patch.filter.k);
      if (f) {
        f.value = patch.filter.v;
        f.on = patch.filter.v !== '不限';
      }
    }
    const get = k => (filters.find(x => x.k === k) || {}).value || '不限';
    let list;
    if (isEnt) {
      list = (this.allCoops || []).filter(it => {
        if (get('city') !== '不限' && it.city !== get('city')) return false;
        if (get('cat') !== '不限') {
          const c = (this.data.ecats || []).find(x => x.key === it.cat);
          if (!c || c.name !== get('cat')) return false;
        }
        if (get('coop') !== '不限' && it.coop !== get('coop')) return false;
        if (q) {
          const hay = (it.title + it.company + (it.tags || []).join('') + it.city).toLowerCase();
          if (hay.indexOf(q.toLowerCase()) < 0) return false;
        }
        return true;
      });
      const cards = list.map(it => {
        const c = (this.data.ecats || []).find(x => x.key === it.cat);
        return vm.coopCard(it, c ? c.name : '');
      });
      this.setData({
        ['stack[' + i + '].vm.q']: q,
        ['stack[' + i + '].vm.filters']: filters,
        ['stack[' + i + '].vm.cards']: cards,
        ['stack[' + i + '].vm.count']: (q ? '找到 ' + cards.length + ' 个合作需求' : '共 ' + cards.length + ' 个合作需求'),
        ['stack[' + i + '].vm.empty']: cards.length === 0
      });
      return;
    }
    list = (this.allJobs || []).filter(j => {
      if (get('city') !== '不限' && j.city !== get('city')) return false;
      if (get('cat') !== '不限') {
        const c = (this.data.cats || []).find(x => x.key === j.cat);
        if (!c || c.name !== get('cat')) return false;
      }
      if (get('exp') !== '不限') {
        const a = get('exp').replace(/[–—]/g, '-').replace(/\s/g, '');
        const b = String(j.exp).replace(/[–—]/g, '-').replace(/\s/g, '');
        if (b.indexOf(a) !== 0) return false;
      }
      if (q) {
        const hay = (j.title + j.company + (j.tags || []).join('') + j.city + j.type).toLowerCase();
        if (hay.indexOf(q.toLowerCase()) < 0) return false;
      }
      return true;
    });
    const cards = list.map(vm.jobCard);
    this.setData({
      ['stack[' + i + '].vm.q']: q,
      ['stack[' + i + '].vm.filters']: filters,
      ['stack[' + i + '].vm.cards']: cards,
      ['stack[' + i + '].vm.count']: (q ? '找到 ' + cards.length + ' 个相关岗位' : '共 ' + cards.length + ' 个岗位'),
      ['stack[' + i + '].vm.empty']: cards.length === 0
    });
  },

  /* ================= 规划 ================= */
  onHistOpen(e) { this.go('histDetail', { id: e.currentTarget.dataset.id }); },

  onChatChip(e) {
    const i = Number(e.currentTarget.dataset.i);
    const idx = Number(e.currentTarget.dataset.c);
    const layer = this.data.stack[i];
    if (layer.vm.started) return;
    this.chatStart(i, idx);
  },

  onChatInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.setData({ ['stack[' + i + '].vm.input']: e.detail.value });
  },

  onChatSend(e) {
    const i = Number(e.currentTarget.dataset.i);
    const layer = this.data.stack[i];
    const v = String(layer.vm.input || '').trim();
    if (!v) return;
    this.setData({ ['stack[' + i + '].vm.input']: '' });
    if (!layer.vm.started) {
      this.setData({ ['stack[' + i + '].vm.started']: true, ['stack[' + i + '].vm.hero']: false, ['stack[' + i + '].vm.chipOn']: 0 });
      this.chatPush(i, { me: true, text: v });
      this.chatSay(i, '好的呀～ 那我先按你的在线简历做一次基础解析，再问几个关键问题补全画像。').then(() => this.chatAsk(i));
      return;
    }
    if (layer.vm.done) {
      this.chatPush(i, { me: true, text: v });
      this.chatSay(i, '收到。补充信息已并入画像，如需重新出一版方案，可以点「重新评估」。');
      return;
    }
    if (layer.vm.busy) return;
    this.chatAnswer(i, v);
  },

  chatStart(i, chipIdx) {
    this.setData({
      ['stack[' + i + '].vm.started']: true,
      ['stack[' + i + '].vm.hero']: false,
      ['stack[' + i + '].vm.chipOn']: chipIdx,
      ['stack[' + i + '].vm.step']: -1
    });
    this.chatPush(i, { me: true, text: '请根据我选择的简历，来帮我规划我的职业路径' });
    this.chatSay(i, '好的，我已经收到您的简历，还有一些问题需要您来补充哦~').then(() => {
      if (this.data.stack[i]) this.chatAsk(i);
    });
  },

  chatPush(i, msg) {
    const layer = this.data.stack[i];
    if (!layer) return;
    const msgs = layer.vm.msgs.concat([Object.assign({ id: 'm' + Date.now() + Math.floor(Math.random() * 1000) }, msg)]);
    this.setData({ ['stack[' + i + '].vm.msgs']: msgs, ['stack[' + i + '].vm.scrollInto']: 'msg-' + msgs[msgs.length - 1].id });
  },

  chatSay(i, html) {
    return new Promise(resolve => {
      const layer = this.data.stack[i];
      const id = 'm' + Date.now() + Math.floor(Math.random() * 1000);
      const msgs = layer.vm.msgs.concat([{ id, dots: true, ai: true }]);
      this.setData({ ['stack[' + i + '].vm.msgs']: msgs, ['stack[' + i + '].vm.scrollInto']: 'msg-' + id });
      setTimeout(() => {
        const now = this.data.stack[i];
        if (!now) { resolve(id); return; }
        const cur = now.vm.msgs.map(m => m.id === id ? { id, ai: true, text: rich(html) } : m);
        this.setData({ ['stack[' + i + '].vm.msgs']: cur, ['stack[' + i + '].vm.scrollInto']: 'msg-' + id });
        resolve(id);
      }, 560);
    });
  },

  chatAsk(i) {
    const layer = this.data.stack[i];
    if (!layer) return;
    const step = (layer.vm.step == null ? -1 : layer.vm.step) + 1;
    if (step >= GW_Q.length) { this.chatFinish(i); return; }
    this.setData({ ['stack[' + i + '].vm.step']: step });
    const q = GW_Q[step];
    this.chatSay(i, q.q).then(id => {
      const layerNow = this.data.stack[i];
      if (!layerNow) return;
      const msgs = layerNow.vm.msgs.map(m => m.id === id
        ? Object.assign({}, m, { opts: q.opts.map((o, k) => ({ k, text: o })) })
        : m);
      this.setData({ ['stack[' + i + '].vm.msgs']: msgs, ['stack[' + i + '].vm.scrollInto']: 'msg-' + id });
    });
  },

  chatAnswer(i, text) {
    const layer = this.data.stack[i];
    if (!layer) return;
    this.setData({ ['stack[' + i + '].vm.busy']: true });
    const msgs = layer.vm.msgs.map(m => {
      if (m.opts) return Object.assign({}, m, { disabled: true });
      return m;
    });
    this.setData({ ['stack[' + i + '].vm.msgs']: msgs });
    this.chatPush(i, { me: true, text });
    const step = layer.vm.step || 0;
    const ack = ACK[step] ? ACK[step](text) : '收到～';
    this.chatSay(i, ack).then(() => {
      if (!this.data.stack[i]) return;
      this.setData({ ['stack[' + i + '].vm.busy']: false });
      this.chatAsk(i);
    });
  },

  chatFinish(i) {
    this.chatSay(i, '所有关键信息都齐了 ✅ 我正在把简历解析结果与您刚才的回答做交叉计算…').then(() => {
      this.chatSay(i, '方案已生成。核心结论是：您的画像<b>「技术背景 + B 端产品 + AI 应用落地」</b>三重叠加，在 AI 产品方向上有明显优势，短板集中在数据决策与行业纵深。我把方向与下一步动作整理成了一份规划 👇').then(() => {
        if (!this.data.stack[i]) return;
        const plan = {
          concl: rich(GW_PLAN.concl),
          weeks: GW_PLAN.weeks,
          gaps: GW_PLAN.gaps,
          actions: GW_PLAN.actions,
          phases: GW_PLAN.phases,
          next: GW_PLAN.next,
          hint: GW_PLAN.hint
        };
        this.setData({ ['stack[' + i + '].vm.done']: true, ['stack[' + i + '].vm.plan']: plan, ['stack[' + i + '].vm.scrollInto']: 'msg-plan' });
        service.addPlan({
          rounds: GW_Q.length,
          dir: 'AI 产品经理',
          weeks: GW_PLAN.weeks,
          gaps: GW_PLAN.gaps,
          actions: GW_PLAN.actions,
          concl: GW_PLAN.concl.replace(/<[^>]+>/g, ''),
          phases: GW_PLAN.phases.map(x => x.slice()),
          next: GW_PLAN.next.slice()
        }).then(list => this.setData({ plans: list }));
      });
    });
  },

  onReplan(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.setData({
      ['stack[' + i + '].vm.hero']: true,
      ['stack[' + i + '].vm.msgs']: [],
      ['stack[' + i + '].vm.started']: false,
      ['stack[' + i + '].vm.step']: -1,
      ['stack[' + i + '].vm.done']: false,
      ['stack[' + i + '].vm.busy']: false,
      ['stack[' + i + '].vm.plan']: null,
      ['stack[' + i + '].vm.chipOn']: -1,
      ['stack[' + i + '].vm.input']: ''
    });
  },

  onOptTap(e) {
    const i = Number(e.currentTarget.dataset.i);
    const t = e.currentTarget.dataset.t;
    const layer = this.data.stack[i];
    if (layer.vm.busy || layer.vm.done) return;
    this.chatAnswer(i, t);
  },

  /* ================= 消息 ================= */
  onMsgOpen(e) {
    if (this._lp) { this._lp = false; return; }
    const id = e.currentTarget.dataset.id;
    const scope = e.currentTarget.dataset.scope;
    this.go(scope === 'ent' ? 'eMsgDetail' : 'msgDetail', { id });
  },

  onRelOpen(e) {
    const id = e.currentTarget.dataset.id;
    if (id) this.go('objDetail', { id });
  },

  onRelBtn(e) {
    const id = e.currentTarget.dataset.id;
    if (id) this.go('objDetail', { id });
    else this.toast('该消息没有关联内容');
  },

  onApOpen(e) {
    const i = Number(e.currentTarget.dataset.i);
    const vm2 = this.data.stack[i].vm;
    if (vm2.scope === 'ent') { this.go('eReceived'); return; }
    if (!vm2.relId) { this.toast('该消息没有关联内容'); return; }
    this.go('apDetail', { objId: vm2.relId });
  },

  /* ================= 我的发布 / 申请 ================= */
  onPostOpen(e) {
    const id = e.currentTarget.dataset.id;
    const kind = e.currentTarget.dataset.kind;
    if (kind) this.go('eObjDetail', { kind, id });
    else this.go('objDetail', { id });
  },

  onSegTab(e) {
    const i = Number(e.currentTarget.dataset.i);
    const t = Number(e.currentTarget.dataset.t);
    const layer = this.data.stack[i];
    const isEnt = layer.name === 'eMinePub';
    const labels = layer.vm.segs;
    let cards = [];
    if (isEnt) {
      const order = ['job', 'project', 'consult', 'train', 'coach'];
      const kind = order[t];
      cards = ((this.data.ePub || {})[kind] || []).map(it => vm.ePubCard(kind, it));
    } else {
      const keys = ['consult', 'project', 'coach'];
      const kind = keys[t];
      cards = ((this.data.myPub || {})[kind] || []).map(it => vm.postCard(kind, it));
    }
    this.setData({
      ['stack[' + i + '].vm.tab']: t,
      ['stack[' + i + '].vm.cards']: cards,
      ['stack[' + i + '].vm.empty']: cards.length === 0
    }, () => this.syncBar('segs' + i, t, 'stack[' + i + '].vm.bar'));
  },

  /* ================= 申请处理 ================= */
  onApCardTap(e) {
    const d = e.currentTarget.dataset;
    if (d.scope === 'ent' || !d.obj) return;
    this.go('apDetail', { objId: d.obj });
  },

  onApDecision(e) {
    const d = e.currentTarget.dataset;
    if (d.scope === 'ent') {
      if (d.ok === '1') this.onEApprove(e); else this.onEReject(e);
    } else {
      if (d.ok === '1') this.onApprove(e); else this.onReject(e);
    }
  },

  onApprove(e) {
    const i = Number(e.currentTarget.dataset.i);
    const id = e.currentTarget.dataset.id;
    const a = (this.data.applicants || []).find(x => x.id === id);
    this.openDialog({
      title: '同意该申请？',
      desc: '同意后将与「' + (a ? a.who : '') + '」互相开放联系方式，可在消息中继续沟通。',
      ok: '同意并建立联系',
      onOk: async () => {
        await service.decideApplicant(id, true);
        const arr = this.data.applicants.map(x => x.id === id ? Object.assign({}, x, { st: 1 }) : x);
        const items = arr.filter(x => x.objId === this.data.stack[i].vm.objId).map(x => vm.applicantCard(x, this.objTitle(x.objId)));
        this.setData({ applicants: arr, ['stack[' + i + '].vm.items']: items });
        this.toast('已同意，联系方式已互相开放');
      }
    });
  },

  onReject(e) {
    const i = Number(e.currentTarget.dataset.i);
    const id = e.currentTarget.dataset.id;
    const a = (this.data.applicants || []).find(x => x.id === id);
    this.openDialog({
      title: '不合适该申请？',
      desc: '拒绝后将通知对方，不会消耗联系次数。',
      ok: '确认拒绝',
      danger: true,
      onOk: async () => {
        await service.decideApplicant(id, false);
        const arr = this.data.applicants.map(x => x.id === id ? Object.assign({}, x, { st: 2 }) : x);
        const items = arr.filter(x => x.objId === this.data.stack[i].vm.objId).map(x => vm.applicantCard(x, this.objTitle(x.objId)));
        this.setData({ applicants: arr, ['stack[' + i + '].vm.items']: items });
        this.toast('已标记为不合适');
      }
    });
  },

  onEApprove(e) {
    const i = Number(e.currentTarget.dataset.i);
    const id = e.currentTarget.dataset.id;
    const a = (this.data.eApplies || []).find(x => x.id === id);
    this.openDialog({
      title: '同意该申请？',
      desc: '同意后将与「' + (a ? a.who : '') + '」互相开放联系方式，可在消息中继续沟通。',
      ok: '同意并建立联系',
      onOk: async () => {
        await service.decideCompanyApplicant(id, true);
        const arr = this.data.eApplies.map(x => x.id === id ? Object.assign({}, x, { st: 2 }) : x);
        this.setData({ eApplies: arr, ['stack[' + i + '].vm.items']: arr.map(vm.companyApplicantCard) });
        this.toast('已同意，联系方式已互相开放');
      }
    });
  },

  onEReject(e) {
    const i = Number(e.currentTarget.dataset.i);
    const id = e.currentTarget.dataset.id;
    const a = (this.data.eApplies || []).find(x => x.id === id);
    this.openDialog({
      title: '不合适该申请？',
      desc: '拒绝后将通知对方，不会消耗联系次数。',
      ok: '确认拒绝',
      danger: true,
      onOk: async () => {
        await service.decideCompanyApplicant(id, false);
        const arr = this.data.eApplies.map(x => x.id === id ? Object.assign({}, x, { st: 3 }) : x);
        this.setData({ eApplies: arr, ['stack[' + i + '].vm.items']: arr.map(vm.companyApplicantCard) });
        this.toast('已标记为不合适');
      }
    });
  },

  /* ================= 牛人 ================= */
  onTalentInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.setData({ ['stack[' + i + '].vm.q']: e.detail.value }, () => this.paintTalents(i));
  },

  onTalentSeg(e) {
    const i = Number(e.currentTarget.dataset.i);
    const s = Number(e.currentTarget.dataset.s);
    this.setData({ ['stack[' + i + '].vm.seg']: s }, () => this.paintTalents(i));
  },

  paintTalents(i) {
    const layer = this.data.stack[i];
    const v = layer.vm;
    const q = String(v.q || '').toLowerCase();
    let arr = (this.data.talents || []).filter(t => {
      if (v.seg === 1 && !/智能体|视觉|大模型|数据/.test(t.dir)) return false;
      if (v.seg === 2 && !/产品/.test(t.dir)) return false;
      if (v.seg === 3 && !/培训/.test(t.dir)) return false;
      if (q) {
        const hay = (t.name + t.dir + (t.skills || []).join('') + t.city).toLowerCase();
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    }).sort((a, b) => b.match - a.match);
    this.setData({
      ['stack[' + i + '].vm.cards']: arr.map(vm.talentCard),
      ['stack[' + i + '].vm.count']: '共 ' + arr.length + ' 位牛人 · 按匹配度排序',
      ['stack[' + i + '].vm.empty']: arr.length === 0
    });
  },

  onTalentOpen(e) { this.go('talentDetail', { id: e.currentTarget.dataset.id }); },

  onTalentChat(e) {
    const n = e.currentTarget.dataset.name;
    this.toast('已向 ' + n + ' 发起沟通，可在消息中查看');
  },

  onTalentInvite() { this.toast('面试邀约已发送，等待候选人确认'); },

  /* ================= 上传 / 投诉 ================= */
  onUploadResume(e) {
    const i = Number(e.currentTarget.dataset.i);
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      extension: ['pdf', 'doc', 'docx'],
      success: async res => {
        const f = res.tempFiles && res.tempFiles[0];
        if (!f) return;
        if (f.size > 10 * 1024 * 1024) { this.toast('文件超过 10 MB，请压缩后再上传'); return; }
        const nm = f.name.length > 20 ? f.name.slice(0, 20) + '…' : f.name;
        const size = f.size / 1024 / 1024 >= 1 ? (f.size / 1024 / 1024).toFixed(1) + ' MB' : Math.round(f.size / 1024) + ' KB';
        const list = await service.addResume({ name: nm, size, path: f.path });
        this.setData({ resumes: list, ['stack[' + i + '].vm.items']: list.map(vm.fileCard) });
        this.toast('简历已上传');
      }
    });
  },

  onComplaintInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    const k = e.currentTarget.dataset.k;
    this.setData({ ['stack[' + i + '].vm.' + k]: e.detail.value });
  },

  onComplaintType(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.openPicker('投诉类型', ['虚假职位', '薪资不符', '骚扰行为', '交付纠纷', '其他'], this.data.stack[i].vm.type, v => {
      this.setData({ ['stack[' + i + '].vm.type']: v });
    });
  },

  async onSubmitComplaint(e) {
    const i = Number(e.currentTarget.dataset.i);
    const v = this.data.stack[i].vm;
    if (!String(v.obj || '').trim()) { this.toast('请填写投诉对象'); return; }
    const list = await service.addComplaint(String(v.obj).trim(), v.type, String(v.desc || '').trim());
    this.setData({
      complaints: list,
      ['stack[' + i + '].vm.items']: list.map(vm.complaintCard),
      ['stack[' + i + '].vm.obj']: '',
      ['stack[' + i + '].vm.desc']: ''
    });
    this.toast('投诉已提交，平台将在 1 个工作日内受理');
  }
};
