const service = require('../../utils/service');
const vm = require('../../utils/vm');
const util = require('../../utils/util');
const seed = require('../../utils/seed');
const config = require('../../utils/config');

const TABS_P = [
  { key: 'home', label: '机会', icon: 'home' },
  { key: 'change', label: '职业规划', icon: 'change' },
  { key: 'push', label: '发布', icon: 'push', slot: true },
  { key: 'messages', label: '消息', icon: 'messages' },
  { key: 'mine', label: '我的', icon: 'mine' }
];
const TABS_E = [
  { key: 'coop', label: '合作', icon: 'coop' },
  { key: 'cert', label: '企业认证', icon: 'cert' },
  { key: 'push', label: '发布', icon: 'push', slot: true },
  { key: 'messages', label: '消息', icon: 'messages' },
  { key: 'mine', label: '我的', icon: 'mine' }
];
const P_TITLE = { 0: '大咖 · DAKA', 1: '职业规划', 3: '消息', 4: '我的' };
const E_TITLE = { 0: '大咖 · 企业', 1: '企业认证', 3: '消息', 4: '我的' };

const FUNCS = [
  { k: 'resume', t: '在线简历', i: 'func-resume' },
  { k: 'minePub', t: '我的发布', i: 'func-pub' },
  { k: 'mineApply', t: '我的申请', i: 'func-apply' },
  { k: 'received', t: '收到申请', i: 'func-received' }
];
const E_FUNCS = [
  { k: 'viewTalent', t: '查看牛人', i: 'talent' },
  { k: 'eMinePub', t: '我的发布', i: 'func-pub' },
  { k: 'eMineApply', t: '我的申请', i: 'func-apply' },
  { k: 'eReceived', t: '收到申请', i: 'func-received' }
];

const pageConfig = {
  data: {
    sb: 20,
    padTop: 94,
    role: 'personal',
    tab: 0,
    navTitle: '大咖 · DAKA',
    navGone: false,
    tabbarHide: false,
    fabOpen: false,
    tabPop: -1,
    tabs: TABS_P,

    cats: [],
    cat: 0,
    catBar: { left: 0, width: 0 },
    catScroll: 0,
    jobCards: [],

    ecats: [],
    ecat: 0,
    ecatBar: { left: 0, width: 0 },
    ecatScroll: 0,
    coopCards: [],

    msgs: [],
    emsgs: [],
    msgsRaw: [],
    emsgsRaw: [],
    me: {},
    meAvatar: '/assets/avatars/p0.jpg',
    mePhone: '',
    entCode: '',
    certL1: { lead: '现在完成', tail: '您的企业资质认证', desc: '认证通过后才能发布岗位、查看候选人简历、发起面试邀约；证照仅用于平台核验，不对外展示。', btn: '立即认证' },
    ent: {},
    funcs: FUNCS,
    efuncs: E_FUNCS,
    myPub: { consult: [], project: [], coach: [] },
    ePub: { job: [], project: [], consult: [], train: [], coach: [] },
    applicants: [],
    eApplies: [],
    myApplies: [],
    eMyApplies: [],
    resume: {},
    resumes: [],
    complaints: [],
    plans: [],
    talents: [],
    appliedJobs: [],

    cert: {},
    certEditing: false,
    certStep: 1,
    certDraft: {},
    certLogs: [],

    stack: [],
    sheet: { show: false, okText: '确定', cancelText: '取消' },
    picker: { show: false, title: '', opts: [], cur: '' },
    dialog: { show: false },
    toast: { show: false, text: '' },

    login: {
      show: true, out: false, role: 'personal', mode: 'pwd',
      agree: true, remember: true,
      phone: '13800136688', pwd: '123456', code: '',
      pwdShow: false, codeText: '获取验证码', codeDisabled: false,
      badge: '个人端',
      subtitle: '登录后继续，找到属于你的 AI 机会',
      submitting: false
    },
    loginBar: { left: 0, width: 0 },
    publish: { tab: 0, specs: [], groups: [], draft: [] }
  },

  /* ================= 生命周期 ================= */
  onLoad() {
    const app = getApp();
    const info = (app && app.globalData.systemInfo) || {};
    const w = info.windowWidth || 375;
    const sb = info.statusBarHeight || 20;
    this.scale = w / 440;
    this.W = w;
    this.scrollLeft = { cats: 0, ecats: 0 };
    this.setData({
      sb,
      padTop: sb + 47 * this.scale
    });
    this.loadData();
  },

  onReady() {
    this.syncBar('cats', this.data.cat, 'catBar', true);
    wx.nextTick(() => this.syncBar('lgModes', 0, 'loginBar'));
  },

  async loadData() {
    try {
      const d = await service.bootstrap();
      this.allJobs = d.jobs || [];
      this.allCoops = d.coops || [];
      this.allTalents = d.talents || [];
      this.setData({
        cats: d.cats || [],
        ecats: d.ecats || [],
        msgs: (d.messages || []).map(vm.msgCard),
        emsgs: (d.companyMessages || []).map(vm.msgCard),
        msgsRaw: d.messages || [],
        emsgsRaw: d.companyMessages || [],
        me: d.me || {},
        meAvatar: (d.me && d.me.avatar && d.me.avatar.src) || '/assets/avatars/p0.jpg',
        mePhone: util.maskPhone((d.me || {}).phone),
        entCode: '统一社会信用代码 ' + ((d.ent || {}).codeMask || ''),
        ent: d.ent || {},
        myPub: d.posts || { consult: [], project: [], coach: [] },
        ePub: d.companyPosts || { job: [], project: [], consult: [], train: [], coach: [] },
        applicants: d.applicants || [],
        eApplies: d.companyApplicants || [],
        myApplies: d.myApplications || [],
        eMyApplies: d.companyMyApplications || [],
        resume: d.resume || {},
        resumes: d.resumes || [],
        complaints: d.complaints || [],
        plans: d.plans || [],
        talents: d.talents || [],
        cert: d.cert || {},
        certStep: (d.cert && d.cert.step) || 1,
        appliedJobs: d.appliedJobs || []
      }, () => {
        this.renderJobs();
        this.renderCoops();
        this.updateCertL1(this.data.cert);
        this.syncBar('cats', this.data.cat, 'catBar', true);
      });
    } catch (e) {
      this.toast('数据加载失败，已使用本地演示数据');
    }
  },

  updateCertL1(c) {
    const st = (c || {}).state || 0;
    const map = st === 1
      ? { lead: '认证审核中', tail: '预计 1 个工作日完成', desc: '认证材料已提交，平台正在核验证照与工商信息；审核结果将以站内消息通知。', btn: '查看认证进度' }
      : st === 2
        ? { lead: '企业资质已认证', tail: '可发布岗位与查看候选人', desc: '认证通过后才能发布岗位、查看候选人简历、发起面试邀约；证照仅用于平台核验，不对外展示。', btn: '查看认证信息' }
        : { lead: '现在完成', tail: '您的企业资质认证', desc: '认证通过后才能发布岗位、查看候选人简历、发起面试邀约；证照仅用于平台核验，不对外展示。', btn: '立即认证' };
    this.setData({ certL1: map });
  },

  /* ================= 基础工具 ================= */
  toast(text) {
    clearTimeout(this._toastTimer);
    this.setData({ toast: { show: true, text } });
    this._toastTimer = setTimeout(() => {
      this.setData({ 'toast.show': false });
    }, 1700);
  },

  setLogin(key, val) {
    this.setData({ ['login.' + key]: val });
  },

  /* 分类 / 分段滑动条测量（与 demo 的 31.7px 指示条一致） */
  syncBar(groupId, active, barKey, noScroll) {
    const q = wx.createSelectorQuery().in(this);
    q.select('#' + groupId).boundingClientRect();
    q.selectAll('#' + groupId + ' .bar-item').boundingClientRect();
    q.select('#' + groupId + 'Wrap').boundingClientRect();
    q.exec(res => {
      const content = res[0];
      const items = res[1];
      const view = res[2] || content;
      if (!content || !items || !items[active]) return;
      const w = 31.7 * this.scale;
      const offset = items[active].left - content.left;
      const left = offset + (items[active].width - w) / 2;
      const patch = {};
      patch[barKey] = { left, width: w };
      if (!noScroll && this.scrollLeft[groupId] != null) {
        const target = Math.max(0, offset + this.scrollLeft[groupId] - view.width / 2 + items[active].width / 2);
        const key = groupId === 'cats' ? 'catScroll' : (groupId === 'ecats' ? 'ecatScroll' : '');
        if (key) patch[key] = target;
      }
      this.setData(patch);
    });
  },

  onCatScroll(e) { this.scrollLeft.cats = e.detail.scrollLeft; },
  onECatScroll(e) { this.scrollLeft.ecats = e.detail.scrollLeft; },

  /* ================= 一级页 ================= */
  renderJobs() {
    const key = (this.data.cats[this.data.cat] || {}).key || 'job';
    const list = (this.allJobs || []).filter(j => j.cat === key);
    this.setData({ jobCards: list.map(vm.jobCard) });
  },

  renderCoops() {
    const cat = this.data.ecats[this.data.ecat];
    const key = cat ? cat.key : 'project';
    const list = (this.allCoops || []).filter(x => x.cat === key);
    this.setData({ coopCards: list.map(it => vm.coopCard(it, cat ? cat.name : '')) });
  },

  onCat(e) {
    const i = Number(e.currentTarget.dataset.i);
    if (i === this.data.cat) return;
    this.setData({ cat: i });
    this.renderJobs();
    this.syncBar('cats', i, 'catBar');
  },

  onECat(e) {
    const i = Number(e.currentTarget.dataset.i);
    if (i === this.data.ecat) return;
    this.setData({ ecat: i });
    this.renderCoops();
    this.syncBar('ecats', i, 'ecatBar');
  },

  switchTab(i) {
    if (i === 2) { this.openPublish(); return; }
    this.closeAllL2();
    const role = this.data.role;
    const title = role === 'ent' ? E_TITLE[i] : P_TITLE[i];
    this.setData({
      tab: i,
      navTitle: title || (role === 'ent' ? '大咖 · 企业' : '大咖 · DAKA'),
      navGone: false,
      tabbarHide: false,
      tabPop: i
    });
    clearTimeout(this._popTimer);
    this._popTimer = setTimeout(() => this.setData({ tabPop: -1 }), 480);
    wx.nextTick(() => {
      if (i === 0 && role === 'personal') this.syncBar('cats', this.data.cat, 'catBar', true);
      if (i === 0 && role === 'ent') this.syncBar('ecats', this.data.ecat, 'ecatBar', true);
    });
  },

  onTab(e) {
    this.switchTab(Number(e.currentTarget.dataset.i));
  },

  applyRole(role) {
    const isEnt = role === 'ent';
    this.closeAllL2();
    this.setData({
      role: isEnt ? 'ent' : 'personal',
      tab: 0,
      navTitle: isEnt ? '大咖 · 企业' : '大咖 · DAKA',
      navGone: false,
      tabbarHide: false,
      tabs: isEnt ? TABS_E : TABS_P,
      funcs: isEnt ? E_FUNCS : FUNCS
    });
    wx.nextTick(() => {
      if (isEnt) this.syncBar('ecats', this.data.ecat, 'ecatBar', true);
      else this.syncBar('cats', this.data.cat, 'catBar', true);
    });
  },

  /* ================= 二级页路由 ================= */
  go(name, params) {
    params = params || {};
    const key = 'L' + Date.now() + Math.floor(Math.random() * 1000);
    const conf = this.buildPage(name, params, key);
    if (!conf) return;
    const stack = this.data.stack.slice();
    const layer = {
      key,
      name,
      title: conf.title,
      vm: conf.vm || {},
      footer: conf.footer || null,
      scrollClass: conf.scrollClass || '',
      in: false,
      scrollTop: 0
    };
    stack.push(layer);
    this.setData({ stack, navGone: true, tabbarHide: true, fabOpen: name === 'publish' || name === 'ePublish' });
    const idx = stack.length - 1;
    wx.nextTick(() => {
      this.setData({ ['stack[' + idx + '].in']: true });
      if (name === 'minePub' || name === 'eMinePub') {
        this.syncBar('segs' + idx, layer.vm.tab || 0, 'stack[' + idx + '].vm.bar');
      }
    });
  },

  back() {
    const stack = this.data.stack.slice();
    if (!stack.length) return;
    const i = stack.length - 1;
    const remain = stack.length - 1;
    this.setData({
      ['stack[' + i + '].in']: false,
      navGone: remain > 0,
      tabbarHide: remain > 0,
      fabOpen: remain > 0 && (stack[remain - 1].name === 'publish' || stack[remain - 1].name === 'ePublish')
    });
    setTimeout(() => {
      const st = this.data.stack.slice(0, -1);
      this.setData({ stack: st });
    }, 310);
  },

  closeAllL2() {
    this.setData({ stack: [], navGone: false, tabbarHide: false, fabOpen: false });
  },

  onBack() { this.back(); },

  onL2Scroll(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.data.stack[i].scrollTop = e.detail.scrollTop;
  },

  patchLayer(i, patch, cb) {
    const data = {};
    Object.keys(patch).forEach(k => {
      data['stack[' + i + '].vm.' + k] = patch[k];
    });
    this.setData(data, cb);
  },

  /* ================= 发布 ================= */
  openPublish() {
    const name = this.data.role === 'ent' ? 'ePublish' : 'publish';
    const top = this.data.stack[this.data.stack.length - 1];
    if (top && top.name === name) { this.back(); return; }
    this.setData({ fabOpen: true });
    this.go(name);
  },

  onFab() { this.openPublish(); },

  /* ================= 登录 ================= */
  onLoginRole(e) {
    const role = e.currentTarget.dataset.role === 'company' ? 'ent' : 'personal';
    this.setData({
      'login.role': role,
      'login.badge': role === 'ent' ? '企业端' : '个人端',
      'login.subtitle': role === 'ent' ? '登录后继续，管理招聘、项目与培训' : '登录后继续，找到属于你的 AI 机会'
    });
  },

  onLoginMode(e) {
    const mode = e.currentTarget.dataset.mode;
    if (this.data.login.mode === mode) return;
    this.setData({ 'login.mode': mode });
    wx.nextTick(() => this.syncBar('lgModes', mode === 'pwd' ? 0 : 1, 'loginBar'));
  },

  onPhoneInput(e) { this.setLogin('phone', e.detail.value); },
  onPwdInput(e) { this.setLogin('pwd', e.detail.value); },
  onCodeInput(e) { this.setLogin('code', e.detail.value); },

  onEye() { this.setLogin('pwdShow', !this.data.login.pwdShow); },
  onRemember() { this.setLogin('remember', !this.data.login.remember); },
  onAgree() { this.setLogin('agree', !this.data.login.agree); },

  onSendCode() {
    const l = this.data.login;
    if (!/^1[3-9]\d{9}$/.test(String(l.phone).trim())) { this.toast('请先填写正确的手机号'); return; }
    if (l.codeDisabled) return;
    let n = 60;
    this.setData({ 'login.codeDisabled': true, 'login.codeText': n + 's 后重发' });
    this.toast('验证码已发送，演示码 123456');
    clearInterval(this._codeTimer);
    this._codeTimer = setInterval(() => {
      n--;
      if (n <= 0) {
        clearInterval(this._codeTimer);
        this.setData({ 'login.codeDisabled': false, 'login.codeText': '获取验证码' });
      } else {
        this.setData({ 'login.codeText': n + 's 后重发' });
      }
    }, 1000);
  },

  async onLogin() {
    const l = this.data.login;
    if (!l.agree) { this.toast('请先阅读并同意用户协议'); return; }
    if (!/^1[3-9]\d{9}$/.test(String(l.phone).trim())) { this.toast('请输入正确的手机号'); return; }
    if (l.mode === 'pwd') {
      if (String(l.pwd).trim().length < 6) { this.toast('密码至少 6 位'); return; }
    } else if (String(l.code).trim().length < 4) {
      this.toast('请输入验证码'); return;
    }
    this.setData({ 'login.submitting': true });
    try {
      const res = await service.login({ role: l.role, mode: l.mode, phone: l.phone, password: l.pwd, code: l.code });
      this.afterLogin(res, l.role);
    } catch (e) {
      this.setData({ 'login.submitting': false });
    }
  },

  async onWechat() {
    const l = this.data.login;
    if (!l.agree) { this.toast('请先阅读并同意用户协议'); return; }
    this.toast('正在唤起微信…');
    try {
      let code = 'mock-code';
      if (!service.USE_MOCK) {
        const r = await new Promise((resolve, reject) => {
          wx.login({ success: resolve, fail: reject });
        });
        code = r.code;
      }
      const res = await service.login({ mode: 'wechat', code, role: l.role });
      setTimeout(() => this.afterLogin(res, l.role), 300);
    } catch (e) {
      this.setData({ 'login.submitting': false });
    }
  },

  afterLogin(res, role) {
    const app = getApp();
    if (app) {
      app.globalData.token = (res && res.token) || '';
      app.globalData.role = role;
    }
    if (res && res.token) wx.setStorageSync(config.TOKEN_KEY, res.token);
    this.setData({ 'login.submitting': false });
    this.hideLogin();
    this.applyRole(role);
    setTimeout(() => {
      const ent = this.data.ent || {};
      this.toast(role === 'ent' ? '欢迎回来，' + (ent.short || ent.name || '') : '欢迎回来，' + ((this.data.me || {}).name || ''));
    }, 420);
  },

  hideLogin() {
    this.setData({ 'login.out': true });
    setTimeout(() => this.setData({ 'login.show': false }), 380);
  },

  showLogin() {
    this.setData({ 'login.show': true, 'login.out': true });
    setTimeout(() => this.setData({ 'login.out': false }), 30);
  },

  onForgot() { this.toast('重置链接已发送到你的手机'); },
  onSignup() { this.toast('注册功能开发中，敬请期待'); },

  /* ================= 通用弹层 ================= */
  openDialog(o) {
    this._dlgOk = o.onOk || null;
    this.setData({
      dialog: {
        show: true,
        title: o.title || '提示',
        desc: o.desc || '',
        ok: o.ok || '确定',
        cancel: o.cancel === null ? '' : (o.cancel || '取消'),
        danger: !!o.danger
      }
    });
  },

  closeDialog() {
    this.setData({ 'dialog.show': false });
    this._dlgOk = null;
  },

  onDlgOk() {
    const fn = this._dlgOk;
    this.setData({ 'dialog.show': false });
    this._dlgOk = null;
    if (fn) fn();
  },

  openPicker(title, opts, cur, cb) {
    this._pickCb = cb;
    this.setData({ picker: { show: true, title, opts, cur: cur || '' } });
  },

  closePicker() { this.setData({ 'picker.show': false }); this._pickCb = null; },

  onPick(e) {
    const v = e.currentTarget.dataset.v;
    const cb = this._pickCb;
    this.setData({ 'picker.show': false });
    this._pickCb = null;
    if (cb) cb(v);
  },

  onMaskTap() {
    this.setData({ 'sheet.show': false, 'picker.show': false, 'dialog.show': false });
    this._pickCb = null;
    this._sheetOk = null;
  },

  /* ================= 消息长按删除 ================= */
  onMsgLong(e) {
    this._lp = true;
    setTimeout(() => { this._lp = false; }, 800);
    const id = e.currentTarget.dataset.id;
    const scope = e.currentTarget.dataset.scope;
    const list = scope === 'ent' ? this.data.emsgs : this.data.msgs;
    const m = list.find(x => x.id === id);
    this.openDialog({
      title: '删除这条消息？',
      desc: '删除后不可恢复，' + (m ? m.name : '该联系人') + '的会话记录将一并清除。',
      ok: '删除',
      danger: true,
      onOk: async () => {
        await service.deleteMessage(scope, id);
        const arr = (scope === 'ent' ? this.data.emsgs : this.data.msgs).filter(x => x.id !== id);
        this.setData(scope === 'ent' ? { emsgs: arr } : { msgs: arr });
        this.toast('已删除');
      }
    });
  },

  onLogout() {
    this.openDialog({
      title: '退出登录？',
      desc: '退出后需要重新登录才能继续使用大咖',
      ok: '退出登录',
      danger: true,
      onOk: () => {
        wx.removeStorageSync(config.TOKEN_KEY);
        const app = getApp();
        if (app) app.globalData.token = '';
        this.showLogin();
        this.toast('已退出登录');
      }
    });
  },

  onMore(e) {
    const k = e.currentTarget.dataset.more;
    if (k === 'resume') this.go('uploadResume');
    else this.go('complaint');
  },

  onFunc(e) {
    const k = e.currentTarget.dataset.k;
    this.go(k);
  },

  onEditMe() { this.go('editMe'); },

  onShareAppMessage() {
    return { title: '大咖 DAKA · AI 人才与机会平台', path: '/pages/index/index' };
  }
};

Object.assign(pageConfig, require('./pages'), require('./forms'));
Page(pageConfig);
