/* 表单类二级页：发布 / 企业认证 / 编辑资料 */
const service = require('../../utils/service');
const util = require('../../utils/util');
const { avatarOf } = require('../../utils/avatar');
const seed = require('../../utils/seed');

const CITIES = ['深圳', '广州', '杭州', '北京', '上海'];
const EXP_OPTS = ['不限', '在校/应届', '1 年以下', '1–3 年', '3–5 年', '5–10 年', '10 年以上'];
const EDU_OPTS = ['不限', '大专', '本科', '硕士', '博士'];

const PUB_SPECS = [
  {
    key: 'consult', label: '发布数智化咨询', minDesc: 'desc',
    groups: [
      {
        cap: '需求信息', fields: [
          { k: 'title', label: '咨询主题', type: 'text', req: 1, ph: '如：中小企业 AI 招聘落地路径' },
          { k: 'type', label: '咨询类型', type: 'sel', opts: ['项目制咨询', '诊断评估', '长期顾问', '按次结算', '驻场咨询'] },
          { k: 'scene', label: '业务场景', type: 'sel', opts: ['企业内部系统', '招聘与人力', '销售与营销', '数据与经营', '其他'] },
          { k: 'size', label: '组织规模', type: 'sel', opts: ['50 人以下', '50-200 人', '200-1000 人', '1000 人以上'] },
          { k: 'budget', label: '预算区间', type: 'sel', opts: ['10 万以内', '10-50 万', '50-100 万', '100 万以上', '待评估'] },
          { k: 'cycle', label: '项目周期', type: 'sel', opts: ['1 个月内', '1-3 个月', '3-6 个月', '6 个月以上'] },
          { k: 'city', label: '所在城市', type: 'sel', opts: CITIES }
        ]
      },
      {
        cap: '需求详情', fields: [
          { k: 'desc', label: '需求描述', type: 'ta', req: 1, max: 500, ph: '简述当前痛点、已有系统与期望达成的目标（至少 10 个字）' }
        ]
      }
    ]
  },
  {
    key: 'project', label: '发布项目外包',
    groups: [
      {
        cap: '项目信息', fields: [
          { k: 'title', label: '需求名称', type: 'text', req: 1, ph: '如：企业级 AI 知识库建设全案' },
          { k: 'ptype', label: '发布方类型', type: 'sel', opts: ['企业', '政府', '个人'] },
          { k: 'coop', label: '合作方式', type: 'sel', opts: ['线上', '线下'] },
          { k: 'city', label: '所在城市', type: 'sel', opts: CITIES },
          { k: 'catg', label: '项目分类', type: 'sel', opts: ['外部项目交付', '项目外包', '员工能力提升', '业务数字化升级'] },
          { k: 'budget', label: '预算区间', type: 'sel', opts: ['10 万以内', '10-50 万', '50-100 万', '100-200 万', '200 万以上', '面议'] },
          { k: 'deadline', label: '截止日期', type: 'sel', opts: ['1 周内', '2 周内', '1 个月内', '3 个月内', '长期有效'] }
        ]
      },
      {
        cap: '需求详情', fields: [
          { k: 'desc', label: '需求描述', type: 'ta', req: 1, max: 500, ph: '描述项目背景、范围与交付物' },
          { k: 'req', label: '验收标准', type: 'ta', max: 300, ph: '可量化的验收口径' }
        ]
      }
    ]
  },
  {
    key: 'coach', label: '发布AI私教',
    groups: [
      {
        cap: '服务信息', fields: [
          { k: 'title', label: '服务名称', type: 'text', req: 1, ph: '如：零基础转行 AI 产品经理 12 周私教' },
          { k: 'type', label: '服务类型', type: 'sel', opts: ['一对一私教', '小组课', '月度陪跑', '单次答疑', '驻场辅导'] },
          { k: 'count', label: '招募人数', type: 'sel', opts: ['1 人', '2-5 人', '6-10 人', '10 人以上'] },
          { k: 'fee', label: '课时费', type: 'sel', opts: ['200 元/时以内', '200-300 元/时', '300-500 元/时', '500-800 元/时', '800 元/时以上'] },
          { k: 'city', label: '服务城市', type: 'sel', opts: ['线上'].concat(CITIES) },
          { k: 'exp', label: '经验要求', type: 'sel', opts: EXP_OPTS },
          { k: 'edu', label: '最低学历', type: 'sel', opts: EDU_OPTS }
        ]
      },
      {
        cap: '服务详情', fields: [
          { k: 'desc', label: '服务内容', type: 'ta', req: 1, max: 500, ph: '描述服务方式、周期与交付物' },
          { k: 'req', label: '报名要求', type: 'ta', max: 300, ph: '硬性条件，如经验、时间投入' }
        ]
      }
    ]
  }
];

const PUB_SPECS_E = [
  {
    key: 'job', label: '发布岗位', minDesc: 'desc',
    groups: [
      {
        cap: '岗位信息', fields: [
          { k: 'title', label: '岗位名称', type: 'text', req: 1, ph: '如：AI 产品经理（Agent 方向）' },
          { k: 'type', label: '招聘类型', type: 'sel', opts: ['全职', '兼职', '实习'] },
          { k: 'city', label: '工作城市', type: 'sel', opts: CITIES },
          { k: 'exp', label: '经验要求', type: 'sel', opts: EXP_OPTS },
          { k: 'edu', label: '学历要求', type: 'sel', opts: EDU_OPTS },
          { k: 'salary', label: '薪资区间', type: 'sel', opts: ['8-12k', '12-20k', '20-30k', '25-40k', '30-50k', '50k 以上', '面议'] },
          { k: 'count', label: '招聘人数', type: 'sel', opts: ['1 人', '2-5 人', '5-10 人', '10 人以上'] }
        ]
      },
      {
        cap: '岗位详情', fields: [
          { k: 'desc', label: '岗位职责', type: 'ta', req: 1, max: 500, ph: '描述核心职责、业务场景与团队情况（至少 10 个字）' },
          { k: 'req', label: '任职要求', type: 'ta', max: 300, ph: '硬性条件，如经验、技能、学历' }
        ]
      }
    ]
  },
  {
    key: 'project', label: '发布项目外包',
    groups: [
      {
        cap: '项目信息', fields: [
          { k: 'title', label: '项目名称', type: 'text', req: 1, ph: '如：企业级 AI 知识库建设全案' },
          { k: 'ptype', label: '发布方类型', type: 'sel', opts: ['企业', '政府', '个人'] },
          { k: 'coop', label: '合作方式', type: 'sel', opts: ['线上', '线下', '线上 + 线下'] },
          { k: 'city', label: '所在城市', type: 'sel', opts: CITIES },
          { k: 'catg', label: '项目分类', type: 'sel', opts: ['外部项目交付', '项目外包', '员工能力提升', '业务数字化升级'] },
          { k: 'budget', label: '预算区间', type: 'sel', opts: ['10 万以内', '10-50 万', '50-100 万', '100-200 万', '200 万以上', '面议'] },
          { k: 'deadline', label: '截止日期', type: 'sel', opts: ['1 周内', '2 周内', '1 个月内', '3 个月内', '长期有效'] }
        ]
      },
      {
        cap: '需求详情', fields: [
          { k: 'desc', label: '需求描述', type: 'ta', req: 1, max: 500, ph: '描述项目背景、范围与交付物' },
          { k: 'req', label: '验收标准', type: 'ta', max: 300, ph: '可量化的验收口径' }
        ]
      }
    ]
  },
  {
    key: 'consult', label: '数智化咨询', minDesc: 'desc',
    groups: [
      {
        cap: '需求信息', fields: [
          { k: 'title', label: '咨询主题', type: 'text', req: 1, ph: '如：集团 AI 场景诊断与落地路线' },
          { k: 'type', label: '咨询类型', type: 'sel', opts: ['项目制咨询', '诊断评估', '长期顾问', '按次结算', '驻场咨询'] },
          { k: 'scene', label: '业务场景', type: 'sel', opts: ['企业内部系统', '招聘与人力', '销售与营销', '数据与经营', '其他'] },
          { k: 'size', label: '组织规模', type: 'sel', opts: ['50 人以下', '50-200 人', '200-1000 人', '1000 人以上'] },
          { k: 'budget', label: '预算区间', type: 'sel', opts: ['10 万以内', '10-50 万', '50-100 万', '100 万以上', '待评估'] },
          { k: 'cycle', label: '项目周期', type: 'sel', opts: ['1 个月内', '1-3 个月', '3-6 个月', '6 个月以上'] },
          { k: 'city', label: '所在城市', type: 'sel', opts: CITIES }
        ]
      },
      {
        cap: '需求详情', fields: [
          { k: 'desc', label: '需求描述', type: 'ta', req: 1, max: 500, ph: '简述当前痛点、已有系统与期望达成的目标（至少 10 个字）' }
        ]
      }
    ]
  },
  {
    key: 'train', label: '发布AI培训', minDesc: 'desc',
    groups: [
      {
        cap: '培训信息', fields: [
          { k: 'title', label: '课程名称', type: 'text', req: 1, ph: '如：大模型应用开发实战训练营' },
          { k: 'type', label: '培训类型', type: 'sel', opts: ['企业内训', '公开课', '实战训练营', '工作坊', '线上课'] },
          { k: 'audience', label: '培训对象', type: 'sel', opts: ['管理层', '中层管理者', '业务骨干', '技术团队', '全员'] },
          { k: 'count', label: '培训人数', type: 'sel', opts: ['20 人以内', '20-50 人', '50-100 人', '100 人以上'] },
          { k: 'cycle', label: '培训周期', type: 'sel', opts: ['3-5 天', '2-4 周', '4-6 周', '6-8 周', '长期陪跑'] },
          { k: 'budget', label: '预算区间', type: 'sel', opts: ['8 万以内', '8-30 万', '30-60 万', '60 万以上', '面议'] },
          { k: 'city', label: '培训城市', type: 'sel', opts: ['线上'].concat(CITIES) }
        ]
      },
      {
        cap: '课程详情', fields: [
          { k: 'desc', label: '课程内容', type: 'ta', req: 1, max: 500, ph: '描述课程模块、实战案例与交付形式（至少 10 个字）' },
          { k: 'req', label: '交付要求', type: 'ta', max: 300, ph: '如讲师资质、结业标准、效果评估' }
        ]
      }
    ]
  },
  {
    key: 'coach', label: '发布AI私教',
    groups: [
      {
        cap: '服务信息', fields: [
          { k: 'title', label: '服务名称', type: 'text', req: 1, ph: '如：企业内训师 AI 私教' },
          { k: 'type', label: '服务类型', type: 'sel', opts: ['一对一私教', '小组课', '月度陪跑', '单次答疑', '驻场辅导'] },
          { k: 'count', label: '招募人数', type: 'sel', opts: ['1 人', '2-5 人', '6-10 人', '10 人以上'] },
          { k: 'fee', label: '课时费', type: 'sel', opts: ['200 元/时以内', '200-300 元/时', '300-500 元/时', '500-800 元/时', '800 元/时以上'] },
          { k: 'city', label: '服务城市', type: 'sel', opts: ['线上'].concat(CITIES) },
          { k: 'exp', label: '经验要求', type: 'sel', opts: EXP_OPTS },
          { k: 'edu', label: '最低学历', type: 'sel', opts: EDU_OPTS }
        ]
      },
      {
        cap: '服务详情', fields: [
          { k: 'desc', label: '服务内容', type: 'ta', req: 1, max: 500, ph: '描述服务方式、周期与交付物' },
          { k: 'req', label: '报名要求', type: 'ta', max: 300, ph: '硬性条件，如经验、时间投入' }
        ]
      }
    ]
  }
];

const CERT_STEPS = ['主体信息', '资质证照', '经营与开票', '联系人验证'];

function fillGroups(spec, draft) {
  return spec.groups.map(g => ({
    cap: g.cap,
    fields: g.fields.map(f => ({
      k: f.k, label: f.label, type: f.type, req: f.req, ph: f.ph, max: f.max || 500,
      opts: f.opts || [],
      value: draft[f.k] != null ? draft[f.k] : '',
      showPh: !(draft[f.k] != null && draft[f.k] !== '')
    }))
  }));
}

module.exports = {
  buildForm(name, p, key) {
    if (name === 'publish' || name === 'ePublish') {
      const ent = name === 'ePublish';
      const specs = ent ? PUB_SPECS_E : PUB_SPECS;
      this._pub = this._pub || {};
      this._pub[key] = { drafts: specs.map(() => ({})), tab: 0 };
      return {
        title: '发布需求',
        scrollClass: 'pub-body',
        vm: {
          ent,
          tab: 0,
          labels: specs.map(s => s.label),
          groups: fillGroups(specs[0], {}),
          specKey: specs[0].key
        },
        footer: { type: 'publish', segs: specs.map(s => s.label) }
      };
    }

    if (name === 'cert') {
      const c = this.data.cert || {};
      const state = c.state || 0;
      if (state > 0 && !this.data.certEditing) return this.buildCertStatus(c);
      const w = this.buildCertWizard(c);
      return {
        title: '企业认证',
        vm: w,
        footer: { type: 'cert', step: w.step, prevDisabled: w.step === 1, nextText: w.step === 4 ? '提交审核' : '下一步' }
      };
    }

    if (name === 'editMe') {
      const me = this.data.me || {};
      return {
        title: '编辑资料',
        vm: {
          name: me.name || '',
          phone: me.phone || '',
          email: me.email || '',
          city: me.city || '深圳',
          state: me.state || '在职 · 月内到岗',
          avatar: avatarOf(me.name || '王旭'),
          avatarSeed: '王旭',
          panel: false,
          presets: Array.from({ length: 12 }, (_, i) => ({
            i, seed: 'me-' + i, src: avatarOf('me-' + i)
          }))
        }
      };
    }

    return null;
  },

  buildCertWizard(c) {
    const d = Object.assign({
      cName: c.name, cCode: c.code, cYear: c.year, cType: c.type,
      cSize: c.size, cAddr: c.addr, cSite: c.site, cScope: c.scope,
      cLegal: c.legal, cLegalId: c.legalId,
      cInvTitle: (c.invoice || {}).title, cInvTax: (c.invoice || {}).tax,
      cInvBank: (c.invoice || {}).bank, cInvAcct: (c.invoice || {}).acct,
      cYearHire: '10-50 人',
      cDirs: ['AI 产品', '算法 / 大模型'],
      cContact: c.contact, cTitle: c.contactTitle, cMobile: c.mobile,
      cEmail: c.email, cCode2: '123456'
    }, this.data.certDraft || {});
    this._certDraft = d;
    return {
      mode: 'wizard',
      steps: CERT_STEPS,
      step: this.data.certStep || 1,
      p1: this.certFields(d, 1),
      p2: this.certFields(d, 2),
      p3: this.certFields(d, 3),
      p4: this.certFields(d, 4),
      dirs: ['AI 产品', '算法 / 大模型', 'AI 运营', '数据标注与评测', '前端 / 全栈', 'AI 设计'].map(x => ({
        text: x, on: (d.cDirs || []).indexOf(x) >= 0
      })),
      lic: '营业执照-云启智能-2026.pdf',
      authFile: '授权委托书-李明签章.pdf',
      code2: d.cCode2 || '',
      codeText: '获取验证码',
      codeDisabled: false
    };
  },

  certFields(d, step) {
    const F = (k, label, ph, req) => ({ k, label, ph, req: !!req, type: 'text', value: d[k] != null ? d[k] : '' });
    const S = (k, label, opts, req) => ({
      k, label, opts, req: !!req, type: 'sel',
      value: d[k] != null ? d[k] : '', showPh: !d[k]
    });
    const T = (k, label, ph) => ({ k, label, ph, type: 'ta', value: d[k] != null ? d[k] : '', max: 200 });
    if (step === 1) {
      return [
        F('cName', '企业全称', '须与营业执照完全一致', 1),
        F('cCode', '统一社会信用代码', '18 位', 1),
        F('cYear', '成立年份', '如 2017'),
        S('cType', '企业类型', ['有限责任公司', '股份有限公司', '个体工商户', '合伙企业', '其他']),
        S('cSize', '员工规模', ['20 人以下', '20-50 人', '50-200 人', '200-500 人', '500-1000 人', '1000 人以上']),
        F('cAddr', '注册地址', '省 / 市 / 区 + 详细地址', 1),
        F('cSite', '官网', '选填'),
        T('cScope', '经营范围', '与营业执照保持一致')
      ];
    }
    if (step === 2) {
      return [
        F('cLegal', '法定代表人', '', 1),
        F('cLegalId', '法人证件号', '', 1)
      ];
    }
    if (step === 3) {
      return [
        F('cInvTitle', '发票抬头', ''),
        F('cInvTax', '纳税人识别号', ''),
        F('cInvBank', '开户行', ''),
        F('cInvAcct', '银行账号', ''),
        S('cYearHire', '预计年招聘量', ['10 人以内', '10-50 人', '50-200 人', '200 人以上'])
      ];
    }
    return [
      F('cContact', '联系人', '', 1),
      F('cTitle', '职务', '', 1),
      F('cMobile', '手机号', '用于接收审核结果', 1),
      F('cEmail', '邮箱', '接收合同与发票通知', 1)
    ];
  },

  buildCertStatus(c) {
    const st = c.state || 1;
    const logs = (c.logs && c.logs.length) ? c.logs : [
      { t: '提交认证申请', d: (c.submitAt || util.nowText()) + ' · 提交主体信息与证照材料', s: 'ok' },
      { t: '平台审核中', d: '当前节点：证照核验（预计 1 个工作日内完成）', s: 'on' }
    ];
    return {
      title: '企业认证',
      vm: {
        mode: 'status',
        state: st,
        pillText: st === 2 ? '已认证' : '审核中',
        pillCls: st === 2 ? '' : 'orange',
        name: c.name,
        code: c.code,
        type: c.type,
        year: c.year,
        size: c.size,
        addr: c.addr,
        legal: c.legal,
        contact: c.contact,
        contactTitle: c.contactTitle,
        lic: c.lic,
        authFile: c.authFile,
        legalId: c.legalId,
        logs
      },
      footer: { type: 'certStatus', state: st }
    };
  },

  /* ================= 发布交互 ================= */
  layerKey(i) {
    const l = this.data.stack[i];
    return l ? l.key : 'none';
  },

  onPubTab(e) {
    const i = Number(e.currentTarget.dataset.i);
    const t = Number(e.currentTarget.dataset.t);
    const layer = this.data.stack[i];
    const ent = layer.vm.ent;
    const specs = ent ? PUB_SPECS_E : PUB_SPECS;
    if (t === layer.vm.tab) return;
    const key = layer.key;
    const st = this._pub[key];
    st.drafts[layer.vm.tab] = this.collectFields(layer.vm.groups);
    st.tab = t;
    const draft = st.drafts[t] || {};
    this.setData({
      ['stack[' + i + '].vm.tab']: t,
      ['stack[' + i + '].vm.groups']: fillGroups(specs[t], draft),
      ['stack[' + i + '].vm.specKey']: specs[t].key
    });
  },

  collectFields(groups) {
    const d = {};
    (groups || []).forEach(g => (g.fields || []).forEach(f => { d[f.k] = f.value; }));
    return d;
  },

  onPubInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    const g = Number(e.currentTarget.dataset.g);
    const f = Number(e.currentTarget.dataset.f);
    const v = e.detail.value;
    this.setData({
      ['stack[' + i + '].vm.groups[' + g + '].fields[' + f + '].value']: v
    });
  },

  onPubSelect(e) {
    const i = Number(e.currentTarget.dataset.i);
    const g = Number(e.currentTarget.dataset.g);
    const f = Number(e.currentTarget.dataset.f);
    const field = this.data.stack[i].vm.groups[g].fields[f];
    this.openPicker(field.label, field.opts, field.value, v => {
      this.setData({
        ['stack[' + i + '].vm.groups[' + g + '].fields[' + f + '].value']: v,
        ['stack[' + i + '].vm.groups[' + g + '].fields[' + f + '].showPh']: false
      });
    });
  },

  async onPubSubmit(e) {
    const i = Number(e.currentTarget.dataset.i);
    const layer = this.data.stack[i];
    const ent = layer.vm.ent;
    const specs = ent ? PUB_SPECS_E : PUB_SPECS;
    const spec = specs[layer.vm.tab];
    const key = layer.key;
    const st = this._pub[key];
    st.drafts[layer.vm.tab] = this.collectFields(layer.vm.groups);
    const d = st.drafts[layer.vm.tab];
    const flat = spec.groups.reduce((a, g) => a.concat(g.fields), []);
    for (const f of flat) {
      if (f.req && !String(d[f.k] || '').trim()) { this.toast('请填写' + f.label); return; }
    }
    if (spec.minDesc && String(d[spec.minDesc] || '').trim().length < 10) { this.toast('需求描述至少 10 个字'); return; }

    const item = {
      title: d.title, time: util.nowShort(), status: '待审核', applies: 0,
      desc: d.desc || '', req: d.req || '', tags: ent ? ['企业发布'] : []
    };
    if (spec.key === 'job') Object.assign(item, {
      salary: d.salary || '面议', bonus: '13薪', city: d.city || '深圳', exp: d.exp || '不限',
      edu: d.edu || '本科', type: d.type || '全职', count: d.count || '1 人',
      tags: [d.type || '全职', '企业发布']
    });
    if (spec.key === 'project') Object.assign(item, {
      ptype: d.ptype || '企业', coop: d.coop || '线上', city: d.city || '深圳',
      catg: d.catg || '项目外包', budget: d.budget || '面议', deadline: d.deadline || '长期有效',
      cycle: '待评估', tags: [d.catg || '项目外包']
    });
    if (spec.key === 'consult') Object.assign(item, {
      type: d.type || '项目制咨询', scene: d.scene || '其他', size: d.size || '50-200 人',
      budget: d.budget || '待评估', cycle: d.cycle || '1-3 个月', city: d.city || '深圳',
      tags: ['数智化咨询']
    });
    if (spec.key === 'train') Object.assign(item, {
      budget: d.budget || '面议', cycle: d.cycle || '6 周', city: d.city || '线上',
      type: d.type || '企业内训', count: d.count || '30 人', audience: d.audience || '全员',
      tags: [d.type || '企业内训', 'AI 培训']
    });
    if (spec.key === 'coach') Object.assign(item, {
      type: d.type || '一对一私教', fee: d.fee || '面议', count: d.count || '1 人',
      city: d.city || '线上', exp: d.exp || '不限', edu: d.edu || '不限', tags: ['AI 私教']
    });

    const created = await service.createPost(spec.key, item, ent);
    this.toast('发布成功，平台将在 1 个工作日内完成审核');

    if (ent) {
      const ePub = JSON.parse(JSON.stringify(this.data.ePub));
      if (!ePub[spec.key]) ePub[spec.key] = [];
      ePub[spec.key].unshift(Object.assign({ id: created.id, cat: spec.key }, item));
      this.closeAllL2();
      this.switchTab(4);
      this.setData({ ePub });
      const order = ['job', 'project', 'consult', 'train', 'coach'];
      this.go('eMinePub', { tab: Math.max(0, order.indexOf(spec.key)) });
    } else {
      const myPub = JSON.parse(JSON.stringify(this.data.myPub));
      if (!myPub[spec.key]) myPub[spec.key] = [];
      myPub[spec.key].unshift(Object.assign({ id: created.id, cat: spec.key }, item));
      this.closeAllL2();
      this.switchTab(0);
      this.setData({ myPub });
      this.renderJobs();
    }
  },

  /* ================= 企业认证 ================= */
  onCertInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    const k = e.currentTarget.dataset.k;
    const step = Number(e.currentTarget.dataset.s);
    const v = e.detail.value;
    this._certDraft = this._certDraft || {};
    this._certDraft[k] = v;
    if (k === 'cCode2') {
      this.setData({ ['stack[' + i + '].vm.code2']: v });
      return;
    }
    const list = this.data.stack[i].vm['p' + step];
    const idx = list.findIndex(f => f.k === k);
    if (idx >= 0) this.setData({ ['stack[' + i + '].vm.p' + step + '[' + idx + '].value']: v });
  },

  onCertSelect(e) {
    const i = Number(e.currentTarget.dataset.i);
    const k = e.currentTarget.dataset.k;
    const step = Number(e.currentTarget.dataset.s);
    const f = this.data.stack[i].vm['p' + step].find(x => x.k === k);
    if (!f) return;
    this.openPicker(f.label, f.opts, f.value, v => {
      this._certDraft[k] = v;
      const list = this.data.stack[i].vm['p' + step];
      const idx = list.findIndex(x => x.k === k);
      this.setData({
        ['stack[' + i + '].vm.p' + step + '[' + idx + '].value']: v,
        ['stack[' + i + '].vm.p' + step + '[' + idx + '].showPh']: false
      });
    });
  },

  onCertDir(e) {
    const i = Number(e.currentTarget.dataset.i);
    const idx = Number(e.currentTarget.dataset.d);
    const cur = this.data.stack[i].vm.dirs[idx].on;
    const name = this.data.stack[i].vm.dirs[idx].text;
    const dirs = this.data.stack[i].vm.dirs.map((x, k) => k === idx ? { text: x.text, on: !cur } : x);
    const picked = dirs.filter(x => x.on).map(x => x.text);
    this._certDraft = this._certDraft || {};
    this._certDraft.cDirs = picked;
    this.setData({ ['stack[' + i + '].vm.dirs']: dirs });
  },

  onCertUpload(e) {
    const name = e.currentTarget.dataset.name;
    this.toast('演示环境：已重新上传「' + name + '」');
  },

  onCertSendCode(e) {
    const i = Number(e.currentTarget.dataset.i);
    const vm = this.data.stack[i].vm;
    const mobile = (this._certDraft || {}).cMobile || '';
    if (!/^1[3-9]\d{9}$/.test(String(mobile).replace(/\s/g, ''))) { this.toast('请先填写正确的手机号'); return; }
    if (vm.codeDisabled) return;
    let n = 60;
    this.setData({ ['stack[' + i + '].vm.codeDisabled']: true, ['stack[' + i + '].vm.codeText']: n + 's 后重发' });
    this.toast('验证码已发送，演示码 123456');
    clearInterval(this._certTimer);
    this._certTimer = setInterval(() => {
      n--;
      if (n <= 0) {
        clearInterval(this._certTimer);
        this.setData({ ['stack[' + i + '].vm.codeDisabled']: false, ['stack[' + i + '].vm.codeText']: '获取验证码' });
      } else {
        this.setData({ ['stack[' + i + '].vm.codeText']: n + 's 后重发' });
      }
    }, 1000);
  },

  onCertPrev(e) {
    const i = Number(e.currentTarget.dataset.i);
    const step = Number(this.data.stack[i].vm.step);
    if (step <= 1) return;
    this.setData({
      ['stack[' + i + '].vm.step']: step - 1,
      ['stack[' + i + '].footer.step']: step - 1,
      ['stack[' + i + '].footer.prevDisabled']: step - 1 === 1,
      ['stack[' + i + '].footer.nextText']: '下一步'
    });
    this.setData({ certStep: step - 1 });
  },

  async onCertNext(e) {
    const i = Number(e.currentTarget.dataset.i);
    const layer = this.data.stack[i];
    const step = Number(layer.vm.step);
    const v = layer.vm;
    if (step === 1) {
      const d = this.certValues(v);
      if (!String(d.cName || '').trim()) { this.toast('请填写企业全称'); return; }
      if (!/^[0-9A-Z]{18}$/.test(String(d.cCode || '').trim())) { this.toast('请填写 18 位统一社会信用代码'); return; }
      if (!String(d.cAddr || '').trim()) { this.toast('请填写注册地址'); return; }
    }
    if (step === 2) {
      const d = this.certValues(v);
      if (!String(d.cLegal || '').trim()) { this.toast('请填写法定代表人'); return; }
      if (!String(d.cLegalId || '').trim()) { this.toast('请填写法人证件号'); return; }
    }
    if (step === 4) {
      const d = this.certValues(v);
      if (!String(d.cContact || '').trim()) { this.toast('请填写联系人'); return; }
      if (!/^1[3-9]\d{9}$/.test(String(d.cMobile || '').replace(/\s/g, ''))) { this.toast('请填写正确的手机号'); return; }
      if (!/^\d{6}$/.test(String(d.cCode2 || '').trim())) { this.toast('请输入 6 位验证码（演示可填 123456）'); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(d.cEmail || '').trim())) { this.toast('请填写正确的邮箱'); return; }
      await this.submitCertForm(i);
      return;
    }
    this.setData({
      ['stack[' + i + '].vm.step']: step + 1,
      ['stack[' + i + '].footer.step']: step + 1,
      ['stack[' + i + '].footer.prevDisabled']: false,
      ['stack[' + i + '].footer.nextText']: step + 1 === 4 ? '提交审核' : '下一步'
    });
    this.setData({ certStep: step + 1 });
  },

  certValues(v) {
    const d = Object.assign({}, this._certDraft || {});
    [1, 2, 3, 4].forEach(n => {
      (v['p' + n] || []).forEach(f => { d[f.k] = f.value; });
    });
    d.cDirs = (v.dirs || []).filter(x => x.on).map(x => x.text);
    return d;
  },

  async submitCertForm(i) {
    const v = this.data.stack[i].vm;
    const d = this.certValues(v);
    await service.submitCert({
      name: d.cName, code: d.cCode, type: d.cType, year: d.cYear, size: d.cSize,
      addr: d.cAddr, site: d.cSite, scope: d.cScope, legal: d.cLegal, legalId: d.cLegalId,
      lic: '营业执照-云启智能-2026.pdf', authFile: '授权委托书-李明签章.pdf',
      contact: d.cContact, contactTitle: d.cTitle, mobile: d.cMobile, email: d.cEmail,
      invoice: { title: d.cInvTitle, tax: d.cInvTax, bank: d.cInvBank, acct: d.cInvAcct },
      state: 1, step: 1
    });
    const c = Object.assign({}, this.data.cert, {
      state: 1, name: d.cName, code: d.cCode, type: d.cType, year: d.cYear, size: d.cSize,
      addr: d.cAddr, legal: d.cLegal, legalId: d.cLegalId, contact: d.cContact,
      contactTitle: d.cTitle, mobile: d.cMobile, email: d.cEmail,
      invoice: { title: d.cInvTitle, tax: d.cInvTax, bank: d.cInvBank, acct: d.cInvAcct },
      logs: [
        { t: '提交认证申请', d: util.nowText() + ' · 提交主体信息、证照 2 份、对公开票信息', s: 'ok' },
        { t: '平台审核中', d: '当前节点：证照核验（预计 1 个工作日内完成）', s: 'on' }
      ]
    });
    this.closeAllL2();
    this.switchTab(1);
    this.setData({ cert: c, certStep: 1 });
    this.updateCertL1(c);
    this.toast('认证材料已提交，平台将在 1 个工作日内完成审核');
  },

  onCertEdit(e) {
    this.closeAllL2();
    this.setData({ certEditing: true });
    this.go('cert');
  },

  async onCertPass(e) {
    const state = (this.data.cert || {}).state;
    if (state === 2) { this.toast('认证材料已核验，可在「企业认证」中查看'); return; }
    await service.approveCert();
    const c = Object.assign({}, this.data.cert, {
      state: 2, passAt: util.nowText(),
      logs: ((this.data.cert || {}).logs || []).concat([
        { t: '平台审核通过', d: util.nowText() + ' · 证照与工商信息一致', s: 'ok' },
        { t: '认证生效', d: '有效期 12 个月，到期前 30 天提醒续期', s: 'ok' }
      ])
    });
    this.setData({ cert: c });
    this.updateCertL1(c);
    this.toast('认证已通过，发布与查看简历权限已开放');
    this.closeAllL2();
    this.go('cert');
  },

  /* ================= 编辑资料 ================= */
  onAvatarPanel(e) {
    const i = Number(e.currentTarget.dataset.i);
    const p = this.data.stack[i].vm.panel;
    this.setData({ ['stack[' + i + '].vm.panel']: !p });
  },

  onAvatarPick(e) {
    const i = Number(e.currentTarget.dataset.i);
    const seed2 = e.currentTarget.dataset.seed;
    const src = e.currentTarget.dataset.src;
    this.setData({ ['stack[' + i + '].vm.avatar']: src, ['stack[' + i + '].vm.avatarSeed']: seed2 });
  },

  onAvatarUpload(e) {
    const i = Number(e.currentTarget.dataset.i);
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      success: res => {
        const f = res.tempFiles && res.tempFiles[0];
        if (!f) return;
        if (f.size > 5 * 1024 * 1024) { this.toast('图片超过 5 MB，请压缩后再上传'); return; }
        this.setData({ ['stack[' + i + '].vm.avatar']: f.tempFilePath, ['stack[' + i + '].vm.avatarSeed']: 'custom' });
        this.toast('头像已更新，记得保存');
      }
    });
  },

  onMeInput(e) {
    const i = Number(e.currentTarget.dataset.i);
    const k = e.currentTarget.dataset.k;
    this.setData({ ['stack[' + i + '].vm.' + k]: e.detail.value });
  },

  onMePick(e) {
    const i = Number(e.currentTarget.dataset.i);
    const k = e.currentTarget.dataset.k;
    const v = this.data.stack[i].vm;
    if (k === 'city') {
      this.openPicker('所在城市', CITIES, v.city, val => this.setData({ ['stack[' + i + '].vm.city']: val }));
    } else {
      this.openPicker('求职状态', ['离职-随时到岗', '在职-月内到岗', '在职-考虑机会', '在职-暂不考虑'], v.state, val => {
        this.setData({ ['stack[' + i + '].vm.state']: val });
      });
    }
  },

  async onMeSave(e) {
    const i = Number(e.currentTarget.dataset.i);
    const v = this.data.stack[i].vm;
    if (!String(v.name || '').trim()) { this.toast('请填写姓名'); return; }
    if (!/^1[\d\s]{9,12}$/.test(String(v.phone || '').trim())) { this.toast('请填写正确的手机号'); return; }
    if (v.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v.email).trim())) { this.toast('请填写正确的邮箱'); return; }
    const me = Object.assign({}, this.data.me, {
      name: v.name, phone: v.phone, email: v.email, city: v.city, state: v.state,
      avatar: { kind: 'preset', seed: v.avatarSeed, src: v.avatar }
    });
    await service.saveProfile(me);
    this.setData({ me, meAvatar: v.avatar });
    this.toast('资料已保存');
    setTimeout(() => this.back(), 420);
  }
};
